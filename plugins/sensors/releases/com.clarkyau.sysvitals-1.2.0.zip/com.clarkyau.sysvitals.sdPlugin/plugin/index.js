"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// node_modules/ws/lib/constants.js
var require_constants = __commonJS({
  "node_modules/ws/lib/constants.js"(exports2, module2) {
    "use strict";
    var BINARY_TYPES = ["nodebuffer", "arraybuffer", "fragments"];
    var hasBlob = typeof Blob !== "undefined";
    if (hasBlob) BINARY_TYPES.push("blob");
    module2.exports = {
      BINARY_TYPES,
      EMPTY_BUFFER: Buffer.alloc(0),
      GUID: "258EAFA5-E914-47DA-95CA-C5AB0DC85B11",
      hasBlob,
      kForOnEventAttribute: Symbol("kIsForOnEventAttribute"),
      kListener: Symbol("kListener"),
      kStatusCode: Symbol("status-code"),
      kWebSocket: Symbol("websocket"),
      NOOP: () => {
      }
    };
  }
});

// node_modules/ws/lib/buffer-util.js
var require_buffer_util = __commonJS({
  "node_modules/ws/lib/buffer-util.js"(exports2, module2) {
    "use strict";
    var { EMPTY_BUFFER } = require_constants();
    var FastBuffer = Buffer[Symbol.species];
    function concat(list, totalLength) {
      if (list.length === 0) return EMPTY_BUFFER;
      if (list.length === 1) return list[0];
      const target = Buffer.allocUnsafe(totalLength);
      let offset = 0;
      for (let i = 0; i < list.length; i++) {
        const buf = list[i];
        target.set(buf, offset);
        offset += buf.length;
      }
      if (offset < totalLength) {
        return new FastBuffer(target.buffer, target.byteOffset, offset);
      }
      return target;
    }
    function _mask(source, mask, output, offset, length) {
      for (let i = 0; i < length; i++) {
        output[offset + i] = source[i] ^ mask[i & 3];
      }
    }
    function _unmask(buffer, mask) {
      for (let i = 0; i < buffer.length; i++) {
        buffer[i] ^= mask[i & 3];
      }
    }
    function toArrayBuffer(buf) {
      if (buf.length === buf.buffer.byteLength) {
        return buf.buffer;
      }
      return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.length);
    }
    function toBuffer(data) {
      toBuffer.readOnly = true;
      if (Buffer.isBuffer(data)) return data;
      let buf;
      if (data instanceof ArrayBuffer) {
        buf = new FastBuffer(data);
      } else if (ArrayBuffer.isView(data)) {
        buf = new FastBuffer(data.buffer, data.byteOffset, data.byteLength);
      } else {
        buf = Buffer.from(data);
        toBuffer.readOnly = false;
      }
      return buf;
    }
    module2.exports = {
      concat,
      mask: _mask,
      toArrayBuffer,
      toBuffer,
      unmask: _unmask
    };
    if (!process.env.WS_NO_BUFFER_UTIL) {
      try {
        const bufferUtil = require("bufferutil");
        module2.exports.mask = function(source, mask, output, offset, length) {
          if (length < 48) _mask(source, mask, output, offset, length);
          else bufferUtil.mask(source, mask, output, offset, length);
        };
        module2.exports.unmask = function(buffer, mask) {
          if (buffer.length < 32) _unmask(buffer, mask);
          else bufferUtil.unmask(buffer, mask);
        };
      } catch (e) {
      }
    }
  }
});

// node_modules/ws/lib/limiter.js
var require_limiter = __commonJS({
  "node_modules/ws/lib/limiter.js"(exports2, module2) {
    "use strict";
    var kDone = Symbol("kDone");
    var kRun = Symbol("kRun");
    var Limiter = class {
      /**
       * Creates a new `Limiter`.
       *
       * @param {Number} [concurrency=Infinity] The maximum number of jobs allowed
       *     to run concurrently
       */
      constructor(concurrency) {
        this[kDone] = () => {
          this.pending--;
          this[kRun]();
        };
        this.concurrency = concurrency || Infinity;
        this.jobs = [];
        this.pending = 0;
      }
      /**
       * Adds a job to the queue.
       *
       * @param {Function} job The job to run
       * @public
       */
      add(job) {
        this.jobs.push(job);
        this[kRun]();
      }
      /**
       * Removes a job from the queue and runs it if possible.
       *
       * @private
       */
      [kRun]() {
        if (this.pending === this.concurrency) return;
        if (this.jobs.length) {
          const job = this.jobs.shift();
          this.pending++;
          job(this[kDone]);
        }
      }
    };
    module2.exports = Limiter;
  }
});

// node_modules/ws/lib/permessage-deflate.js
var require_permessage_deflate = __commonJS({
  "node_modules/ws/lib/permessage-deflate.js"(exports2, module2) {
    "use strict";
    var zlib = require("zlib");
    var bufferUtil = require_buffer_util();
    var Limiter = require_limiter();
    var { kStatusCode } = require_constants();
    var FastBuffer = Buffer[Symbol.species];
    var TRAILER = Buffer.from([0, 0, 255, 255]);
    var kPerMessageDeflate = Symbol("permessage-deflate");
    var kTotalLength = Symbol("total-length");
    var kCallback = Symbol("callback");
    var kBuffers = Symbol("buffers");
    var kError = Symbol("error");
    var zlibLimiter;
    var PerMessageDeflate = class {
      /**
       * Creates a PerMessageDeflate instance.
       *
       * @param {Object} [options] Configuration options
       * @param {(Boolean|Number)} [options.clientMaxWindowBits] Advertise support
       *     for, or request, a custom client window size
       * @param {Boolean} [options.clientNoContextTakeover=false] Advertise/
       *     acknowledge disabling of client context takeover
       * @param {Number} [options.concurrencyLimit=10] The number of concurrent
       *     calls to zlib
       * @param {(Boolean|Number)} [options.serverMaxWindowBits] Request/confirm the
       *     use of a custom server window size
       * @param {Boolean} [options.serverNoContextTakeover=false] Request/accept
       *     disabling of server context takeover
       * @param {Number} [options.threshold=1024] Size (in bytes) below which
       *     messages should not be compressed if context takeover is disabled
       * @param {Object} [options.zlibDeflateOptions] Options to pass to zlib on
       *     deflate
       * @param {Object} [options.zlibInflateOptions] Options to pass to zlib on
       *     inflate
       * @param {Boolean} [isServer=false] Create the instance in either server or
       *     client mode
       * @param {Number} [maxPayload=0] The maximum allowed message length
       */
      constructor(options, isServer, maxPayload) {
        this._maxPayload = maxPayload | 0;
        this._options = options || {};
        this._threshold = this._options.threshold !== void 0 ? this._options.threshold : 1024;
        this._isServer = !!isServer;
        this._deflate = null;
        this._inflate = null;
        this.params = null;
        if (!zlibLimiter) {
          const concurrency = this._options.concurrencyLimit !== void 0 ? this._options.concurrencyLimit : 10;
          zlibLimiter = new Limiter(concurrency);
        }
      }
      /**
       * @type {String}
       */
      static get extensionName() {
        return "permessage-deflate";
      }
      /**
       * Create an extension negotiation offer.
       *
       * @return {Object} Extension parameters
       * @public
       */
      offer() {
        const params = {};
        if (this._options.serverNoContextTakeover) {
          params.server_no_context_takeover = true;
        }
        if (this._options.clientNoContextTakeover) {
          params.client_no_context_takeover = true;
        }
        if (this._options.serverMaxWindowBits) {
          params.server_max_window_bits = this._options.serverMaxWindowBits;
        }
        if (this._options.clientMaxWindowBits) {
          params.client_max_window_bits = this._options.clientMaxWindowBits;
        } else if (this._options.clientMaxWindowBits == null) {
          params.client_max_window_bits = true;
        }
        return params;
      }
      /**
       * Accept an extension negotiation offer/response.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Object} Accepted configuration
       * @public
       */
      accept(configurations) {
        configurations = this.normalizeParams(configurations);
        this.params = this._isServer ? this.acceptAsServer(configurations) : this.acceptAsClient(configurations);
        return this.params;
      }
      /**
       * Releases all resources used by the extension.
       *
       * @public
       */
      cleanup() {
        if (this._inflate) {
          this._inflate.close();
          this._inflate = null;
        }
        if (this._deflate) {
          const callback = this._deflate[kCallback];
          this._deflate.close();
          this._deflate = null;
          if (callback) {
            callback(
              new Error(
                "The deflate stream was closed while data was being processed"
              )
            );
          }
        }
      }
      /**
       *  Accept an extension negotiation offer.
       *
       * @param {Array} offers The extension negotiation offers
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsServer(offers) {
        const opts = this._options;
        const accepted = offers.find((params) => {
          if (opts.serverNoContextTakeover === false && params.server_no_context_takeover || params.server_max_window_bits && (opts.serverMaxWindowBits === false || typeof opts.serverMaxWindowBits === "number" && opts.serverMaxWindowBits > params.server_max_window_bits) || typeof opts.clientMaxWindowBits === "number" && !params.client_max_window_bits) {
            return false;
          }
          return true;
        });
        if (!accepted) {
          throw new Error("None of the extension offers can be accepted");
        }
        if (opts.serverNoContextTakeover) {
          accepted.server_no_context_takeover = true;
        }
        if (opts.clientNoContextTakeover) {
          accepted.client_no_context_takeover = true;
        }
        if (typeof opts.serverMaxWindowBits === "number") {
          accepted.server_max_window_bits = opts.serverMaxWindowBits;
        }
        if (typeof opts.clientMaxWindowBits === "number") {
          accepted.client_max_window_bits = opts.clientMaxWindowBits;
        } else if (accepted.client_max_window_bits === true || opts.clientMaxWindowBits === false) {
          delete accepted.client_max_window_bits;
        }
        return accepted;
      }
      /**
       * Accept the extension negotiation response.
       *
       * @param {Array} response The extension negotiation response
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsClient(response) {
        const params = response[0];
        if (this._options.clientNoContextTakeover === false && params.client_no_context_takeover) {
          throw new Error('Unexpected parameter "client_no_context_takeover"');
        }
        if (!params.client_max_window_bits) {
          if (typeof this._options.clientMaxWindowBits === "number") {
            params.client_max_window_bits = this._options.clientMaxWindowBits;
          }
        } else if (this._options.clientMaxWindowBits === false || typeof this._options.clientMaxWindowBits === "number" && params.client_max_window_bits > this._options.clientMaxWindowBits) {
          throw new Error(
            'Unexpected or invalid parameter "client_max_window_bits"'
          );
        }
        return params;
      }
      /**
       * Normalize parameters.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Array} The offers/response with normalized parameters
       * @private
       */
      normalizeParams(configurations) {
        configurations.forEach((params) => {
          Object.keys(params).forEach((key) => {
            let value = params[key];
            if (value.length > 1) {
              throw new Error(`Parameter "${key}" must have only a single value`);
            }
            value = value[0];
            if (key === "client_max_window_bits") {
              if (value !== true) {
                const num = +value;
                if (!Number.isInteger(num) || num < 8 || num > 15) {
                  throw new TypeError(
                    `Invalid value for parameter "${key}": ${value}`
                  );
                }
                value = num;
              } else if (!this._isServer) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
            } else if (key === "server_max_window_bits") {
              const num = +value;
              if (!Number.isInteger(num) || num < 8 || num > 15) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
              value = num;
            } else if (key === "client_no_context_takeover" || key === "server_no_context_takeover") {
              if (value !== true) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
            } else {
              throw new Error(`Unknown parameter "${key}"`);
            }
            params[key] = value;
          });
        });
        return configurations;
      }
      /**
       * Decompress data. Concurrency limited.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      decompress(data, fin, callback) {
        zlibLimiter.add((done) => {
          this._decompress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Compress data. Concurrency limited.
       *
       * @param {(Buffer|String)} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      compress(data, fin, callback) {
        zlibLimiter.add((done) => {
          this._compress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Decompress data.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _decompress(data, fin, callback) {
        const endpoint = this._isServer ? "client" : "server";
        if (!this._inflate) {
          const key = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
          this._inflate = zlib.createInflateRaw({
            ...this._options.zlibInflateOptions,
            windowBits
          });
          this._inflate[kPerMessageDeflate] = this;
          this._inflate[kTotalLength] = 0;
          this._inflate[kBuffers] = [];
          this._inflate.on("error", inflateOnError);
          this._inflate.on("data", inflateOnData);
        }
        this._inflate[kCallback] = callback;
        this._inflate.write(data);
        if (fin) this._inflate.write(TRAILER);
        this._inflate.flush(() => {
          const err = this._inflate[kError];
          if (err) {
            this._inflate.close();
            this._inflate = null;
            callback(err);
            return;
          }
          const data2 = bufferUtil.concat(
            this._inflate[kBuffers],
            this._inflate[kTotalLength]
          );
          if (this._inflate._readableState.endEmitted) {
            this._inflate.close();
            this._inflate = null;
          } else {
            this._inflate[kTotalLength] = 0;
            this._inflate[kBuffers] = [];
            if (fin && this.params[`${endpoint}_no_context_takeover`]) {
              this._inflate.reset();
            }
          }
          callback(null, data2);
        });
      }
      /**
       * Compress data.
       *
       * @param {(Buffer|String)} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _compress(data, fin, callback) {
        const endpoint = this._isServer ? "server" : "client";
        if (!this._deflate) {
          const key = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
          this._deflate = zlib.createDeflateRaw({
            ...this._options.zlibDeflateOptions,
            windowBits
          });
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          this._deflate.on("data", deflateOnData);
        }
        this._deflate[kCallback] = callback;
        this._deflate.write(data);
        this._deflate.flush(zlib.Z_SYNC_FLUSH, () => {
          if (!this._deflate) {
            return;
          }
          let data2 = bufferUtil.concat(
            this._deflate[kBuffers],
            this._deflate[kTotalLength]
          );
          if (fin) {
            data2 = new FastBuffer(data2.buffer, data2.byteOffset, data2.length - 4);
          }
          this._deflate[kCallback] = null;
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          if (fin && this.params[`${endpoint}_no_context_takeover`]) {
            this._deflate.reset();
          }
          callback(null, data2);
        });
      }
    };
    module2.exports = PerMessageDeflate;
    function deflateOnData(chunk) {
      this[kBuffers].push(chunk);
      this[kTotalLength] += chunk.length;
    }
    function inflateOnData(chunk) {
      this[kTotalLength] += chunk.length;
      if (this[kPerMessageDeflate]._maxPayload < 1 || this[kTotalLength] <= this[kPerMessageDeflate]._maxPayload) {
        this[kBuffers].push(chunk);
        return;
      }
      this[kError] = new RangeError("Max payload size exceeded");
      this[kError].code = "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH";
      this[kError][kStatusCode] = 1009;
      this.removeListener("data", inflateOnData);
      this.reset();
    }
    function inflateOnError(err) {
      this[kPerMessageDeflate]._inflate = null;
      err[kStatusCode] = 1007;
      this[kCallback](err);
    }
  }
});

// node_modules/ws/lib/validation.js
var require_validation = __commonJS({
  "node_modules/ws/lib/validation.js"(exports2, module2) {
    "use strict";
    var { isUtf8 } = require("buffer");
    var { hasBlob } = require_constants();
    var tokenChars = [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 0 - 15
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 16 - 31
      0,
      1,
      0,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      1,
      1,
      0,
      1,
      1,
      0,
      // 32 - 47
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      // 48 - 63
      0,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 64 - 79
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      1,
      1,
      // 80 - 95
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 96 - 111
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      1,
      0,
      1,
      0
      // 112 - 127
    ];
    function isValidStatusCode(code) {
      return code >= 1e3 && code <= 1014 && code !== 1004 && code !== 1005 && code !== 1006 || code >= 3e3 && code <= 4999;
    }
    function _isValidUTF8(buf) {
      const len = buf.length;
      let i = 0;
      while (i < len) {
        if ((buf[i] & 128) === 0) {
          i++;
        } else if ((buf[i] & 224) === 192) {
          if (i + 1 === len || (buf[i + 1] & 192) !== 128 || (buf[i] & 254) === 192) {
            return false;
          }
          i += 2;
        } else if ((buf[i] & 240) === 224) {
          if (i + 2 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || buf[i] === 224 && (buf[i + 1] & 224) === 128 || // Overlong
          buf[i] === 237 && (buf[i + 1] & 224) === 160) {
            return false;
          }
          i += 3;
        } else if ((buf[i] & 248) === 240) {
          if (i + 3 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || (buf[i + 3] & 192) !== 128 || buf[i] === 240 && (buf[i + 1] & 240) === 128 || // Overlong
          buf[i] === 244 && buf[i + 1] > 143 || buf[i] > 244) {
            return false;
          }
          i += 4;
        } else {
          return false;
        }
      }
      return true;
    }
    function isBlob(value) {
      return hasBlob && typeof value === "object" && typeof value.arrayBuffer === "function" && typeof value.type === "string" && typeof value.stream === "function" && (value[Symbol.toStringTag] === "Blob" || value[Symbol.toStringTag] === "File");
    }
    module2.exports = {
      isBlob,
      isValidStatusCode,
      isValidUTF8: _isValidUTF8,
      tokenChars
    };
    if (isUtf8) {
      module2.exports.isValidUTF8 = function(buf) {
        return buf.length < 24 ? _isValidUTF8(buf) : isUtf8(buf);
      };
    } else if (!process.env.WS_NO_UTF_8_VALIDATE) {
      try {
        const isValidUTF8 = require("utf-8-validate");
        module2.exports.isValidUTF8 = function(buf) {
          return buf.length < 32 ? _isValidUTF8(buf) : isValidUTF8(buf);
        };
      } catch (e) {
      }
    }
  }
});

// node_modules/ws/lib/receiver.js
var require_receiver = __commonJS({
  "node_modules/ws/lib/receiver.js"(exports2, module2) {
    "use strict";
    var { Writable } = require("stream");
    var PerMessageDeflate = require_permessage_deflate();
    var {
      BINARY_TYPES,
      EMPTY_BUFFER,
      kStatusCode,
      kWebSocket
    } = require_constants();
    var { concat, toArrayBuffer, unmask } = require_buffer_util();
    var { isValidStatusCode, isValidUTF8 } = require_validation();
    var FastBuffer = Buffer[Symbol.species];
    var GET_INFO = 0;
    var GET_PAYLOAD_LENGTH_16 = 1;
    var GET_PAYLOAD_LENGTH_64 = 2;
    var GET_MASK = 3;
    var GET_DATA = 4;
    var INFLATING = 5;
    var DEFER_EVENT = 6;
    var Receiver = class extends Writable {
      /**
       * Creates a Receiver instance.
       *
       * @param {Object} [options] Options object
       * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {String} [options.binaryType=nodebuffer] The type for binary data
       * @param {Object} [options.extensions] An object containing the negotiated
       *     extensions
       * @param {Boolean} [options.isServer=false] Specifies whether to operate in
       *     client or server mode
       * @param {Number} [options.maxPayload=0] The maximum allowed message length
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       */
      constructor(options = {}) {
        super();
        this._allowSynchronousEvents = options.allowSynchronousEvents !== void 0 ? options.allowSynchronousEvents : true;
        this._binaryType = options.binaryType || BINARY_TYPES[0];
        this._extensions = options.extensions || {};
        this._isServer = !!options.isServer;
        this._maxPayload = options.maxPayload | 0;
        this._skipUTF8Validation = !!options.skipUTF8Validation;
        this[kWebSocket] = void 0;
        this._bufferedBytes = 0;
        this._buffers = [];
        this._compressed = false;
        this._payloadLength = 0;
        this._mask = void 0;
        this._fragmented = 0;
        this._masked = false;
        this._fin = false;
        this._opcode = 0;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._fragments = [];
        this._errored = false;
        this._loop = false;
        this._state = GET_INFO;
      }
      /**
       * Implements `Writable.prototype._write()`.
       *
       * @param {Buffer} chunk The chunk of data to write
       * @param {String} encoding The character encoding of `chunk`
       * @param {Function} cb Callback
       * @private
       */
      _write(chunk, encoding, cb) {
        if (this._opcode === 8 && this._state == GET_INFO) return cb();
        this._bufferedBytes += chunk.length;
        this._buffers.push(chunk);
        this.startLoop(cb);
      }
      /**
       * Consumes `n` bytes from the buffered data.
       *
       * @param {Number} n The number of bytes to consume
       * @return {Buffer} The consumed bytes
       * @private
       */
      consume(n) {
        this._bufferedBytes -= n;
        if (n === this._buffers[0].length) return this._buffers.shift();
        if (n < this._buffers[0].length) {
          const buf = this._buffers[0];
          this._buffers[0] = new FastBuffer(
            buf.buffer,
            buf.byteOffset + n,
            buf.length - n
          );
          return new FastBuffer(buf.buffer, buf.byteOffset, n);
        }
        const dst = Buffer.allocUnsafe(n);
        do {
          const buf = this._buffers[0];
          const offset = dst.length - n;
          if (n >= buf.length) {
            dst.set(this._buffers.shift(), offset);
          } else {
            dst.set(new Uint8Array(buf.buffer, buf.byteOffset, n), offset);
            this._buffers[0] = new FastBuffer(
              buf.buffer,
              buf.byteOffset + n,
              buf.length - n
            );
          }
          n -= buf.length;
        } while (n > 0);
        return dst;
      }
      /**
       * Starts the parsing loop.
       *
       * @param {Function} cb Callback
       * @private
       */
      startLoop(cb) {
        this._loop = true;
        do {
          switch (this._state) {
            case GET_INFO:
              this.getInfo(cb);
              break;
            case GET_PAYLOAD_LENGTH_16:
              this.getPayloadLength16(cb);
              break;
            case GET_PAYLOAD_LENGTH_64:
              this.getPayloadLength64(cb);
              break;
            case GET_MASK:
              this.getMask();
              break;
            case GET_DATA:
              this.getData(cb);
              break;
            case INFLATING:
            case DEFER_EVENT:
              this._loop = false;
              return;
          }
        } while (this._loop);
        if (!this._errored) cb();
      }
      /**
       * Reads the first two bytes of a frame.
       *
       * @param {Function} cb Callback
       * @private
       */
      getInfo(cb) {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        const buf = this.consume(2);
        if ((buf[0] & 48) !== 0) {
          const error = this.createError(
            RangeError,
            "RSV2 and RSV3 must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_RSV_2_3"
          );
          cb(error);
          return;
        }
        const compressed = (buf[0] & 64) === 64;
        if (compressed && !this._extensions[PerMessageDeflate.extensionName]) {
          const error = this.createError(
            RangeError,
            "RSV1 must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_RSV_1"
          );
          cb(error);
          return;
        }
        this._fin = (buf[0] & 128) === 128;
        this._opcode = buf[0] & 15;
        this._payloadLength = buf[1] & 127;
        if (this._opcode === 0) {
          if (compressed) {
            const error = this.createError(
              RangeError,
              "RSV1 must be clear",
              true,
              1002,
              "WS_ERR_UNEXPECTED_RSV_1"
            );
            cb(error);
            return;
          }
          if (!this._fragmented) {
            const error = this.createError(
              RangeError,
              "invalid opcode 0",
              true,
              1002,
              "WS_ERR_INVALID_OPCODE"
            );
            cb(error);
            return;
          }
          this._opcode = this._fragmented;
        } else if (this._opcode === 1 || this._opcode === 2) {
          if (this._fragmented) {
            const error = this.createError(
              RangeError,
              `invalid opcode ${this._opcode}`,
              true,
              1002,
              "WS_ERR_INVALID_OPCODE"
            );
            cb(error);
            return;
          }
          this._compressed = compressed;
        } else if (this._opcode > 7 && this._opcode < 11) {
          if (!this._fin) {
            const error = this.createError(
              RangeError,
              "FIN must be set",
              true,
              1002,
              "WS_ERR_EXPECTED_FIN"
            );
            cb(error);
            return;
          }
          if (compressed) {
            const error = this.createError(
              RangeError,
              "RSV1 must be clear",
              true,
              1002,
              "WS_ERR_UNEXPECTED_RSV_1"
            );
            cb(error);
            return;
          }
          if (this._payloadLength > 125 || this._opcode === 8 && this._payloadLength === 1) {
            const error = this.createError(
              RangeError,
              `invalid payload length ${this._payloadLength}`,
              true,
              1002,
              "WS_ERR_INVALID_CONTROL_PAYLOAD_LENGTH"
            );
            cb(error);
            return;
          }
        } else {
          const error = this.createError(
            RangeError,
            `invalid opcode ${this._opcode}`,
            true,
            1002,
            "WS_ERR_INVALID_OPCODE"
          );
          cb(error);
          return;
        }
        if (!this._fin && !this._fragmented) this._fragmented = this._opcode;
        this._masked = (buf[1] & 128) === 128;
        if (this._isServer) {
          if (!this._masked) {
            const error = this.createError(
              RangeError,
              "MASK must be set",
              true,
              1002,
              "WS_ERR_EXPECTED_MASK"
            );
            cb(error);
            return;
          }
        } else if (this._masked) {
          const error = this.createError(
            RangeError,
            "MASK must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_MASK"
          );
          cb(error);
          return;
        }
        if (this._payloadLength === 126) this._state = GET_PAYLOAD_LENGTH_16;
        else if (this._payloadLength === 127) this._state = GET_PAYLOAD_LENGTH_64;
        else this.haveLength(cb);
      }
      /**
       * Gets extended payload length (7+16).
       *
       * @param {Function} cb Callback
       * @private
       */
      getPayloadLength16(cb) {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        this._payloadLength = this.consume(2).readUInt16BE(0);
        this.haveLength(cb);
      }
      /**
       * Gets extended payload length (7+64).
       *
       * @param {Function} cb Callback
       * @private
       */
      getPayloadLength64(cb) {
        if (this._bufferedBytes < 8) {
          this._loop = false;
          return;
        }
        const buf = this.consume(8);
        const num = buf.readUInt32BE(0);
        if (num > Math.pow(2, 53 - 32) - 1) {
          const error = this.createError(
            RangeError,
            "Unsupported WebSocket frame: payload length > 2^53 - 1",
            false,
            1009,
            "WS_ERR_UNSUPPORTED_DATA_PAYLOAD_LENGTH"
          );
          cb(error);
          return;
        }
        this._payloadLength = num * Math.pow(2, 32) + buf.readUInt32BE(4);
        this.haveLength(cb);
      }
      /**
       * Payload length has been read.
       *
       * @param {Function} cb Callback
       * @private
       */
      haveLength(cb) {
        if (this._payloadLength && this._opcode < 8) {
          this._totalPayloadLength += this._payloadLength;
          if (this._totalPayloadLength > this._maxPayload && this._maxPayload > 0) {
            const error = this.createError(
              RangeError,
              "Max payload size exceeded",
              false,
              1009,
              "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
            );
            cb(error);
            return;
          }
        }
        if (this._masked) this._state = GET_MASK;
        else this._state = GET_DATA;
      }
      /**
       * Reads mask bytes.
       *
       * @private
       */
      getMask() {
        if (this._bufferedBytes < 4) {
          this._loop = false;
          return;
        }
        this._mask = this.consume(4);
        this._state = GET_DATA;
      }
      /**
       * Reads data bytes.
       *
       * @param {Function} cb Callback
       * @private
       */
      getData(cb) {
        let data = EMPTY_BUFFER;
        if (this._payloadLength) {
          if (this._bufferedBytes < this._payloadLength) {
            this._loop = false;
            return;
          }
          data = this.consume(this._payloadLength);
          if (this._masked && (this._mask[0] | this._mask[1] | this._mask[2] | this._mask[3]) !== 0) {
            unmask(data, this._mask);
          }
        }
        if (this._opcode > 7) {
          this.controlMessage(data, cb);
          return;
        }
        if (this._compressed) {
          this._state = INFLATING;
          this.decompress(data, cb);
          return;
        }
        if (data.length) {
          this._messageLength = this._totalPayloadLength;
          this._fragments.push(data);
        }
        this.dataMessage(cb);
      }
      /**
       * Decompresses data.
       *
       * @param {Buffer} data Compressed data
       * @param {Function} cb Callback
       * @private
       */
      decompress(data, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate.extensionName];
        perMessageDeflate.decompress(data, this._fin, (err, buf) => {
          if (err) return cb(err);
          if (buf.length) {
            this._messageLength += buf.length;
            if (this._messageLength > this._maxPayload && this._maxPayload > 0) {
              const error = this.createError(
                RangeError,
                "Max payload size exceeded",
                false,
                1009,
                "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
              );
              cb(error);
              return;
            }
            this._fragments.push(buf);
          }
          this.dataMessage(cb);
          if (this._state === GET_INFO) this.startLoop(cb);
        });
      }
      /**
       * Handles a data message.
       *
       * @param {Function} cb Callback
       * @private
       */
      dataMessage(cb) {
        if (!this._fin) {
          this._state = GET_INFO;
          return;
        }
        const messageLength = this._messageLength;
        const fragments = this._fragments;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._fragmented = 0;
        this._fragments = [];
        if (this._opcode === 2) {
          let data;
          if (this._binaryType === "nodebuffer") {
            data = concat(fragments, messageLength);
          } else if (this._binaryType === "arraybuffer") {
            data = toArrayBuffer(concat(fragments, messageLength));
          } else if (this._binaryType === "blob") {
            data = new Blob(fragments);
          } else {
            data = fragments;
          }
          if (this._allowSynchronousEvents) {
            this.emit("message", data, true);
            this._state = GET_INFO;
          } else {
            this._state = DEFER_EVENT;
            setImmediate(() => {
              this.emit("message", data, true);
              this._state = GET_INFO;
              this.startLoop(cb);
            });
          }
        } else {
          const buf = concat(fragments, messageLength);
          if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
            const error = this.createError(
              Error,
              "invalid UTF-8 sequence",
              true,
              1007,
              "WS_ERR_INVALID_UTF8"
            );
            cb(error);
            return;
          }
          if (this._state === INFLATING || this._allowSynchronousEvents) {
            this.emit("message", buf, false);
            this._state = GET_INFO;
          } else {
            this._state = DEFER_EVENT;
            setImmediate(() => {
              this.emit("message", buf, false);
              this._state = GET_INFO;
              this.startLoop(cb);
            });
          }
        }
      }
      /**
       * Handles a control message.
       *
       * @param {Buffer} data Data to handle
       * @return {(Error|RangeError|undefined)} A possible error
       * @private
       */
      controlMessage(data, cb) {
        if (this._opcode === 8) {
          if (data.length === 0) {
            this._loop = false;
            this.emit("conclude", 1005, EMPTY_BUFFER);
            this.end();
          } else {
            const code = data.readUInt16BE(0);
            if (!isValidStatusCode(code)) {
              const error = this.createError(
                RangeError,
                `invalid status code ${code}`,
                true,
                1002,
                "WS_ERR_INVALID_CLOSE_CODE"
              );
              cb(error);
              return;
            }
            const buf = new FastBuffer(
              data.buffer,
              data.byteOffset + 2,
              data.length - 2
            );
            if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
              const error = this.createError(
                Error,
                "invalid UTF-8 sequence",
                true,
                1007,
                "WS_ERR_INVALID_UTF8"
              );
              cb(error);
              return;
            }
            this._loop = false;
            this.emit("conclude", code, buf);
            this.end();
          }
          this._state = GET_INFO;
          return;
        }
        if (this._allowSynchronousEvents) {
          this.emit(this._opcode === 9 ? "ping" : "pong", data);
          this._state = GET_INFO;
        } else {
          this._state = DEFER_EVENT;
          setImmediate(() => {
            this.emit(this._opcode === 9 ? "ping" : "pong", data);
            this._state = GET_INFO;
            this.startLoop(cb);
          });
        }
      }
      /**
       * Builds an error object.
       *
       * @param {function(new:Error|RangeError)} ErrorCtor The error constructor
       * @param {String} message The error message
       * @param {Boolean} prefix Specifies whether or not to add a default prefix to
       *     `message`
       * @param {Number} statusCode The status code
       * @param {String} errorCode The exposed error code
       * @return {(Error|RangeError)} The error
       * @private
       */
      createError(ErrorCtor, message, prefix, statusCode, errorCode) {
        this._loop = false;
        this._errored = true;
        const err = new ErrorCtor(
          prefix ? `Invalid WebSocket frame: ${message}` : message
        );
        Error.captureStackTrace(err, this.createError);
        err.code = errorCode;
        err[kStatusCode] = statusCode;
        return err;
      }
    };
    module2.exports = Receiver;
  }
});

// node_modules/ws/lib/sender.js
var require_sender = __commonJS({
  "node_modules/ws/lib/sender.js"(exports2, module2) {
    "use strict";
    var { Duplex } = require("stream");
    var { randomFillSync } = require("crypto");
    var PerMessageDeflate = require_permessage_deflate();
    var { EMPTY_BUFFER, kWebSocket, NOOP } = require_constants();
    var { isBlob, isValidStatusCode } = require_validation();
    var { mask: applyMask, toBuffer } = require_buffer_util();
    var kByteLength = Symbol("kByteLength");
    var maskBuffer = Buffer.alloc(4);
    var RANDOM_POOL_SIZE = 8 * 1024;
    var randomPool;
    var randomPoolPointer = RANDOM_POOL_SIZE;
    var DEFAULT = 0;
    var DEFLATING = 1;
    var GET_BLOB_DATA = 2;
    var Sender = class _Sender {
      /**
       * Creates a Sender instance.
       *
       * @param {Duplex} socket The connection socket
       * @param {Object} [extensions] An object containing the negotiated extensions
       * @param {Function} [generateMask] The function used to generate the masking
       *     key
       */
      constructor(socket, extensions, generateMask) {
        this._extensions = extensions || {};
        if (generateMask) {
          this._generateMask = generateMask;
          this._maskBuffer = Buffer.alloc(4);
        }
        this._socket = socket;
        this._firstFragment = true;
        this._compress = false;
        this._bufferedBytes = 0;
        this._queue = [];
        this._state = DEFAULT;
        this.onerror = NOOP;
        this[kWebSocket] = void 0;
      }
      /**
       * Frames a piece of data according to the HyBi WebSocket protocol.
       *
       * @param {(Buffer|String)} data The data to frame
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @return {(Buffer|String)[]} The framed data
       * @public
       */
      static frame(data, options) {
        let mask;
        let merge = false;
        let offset = 2;
        let skipMasking = false;
        if (options.mask) {
          mask = options.maskBuffer || maskBuffer;
          if (options.generateMask) {
            options.generateMask(mask);
          } else {
            if (randomPoolPointer === RANDOM_POOL_SIZE) {
              if (randomPool === void 0) {
                randomPool = Buffer.alloc(RANDOM_POOL_SIZE);
              }
              randomFillSync(randomPool, 0, RANDOM_POOL_SIZE);
              randomPoolPointer = 0;
            }
            mask[0] = randomPool[randomPoolPointer++];
            mask[1] = randomPool[randomPoolPointer++];
            mask[2] = randomPool[randomPoolPointer++];
            mask[3] = randomPool[randomPoolPointer++];
          }
          skipMasking = (mask[0] | mask[1] | mask[2] | mask[3]) === 0;
          offset = 6;
        }
        let dataLength;
        if (typeof data === "string") {
          if ((!options.mask || skipMasking) && options[kByteLength] !== void 0) {
            dataLength = options[kByteLength];
          } else {
            data = Buffer.from(data);
            dataLength = data.length;
          }
        } else {
          dataLength = data.length;
          merge = options.mask && options.readOnly && !skipMasking;
        }
        let payloadLength = dataLength;
        if (dataLength >= 65536) {
          offset += 8;
          payloadLength = 127;
        } else if (dataLength > 125) {
          offset += 2;
          payloadLength = 126;
        }
        const target = Buffer.allocUnsafe(merge ? dataLength + offset : offset);
        target[0] = options.fin ? options.opcode | 128 : options.opcode;
        if (options.rsv1) target[0] |= 64;
        target[1] = payloadLength;
        if (payloadLength === 126) {
          target.writeUInt16BE(dataLength, 2);
        } else if (payloadLength === 127) {
          target[2] = target[3] = 0;
          target.writeUIntBE(dataLength, 4, 6);
        }
        if (!options.mask) return [target, data];
        target[1] |= 128;
        target[offset - 4] = mask[0];
        target[offset - 3] = mask[1];
        target[offset - 2] = mask[2];
        target[offset - 1] = mask[3];
        if (skipMasking) return [target, data];
        if (merge) {
          applyMask(data, mask, target, offset, dataLength);
          return [target];
        }
        applyMask(data, mask, data, 0, dataLength);
        return [target, data];
      }
      /**
       * Sends a close message to the other peer.
       *
       * @param {Number} [code] The status code component of the body
       * @param {(String|Buffer)} [data] The message component of the body
       * @param {Boolean} [mask=false] Specifies whether or not to mask the message
       * @param {Function} [cb] Callback
       * @public
       */
      close(code, data, mask, cb) {
        let buf;
        if (code === void 0) {
          buf = EMPTY_BUFFER;
        } else if (typeof code !== "number" || !isValidStatusCode(code)) {
          throw new TypeError("First argument must be a valid error code number");
        } else if (data === void 0 || !data.length) {
          buf = Buffer.allocUnsafe(2);
          buf.writeUInt16BE(code, 0);
        } else {
          const length = Buffer.byteLength(data);
          if (length > 123) {
            throw new RangeError("The message must not be greater than 123 bytes");
          }
          buf = Buffer.allocUnsafe(2 + length);
          buf.writeUInt16BE(code, 0);
          if (typeof data === "string") {
            buf.write(data, 2);
          } else {
            buf.set(data, 2);
          }
        }
        const options = {
          [kByteLength]: buf.length,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 8,
          readOnly: false,
          rsv1: false
        };
        if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, buf, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(buf, options), cb);
        }
      }
      /**
       * Sends a ping message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback
       * @public
       */
      ping(data, mask, cb) {
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (byteLength > 125) {
          throw new RangeError("The data size must not be greater than 125 bytes");
        }
        const options = {
          [kByteLength]: byteLength,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 9,
          readOnly,
          rsv1: false
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, false, options, cb]);
          } else {
            this.getBlobData(data, false, options, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(data, options), cb);
        }
      }
      /**
       * Sends a pong message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback
       * @public
       */
      pong(data, mask, cb) {
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (byteLength > 125) {
          throw new RangeError("The data size must not be greater than 125 bytes");
        }
        const options = {
          [kByteLength]: byteLength,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 10,
          readOnly,
          rsv1: false
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, false, options, cb]);
          } else {
            this.getBlobData(data, false, options, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(data, options), cb);
        }
      }
      /**
       * Sends a data message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Object} options Options object
       * @param {Boolean} [options.binary=false] Specifies whether `data` is binary
       *     or text
       * @param {Boolean} [options.compress=false] Specifies whether or not to
       *     compress `data`
       * @param {Boolean} [options.fin=false] Specifies whether the fragment is the
       *     last one
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Function} [cb] Callback
       * @public
       */
      send(data, options, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate.extensionName];
        let opcode = options.binary ? 2 : 1;
        let rsv1 = options.compress;
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (this._firstFragment) {
          this._firstFragment = false;
          if (rsv1 && perMessageDeflate && perMessageDeflate.params[perMessageDeflate._isServer ? "server_no_context_takeover" : "client_no_context_takeover"]) {
            rsv1 = byteLength >= perMessageDeflate._threshold;
          }
          this._compress = rsv1;
        } else {
          rsv1 = false;
          opcode = 0;
        }
        if (options.fin) this._firstFragment = true;
        const opts = {
          [kByteLength]: byteLength,
          fin: options.fin,
          generateMask: this._generateMask,
          mask: options.mask,
          maskBuffer: this._maskBuffer,
          opcode,
          readOnly,
          rsv1
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, this._compress, opts, cb]);
          } else {
            this.getBlobData(data, this._compress, opts, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, this._compress, opts, cb]);
        } else {
          this.dispatch(data, this._compress, opts, cb);
        }
      }
      /**
       * Gets the contents of a blob as binary data.
       *
       * @param {Blob} blob The blob
       * @param {Boolean} [compress=false] Specifies whether or not to compress
       *     the data
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @param {Function} [cb] Callback
       * @private
       */
      getBlobData(blob, compress, options, cb) {
        this._bufferedBytes += options[kByteLength];
        this._state = GET_BLOB_DATA;
        blob.arrayBuffer().then((arrayBuffer) => {
          if (this._socket.destroyed) {
            const err = new Error(
              "The socket was closed while the blob was being read"
            );
            process.nextTick(callCallbacks, this, err, cb);
            return;
          }
          this._bufferedBytes -= options[kByteLength];
          const data = toBuffer(arrayBuffer);
          if (!compress) {
            this._state = DEFAULT;
            this.sendFrame(_Sender.frame(data, options), cb);
            this.dequeue();
          } else {
            this.dispatch(data, compress, options, cb);
          }
        }).catch((err) => {
          process.nextTick(onError, this, err, cb);
        });
      }
      /**
       * Dispatches a message.
       *
       * @param {(Buffer|String)} data The message to send
       * @param {Boolean} [compress=false] Specifies whether or not to compress
       *     `data`
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @param {Function} [cb] Callback
       * @private
       */
      dispatch(data, compress, options, cb) {
        if (!compress) {
          this.sendFrame(_Sender.frame(data, options), cb);
          return;
        }
        const perMessageDeflate = this._extensions[PerMessageDeflate.extensionName];
        this._bufferedBytes += options[kByteLength];
        this._state = DEFLATING;
        perMessageDeflate.compress(data, options.fin, (_, buf) => {
          if (this._socket.destroyed) {
            const err = new Error(
              "The socket was closed while data was being compressed"
            );
            callCallbacks(this, err, cb);
            return;
          }
          this._bufferedBytes -= options[kByteLength];
          this._state = DEFAULT;
          options.readOnly = false;
          this.sendFrame(_Sender.frame(buf, options), cb);
          this.dequeue();
        });
      }
      /**
       * Executes queued send operations.
       *
       * @private
       */
      dequeue() {
        while (this._state === DEFAULT && this._queue.length) {
          const params = this._queue.shift();
          this._bufferedBytes -= params[3][kByteLength];
          Reflect.apply(params[0], this, params.slice(1));
        }
      }
      /**
       * Enqueues a send operation.
       *
       * @param {Array} params Send operation parameters.
       * @private
       */
      enqueue(params) {
        this._bufferedBytes += params[3][kByteLength];
        this._queue.push(params);
      }
      /**
       * Sends a frame.
       *
       * @param {Buffer[]} list The frame to send
       * @param {Function} [cb] Callback
       * @private
       */
      sendFrame(list, cb) {
        if (list.length === 2) {
          this._socket.cork();
          this._socket.write(list[0]);
          this._socket.write(list[1], cb);
          this._socket.uncork();
        } else {
          this._socket.write(list[0], cb);
        }
      }
    };
    module2.exports = Sender;
    function callCallbacks(sender, err, cb) {
      if (typeof cb === "function") cb(err);
      for (let i = 0; i < sender._queue.length; i++) {
        const params = sender._queue[i];
        const callback = params[params.length - 1];
        if (typeof callback === "function") callback(err);
      }
    }
    function onError(sender, err, cb) {
      callCallbacks(sender, err, cb);
      sender.onerror(err);
    }
  }
});

// node_modules/ws/lib/event-target.js
var require_event_target = __commonJS({
  "node_modules/ws/lib/event-target.js"(exports2, module2) {
    "use strict";
    var { kForOnEventAttribute, kListener } = require_constants();
    var kCode = Symbol("kCode");
    var kData = Symbol("kData");
    var kError = Symbol("kError");
    var kMessage = Symbol("kMessage");
    var kReason = Symbol("kReason");
    var kTarget = Symbol("kTarget");
    var kType = Symbol("kType");
    var kWasClean = Symbol("kWasClean");
    var Event = class {
      /**
       * Create a new `Event`.
       *
       * @param {String} type The name of the event
       * @throws {TypeError} If the `type` argument is not specified
       */
      constructor(type) {
        this[kTarget] = null;
        this[kType] = type;
      }
      /**
       * @type {*}
       */
      get target() {
        return this[kTarget];
      }
      /**
       * @type {String}
       */
      get type() {
        return this[kType];
      }
    };
    Object.defineProperty(Event.prototype, "target", { enumerable: true });
    Object.defineProperty(Event.prototype, "type", { enumerable: true });
    var CloseEvent = class extends Event {
      /**
       * Create a new `CloseEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {Number} [options.code=0] The status code explaining why the
       *     connection was closed
       * @param {String} [options.reason=''] A human-readable string explaining why
       *     the connection was closed
       * @param {Boolean} [options.wasClean=false] Indicates whether or not the
       *     connection was cleanly closed
       */
      constructor(type, options = {}) {
        super(type);
        this[kCode] = options.code === void 0 ? 0 : options.code;
        this[kReason] = options.reason === void 0 ? "" : options.reason;
        this[kWasClean] = options.wasClean === void 0 ? false : options.wasClean;
      }
      /**
       * @type {Number}
       */
      get code() {
        return this[kCode];
      }
      /**
       * @type {String}
       */
      get reason() {
        return this[kReason];
      }
      /**
       * @type {Boolean}
       */
      get wasClean() {
        return this[kWasClean];
      }
    };
    Object.defineProperty(CloseEvent.prototype, "code", { enumerable: true });
    Object.defineProperty(CloseEvent.prototype, "reason", { enumerable: true });
    Object.defineProperty(CloseEvent.prototype, "wasClean", { enumerable: true });
    var ErrorEvent = class extends Event {
      /**
       * Create a new `ErrorEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {*} [options.error=null] The error that generated this event
       * @param {String} [options.message=''] The error message
       */
      constructor(type, options = {}) {
        super(type);
        this[kError] = options.error === void 0 ? null : options.error;
        this[kMessage] = options.message === void 0 ? "" : options.message;
      }
      /**
       * @type {*}
       */
      get error() {
        return this[kError];
      }
      /**
       * @type {String}
       */
      get message() {
        return this[kMessage];
      }
    };
    Object.defineProperty(ErrorEvent.prototype, "error", { enumerable: true });
    Object.defineProperty(ErrorEvent.prototype, "message", { enumerable: true });
    var MessageEvent = class extends Event {
      /**
       * Create a new `MessageEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {*} [options.data=null] The message content
       */
      constructor(type, options = {}) {
        super(type);
        this[kData] = options.data === void 0 ? null : options.data;
      }
      /**
       * @type {*}
       */
      get data() {
        return this[kData];
      }
    };
    Object.defineProperty(MessageEvent.prototype, "data", { enumerable: true });
    var EventTarget = {
      /**
       * Register an event listener.
       *
       * @param {String} type A string representing the event type to listen for
       * @param {(Function|Object)} handler The listener to add
       * @param {Object} [options] An options object specifies characteristics about
       *     the event listener
       * @param {Boolean} [options.once=false] A `Boolean` indicating that the
       *     listener should be invoked at most once after being added. If `true`,
       *     the listener would be automatically removed when invoked.
       * @public
       */
      addEventListener(type, handler, options = {}) {
        for (const listener of this.listeners(type)) {
          if (!options[kForOnEventAttribute] && listener[kListener] === handler && !listener[kForOnEventAttribute]) {
            return;
          }
        }
        let wrapper;
        if (type === "message") {
          wrapper = function onMessage(data, isBinary) {
            const event = new MessageEvent("message", {
              data: isBinary ? data : data.toString()
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "close") {
          wrapper = function onClose(code, message) {
            const event = new CloseEvent("close", {
              code,
              reason: message.toString(),
              wasClean: this._closeFrameReceived && this._closeFrameSent
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "error") {
          wrapper = function onError(error) {
            const event = new ErrorEvent("error", {
              error,
              message: error.message
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "open") {
          wrapper = function onOpen() {
            const event = new Event("open");
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else {
          return;
        }
        wrapper[kForOnEventAttribute] = !!options[kForOnEventAttribute];
        wrapper[kListener] = handler;
        if (options.once) {
          this.once(type, wrapper);
        } else {
          this.on(type, wrapper);
        }
      },
      /**
       * Remove an event listener.
       *
       * @param {String} type A string representing the event type to remove
       * @param {(Function|Object)} handler The listener to remove
       * @public
       */
      removeEventListener(type, handler) {
        for (const listener of this.listeners(type)) {
          if (listener[kListener] === handler && !listener[kForOnEventAttribute]) {
            this.removeListener(type, listener);
            break;
          }
        }
      }
    };
    module2.exports = {
      CloseEvent,
      ErrorEvent,
      Event,
      EventTarget,
      MessageEvent
    };
    function callListener(listener, thisArg, event) {
      if (typeof listener === "object" && listener.handleEvent) {
        listener.handleEvent.call(listener, event);
      } else {
        listener.call(thisArg, event);
      }
    }
  }
});

// node_modules/ws/lib/extension.js
var require_extension = __commonJS({
  "node_modules/ws/lib/extension.js"(exports2, module2) {
    "use strict";
    var { tokenChars } = require_validation();
    function push(dest, name, elem) {
      if (dest[name] === void 0) dest[name] = [elem];
      else dest[name].push(elem);
    }
    function parse(header) {
      const offers = /* @__PURE__ */ Object.create(null);
      let params = /* @__PURE__ */ Object.create(null);
      let mustUnescape = false;
      let isEscaping = false;
      let inQuotes = false;
      let extensionName;
      let paramName;
      let start = -1;
      let code = -1;
      let end = -1;
      let i = 0;
      for (; i < header.length; i++) {
        code = header.charCodeAt(i);
        if (extensionName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (i !== 0 && (code === 32 || code === 9)) {
            if (end === -1 && start !== -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            const name = header.slice(start, end);
            if (code === 44) {
              push(offers, name, params);
              params = /* @__PURE__ */ Object.create(null);
            } else {
              extensionName = name;
            }
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else if (paramName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (code === 32 || code === 9) {
            if (end === -1 && start !== -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            push(params, header.slice(start, end), true);
            if (code === 44) {
              push(offers, extensionName, params);
              params = /* @__PURE__ */ Object.create(null);
              extensionName = void 0;
            }
            start = end = -1;
          } else if (code === 61 && start !== -1 && end === -1) {
            paramName = header.slice(start, i);
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else {
          if (isEscaping) {
            if (tokenChars[code] !== 1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (start === -1) start = i;
            else if (!mustUnescape) mustUnescape = true;
            isEscaping = false;
          } else if (inQuotes) {
            if (tokenChars[code] === 1) {
              if (start === -1) start = i;
            } else if (code === 34 && start !== -1) {
              inQuotes = false;
              end = i;
            } else if (code === 92) {
              isEscaping = true;
            } else {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
          } else if (code === 34 && header.charCodeAt(i - 1) === 61) {
            inQuotes = true;
          } else if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (start !== -1 && (code === 32 || code === 9)) {
            if (end === -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            let value = header.slice(start, end);
            if (mustUnescape) {
              value = value.replace(/\\/g, "");
              mustUnescape = false;
            }
            push(params, paramName, value);
            if (code === 44) {
              push(offers, extensionName, params);
              params = /* @__PURE__ */ Object.create(null);
              extensionName = void 0;
            }
            paramName = void 0;
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        }
      }
      if (start === -1 || inQuotes || code === 32 || code === 9) {
        throw new SyntaxError("Unexpected end of input");
      }
      if (end === -1) end = i;
      const token = header.slice(start, end);
      if (extensionName === void 0) {
        push(offers, token, params);
      } else {
        if (paramName === void 0) {
          push(params, token, true);
        } else if (mustUnescape) {
          push(params, paramName, token.replace(/\\/g, ""));
        } else {
          push(params, paramName, token);
        }
        push(offers, extensionName, params);
      }
      return offers;
    }
    function format(extensions) {
      return Object.keys(extensions).map((extension) => {
        let configurations = extensions[extension];
        if (!Array.isArray(configurations)) configurations = [configurations];
        return configurations.map((params) => {
          return [extension].concat(
            Object.keys(params).map((k) => {
              let values = params[k];
              if (!Array.isArray(values)) values = [values];
              return values.map((v) => v === true ? k : `${k}=${v}`).join("; ");
            })
          ).join("; ");
        }).join(", ");
      }).join(", ");
    }
    module2.exports = { format, parse };
  }
});

// node_modules/ws/lib/websocket.js
var require_websocket = __commonJS({
  "node_modules/ws/lib/websocket.js"(exports2, module2) {
    "use strict";
    var EventEmitter = require("events");
    var https = require("https");
    var http = require("http");
    var net = require("net");
    var tls = require("tls");
    var { randomBytes, createHash } = require("crypto");
    var { Duplex, Readable } = require("stream");
    var { URL } = require("url");
    var PerMessageDeflate = require_permessage_deflate();
    var Receiver = require_receiver();
    var Sender = require_sender();
    var { isBlob } = require_validation();
    var {
      BINARY_TYPES,
      EMPTY_BUFFER,
      GUID,
      kForOnEventAttribute,
      kListener,
      kStatusCode,
      kWebSocket,
      NOOP
    } = require_constants();
    var {
      EventTarget: { addEventListener, removeEventListener }
    } = require_event_target();
    var { format, parse } = require_extension();
    var { toBuffer } = require_buffer_util();
    var closeTimeout = 30 * 1e3;
    var kAborted = Symbol("kAborted");
    var protocolVersions = [8, 13];
    var readyStates = ["CONNECTING", "OPEN", "CLOSING", "CLOSED"];
    var subprotocolRegex = /^[!#$%&'*+\-.0-9A-Z^_`|a-z~]+$/;
    var WebSocket2 = class _WebSocket extends EventEmitter {
      /**
       * Create a new `WebSocket`.
       *
       * @param {(String|URL)} address The URL to which to connect
       * @param {(String|String[])} [protocols] The subprotocols
       * @param {Object} [options] Connection options
       */
      constructor(address, protocols, options) {
        super();
        this._binaryType = BINARY_TYPES[0];
        this._closeCode = 1006;
        this._closeFrameReceived = false;
        this._closeFrameSent = false;
        this._closeMessage = EMPTY_BUFFER;
        this._closeTimer = null;
        this._errorEmitted = false;
        this._extensions = {};
        this._paused = false;
        this._protocol = "";
        this._readyState = _WebSocket.CONNECTING;
        this._receiver = null;
        this._sender = null;
        this._socket = null;
        if (address !== null) {
          this._bufferedAmount = 0;
          this._isServer = false;
          this._redirects = 0;
          if (protocols === void 0) {
            protocols = [];
          } else if (!Array.isArray(protocols)) {
            if (typeof protocols === "object" && protocols !== null) {
              options = protocols;
              protocols = [];
            } else {
              protocols = [protocols];
            }
          }
          initAsClient(this, address, protocols, options);
        } else {
          this._autoPong = options.autoPong;
          this._isServer = true;
        }
      }
      /**
       * For historical reasons, the custom "nodebuffer" type is used by the default
       * instead of "blob".
       *
       * @type {String}
       */
      get binaryType() {
        return this._binaryType;
      }
      set binaryType(type) {
        if (!BINARY_TYPES.includes(type)) return;
        this._binaryType = type;
        if (this._receiver) this._receiver._binaryType = type;
      }
      /**
       * @type {Number}
       */
      get bufferedAmount() {
        if (!this._socket) return this._bufferedAmount;
        return this._socket._writableState.length + this._sender._bufferedBytes;
      }
      /**
       * @type {String}
       */
      get extensions() {
        return Object.keys(this._extensions).join();
      }
      /**
       * @type {Boolean}
       */
      get isPaused() {
        return this._paused;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onclose() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onerror() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onopen() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onmessage() {
        return null;
      }
      /**
       * @type {String}
       */
      get protocol() {
        return this._protocol;
      }
      /**
       * @type {Number}
       */
      get readyState() {
        return this._readyState;
      }
      /**
       * @type {String}
       */
      get url() {
        return this._url;
      }
      /**
       * Set up the socket and the internal resources.
       *
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Object} options Options object
       * @param {Boolean} [options.allowSynchronousEvents=false] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Number} [options.maxPayload=0] The maximum allowed message size
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       * @private
       */
      setSocket(socket, head, options) {
        const receiver = new Receiver({
          allowSynchronousEvents: options.allowSynchronousEvents,
          binaryType: this.binaryType,
          extensions: this._extensions,
          isServer: this._isServer,
          maxPayload: options.maxPayload,
          skipUTF8Validation: options.skipUTF8Validation
        });
        const sender = new Sender(socket, this._extensions, options.generateMask);
        this._receiver = receiver;
        this._sender = sender;
        this._socket = socket;
        receiver[kWebSocket] = this;
        sender[kWebSocket] = this;
        socket[kWebSocket] = this;
        receiver.on("conclude", receiverOnConclude);
        receiver.on("drain", receiverOnDrain);
        receiver.on("error", receiverOnError);
        receiver.on("message", receiverOnMessage);
        receiver.on("ping", receiverOnPing);
        receiver.on("pong", receiverOnPong);
        sender.onerror = senderOnError;
        if (socket.setTimeout) socket.setTimeout(0);
        if (socket.setNoDelay) socket.setNoDelay();
        if (head.length > 0) socket.unshift(head);
        socket.on("close", socketOnClose);
        socket.on("data", socketOnData);
        socket.on("end", socketOnEnd);
        socket.on("error", socketOnError);
        this._readyState = _WebSocket.OPEN;
        this.emit("open");
      }
      /**
       * Emit the `'close'` event.
       *
       * @private
       */
      emitClose() {
        if (!this._socket) {
          this._readyState = _WebSocket.CLOSED;
          this.emit("close", this._closeCode, this._closeMessage);
          return;
        }
        if (this._extensions[PerMessageDeflate.extensionName]) {
          this._extensions[PerMessageDeflate.extensionName].cleanup();
        }
        this._receiver.removeAllListeners();
        this._readyState = _WebSocket.CLOSED;
        this.emit("close", this._closeCode, this._closeMessage);
      }
      /**
       * Start a closing handshake.
       *
       *          +----------+   +-----------+   +----------+
       *     - - -|ws.close()|-->|close frame|-->|ws.close()|- - -
       *    |     +----------+   +-----------+   +----------+     |
       *          +----------+   +-----------+         |
       * CLOSING  |ws.close()|<--|close frame|<--+-----+       CLOSING
       *          +----------+   +-----------+   |
       *    |           |                        |   +---+        |
       *                +------------------------+-->|fin| - - - -
       *    |         +---+                      |   +---+
       *     - - - - -|fin|<---------------------+
       *              +---+
       *
       * @param {Number} [code] Status code explaining why the connection is closing
       * @param {(String|Buffer)} [data] The reason why the connection is
       *     closing
       * @public
       */
      close(code, data) {
        if (this.readyState === _WebSocket.CLOSED) return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          abortHandshake(this, this._req, msg);
          return;
        }
        if (this.readyState === _WebSocket.CLOSING) {
          if (this._closeFrameSent && (this._closeFrameReceived || this._receiver._writableState.errorEmitted)) {
            this._socket.end();
          }
          return;
        }
        this._readyState = _WebSocket.CLOSING;
        this._sender.close(code, data, !this._isServer, (err) => {
          if (err) return;
          this._closeFrameSent = true;
          if (this._closeFrameReceived || this._receiver._writableState.errorEmitted) {
            this._socket.end();
          }
        });
        setCloseTimer(this);
      }
      /**
       * Pause the socket.
       *
       * @public
       */
      pause() {
        if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
          return;
        }
        this._paused = true;
        this._socket.pause();
      }
      /**
       * Send a ping.
       *
       * @param {*} [data] The data to send
       * @param {Boolean} [mask] Indicates whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when the ping is sent
       * @public
       */
      ping(data, mask, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        if (mask === void 0) mask = !this._isServer;
        this._sender.ping(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Send a pong.
       *
       * @param {*} [data] The data to send
       * @param {Boolean} [mask] Indicates whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when the pong is sent
       * @public
       */
      pong(data, mask, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        if (mask === void 0) mask = !this._isServer;
        this._sender.pong(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Resume the socket.
       *
       * @public
       */
      resume() {
        if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
          return;
        }
        this._paused = false;
        if (!this._receiver._writableState.needDrain) this._socket.resume();
      }
      /**
       * Send a data message.
       *
       * @param {*} data The message to send
       * @param {Object} [options] Options object
       * @param {Boolean} [options.binary] Specifies whether `data` is binary or
       *     text
       * @param {Boolean} [options.compress] Specifies whether or not to compress
       *     `data`
       * @param {Boolean} [options.fin=true] Specifies whether the fragment is the
       *     last one
       * @param {Boolean} [options.mask] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when data is written out
       * @public
       */
      send(data, options, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof options === "function") {
          cb = options;
          options = {};
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        const opts = {
          binary: typeof data !== "string",
          mask: !this._isServer,
          compress: true,
          fin: true,
          ...options
        };
        if (!this._extensions[PerMessageDeflate.extensionName]) {
          opts.compress = false;
        }
        this._sender.send(data || EMPTY_BUFFER, opts, cb);
      }
      /**
       * Forcibly close the connection.
       *
       * @public
       */
      terminate() {
        if (this.readyState === _WebSocket.CLOSED) return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          abortHandshake(this, this._req, msg);
          return;
        }
        if (this._socket) {
          this._readyState = _WebSocket.CLOSING;
          this._socket.destroy();
        }
      }
    };
    Object.defineProperty(WebSocket2, "CONNECTING", {
      enumerable: true,
      value: readyStates.indexOf("CONNECTING")
    });
    Object.defineProperty(WebSocket2.prototype, "CONNECTING", {
      enumerable: true,
      value: readyStates.indexOf("CONNECTING")
    });
    Object.defineProperty(WebSocket2, "OPEN", {
      enumerable: true,
      value: readyStates.indexOf("OPEN")
    });
    Object.defineProperty(WebSocket2.prototype, "OPEN", {
      enumerable: true,
      value: readyStates.indexOf("OPEN")
    });
    Object.defineProperty(WebSocket2, "CLOSING", {
      enumerable: true,
      value: readyStates.indexOf("CLOSING")
    });
    Object.defineProperty(WebSocket2.prototype, "CLOSING", {
      enumerable: true,
      value: readyStates.indexOf("CLOSING")
    });
    Object.defineProperty(WebSocket2, "CLOSED", {
      enumerable: true,
      value: readyStates.indexOf("CLOSED")
    });
    Object.defineProperty(WebSocket2.prototype, "CLOSED", {
      enumerable: true,
      value: readyStates.indexOf("CLOSED")
    });
    [
      "binaryType",
      "bufferedAmount",
      "extensions",
      "isPaused",
      "protocol",
      "readyState",
      "url"
    ].forEach((property) => {
      Object.defineProperty(WebSocket2.prototype, property, { enumerable: true });
    });
    ["open", "error", "close", "message"].forEach((method) => {
      Object.defineProperty(WebSocket2.prototype, `on${method}`, {
        enumerable: true,
        get() {
          for (const listener of this.listeners(method)) {
            if (listener[kForOnEventAttribute]) return listener[kListener];
          }
          return null;
        },
        set(handler) {
          for (const listener of this.listeners(method)) {
            if (listener[kForOnEventAttribute]) {
              this.removeListener(method, listener);
              break;
            }
          }
          if (typeof handler !== "function") return;
          this.addEventListener(method, handler, {
            [kForOnEventAttribute]: true
          });
        }
      });
    });
    WebSocket2.prototype.addEventListener = addEventListener;
    WebSocket2.prototype.removeEventListener = removeEventListener;
    module2.exports = WebSocket2;
    function initAsClient(websocket, address, protocols, options) {
      const opts = {
        allowSynchronousEvents: true,
        autoPong: true,
        protocolVersion: protocolVersions[1],
        maxPayload: 100 * 1024 * 1024,
        skipUTF8Validation: false,
        perMessageDeflate: true,
        followRedirects: false,
        maxRedirects: 10,
        ...options,
        socketPath: void 0,
        hostname: void 0,
        protocol: void 0,
        timeout: void 0,
        method: "GET",
        host: void 0,
        path: void 0,
        port: void 0
      };
      websocket._autoPong = opts.autoPong;
      if (!protocolVersions.includes(opts.protocolVersion)) {
        throw new RangeError(
          `Unsupported protocol version: ${opts.protocolVersion} (supported versions: ${protocolVersions.join(", ")})`
        );
      }
      let parsedUrl;
      if (address instanceof URL) {
        parsedUrl = address;
      } else {
        try {
          parsedUrl = new URL(address);
        } catch (e) {
          throw new SyntaxError(`Invalid URL: ${address}`);
        }
      }
      if (parsedUrl.protocol === "http:") {
        parsedUrl.protocol = "ws:";
      } else if (parsedUrl.protocol === "https:") {
        parsedUrl.protocol = "wss:";
      }
      websocket._url = parsedUrl.href;
      const isSecure = parsedUrl.protocol === "wss:";
      const isIpcUrl = parsedUrl.protocol === "ws+unix:";
      let invalidUrlMessage;
      if (parsedUrl.protocol !== "ws:" && !isSecure && !isIpcUrl) {
        invalidUrlMessage = `The URL's protocol must be one of "ws:", "wss:", "http:", "https", or "ws+unix:"`;
      } else if (isIpcUrl && !parsedUrl.pathname) {
        invalidUrlMessage = "The URL's pathname is empty";
      } else if (parsedUrl.hash) {
        invalidUrlMessage = "The URL contains a fragment identifier";
      }
      if (invalidUrlMessage) {
        const err = new SyntaxError(invalidUrlMessage);
        if (websocket._redirects === 0) {
          throw err;
        } else {
          emitErrorAndClose(websocket, err);
          return;
        }
      }
      const defaultPort = isSecure ? 443 : 80;
      const key = randomBytes(16).toString("base64");
      const request = isSecure ? https.request : http.request;
      const protocolSet = /* @__PURE__ */ new Set();
      let perMessageDeflate;
      opts.createConnection = opts.createConnection || (isSecure ? tlsConnect : netConnect);
      opts.defaultPort = opts.defaultPort || defaultPort;
      opts.port = parsedUrl.port || defaultPort;
      opts.host = parsedUrl.hostname.startsWith("[") ? parsedUrl.hostname.slice(1, -1) : parsedUrl.hostname;
      opts.headers = {
        ...opts.headers,
        "Sec-WebSocket-Version": opts.protocolVersion,
        "Sec-WebSocket-Key": key,
        Connection: "Upgrade",
        Upgrade: "websocket"
      };
      opts.path = parsedUrl.pathname + parsedUrl.search;
      opts.timeout = opts.handshakeTimeout;
      if (opts.perMessageDeflate) {
        perMessageDeflate = new PerMessageDeflate(
          opts.perMessageDeflate !== true ? opts.perMessageDeflate : {},
          false,
          opts.maxPayload
        );
        opts.headers["Sec-WebSocket-Extensions"] = format({
          [PerMessageDeflate.extensionName]: perMessageDeflate.offer()
        });
      }
      if (protocols.length) {
        for (const protocol of protocols) {
          if (typeof protocol !== "string" || !subprotocolRegex.test(protocol) || protocolSet.has(protocol)) {
            throw new SyntaxError(
              "An invalid or duplicated subprotocol was specified"
            );
          }
          protocolSet.add(protocol);
        }
        opts.headers["Sec-WebSocket-Protocol"] = protocols.join(",");
      }
      if (opts.origin) {
        if (opts.protocolVersion < 13) {
          opts.headers["Sec-WebSocket-Origin"] = opts.origin;
        } else {
          opts.headers.Origin = opts.origin;
        }
      }
      if (parsedUrl.username || parsedUrl.password) {
        opts.auth = `${parsedUrl.username}:${parsedUrl.password}`;
      }
      if (isIpcUrl) {
        const parts = opts.path.split(":");
        opts.socketPath = parts[0];
        opts.path = parts[1];
      }
      let req;
      if (opts.followRedirects) {
        if (websocket._redirects === 0) {
          websocket._originalIpc = isIpcUrl;
          websocket._originalSecure = isSecure;
          websocket._originalHostOrSocketPath = isIpcUrl ? opts.socketPath : parsedUrl.host;
          const headers = options && options.headers;
          options = { ...options, headers: {} };
          if (headers) {
            for (const [key2, value] of Object.entries(headers)) {
              options.headers[key2.toLowerCase()] = value;
            }
          }
        } else if (websocket.listenerCount("redirect") === 0) {
          const isSameHost = isIpcUrl ? websocket._originalIpc ? opts.socketPath === websocket._originalHostOrSocketPath : false : websocket._originalIpc ? false : parsedUrl.host === websocket._originalHostOrSocketPath;
          if (!isSameHost || websocket._originalSecure && !isSecure) {
            delete opts.headers.authorization;
            delete opts.headers.cookie;
            if (!isSameHost) delete opts.headers.host;
            opts.auth = void 0;
          }
        }
        if (opts.auth && !options.headers.authorization) {
          options.headers.authorization = "Basic " + Buffer.from(opts.auth).toString("base64");
        }
        req = websocket._req = request(opts);
        if (websocket._redirects) {
          websocket.emit("redirect", websocket.url, req);
        }
      } else {
        req = websocket._req = request(opts);
      }
      if (opts.timeout) {
        req.on("timeout", () => {
          abortHandshake(websocket, req, "Opening handshake has timed out");
        });
      }
      req.on("error", (err) => {
        if (req === null || req[kAborted]) return;
        req = websocket._req = null;
        emitErrorAndClose(websocket, err);
      });
      req.on("response", (res) => {
        const location = res.headers.location;
        const statusCode = res.statusCode;
        if (location && opts.followRedirects && statusCode >= 300 && statusCode < 400) {
          if (++websocket._redirects > opts.maxRedirects) {
            abortHandshake(websocket, req, "Maximum redirects exceeded");
            return;
          }
          req.abort();
          let addr;
          try {
            addr = new URL(location, address);
          } catch (e) {
            const err = new SyntaxError(`Invalid URL: ${location}`);
            emitErrorAndClose(websocket, err);
            return;
          }
          initAsClient(websocket, addr, protocols, options);
        } else if (!websocket.emit("unexpected-response", req, res)) {
          abortHandshake(
            websocket,
            req,
            `Unexpected server response: ${res.statusCode}`
          );
        }
      });
      req.on("upgrade", (res, socket, head) => {
        websocket.emit("upgrade", res);
        if (websocket.readyState !== WebSocket2.CONNECTING) return;
        req = websocket._req = null;
        const upgrade = res.headers.upgrade;
        if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
          abortHandshake(websocket, socket, "Invalid Upgrade header");
          return;
        }
        const digest = createHash("sha1").update(key + GUID).digest("base64");
        if (res.headers["sec-websocket-accept"] !== digest) {
          abortHandshake(websocket, socket, "Invalid Sec-WebSocket-Accept header");
          return;
        }
        const serverProt = res.headers["sec-websocket-protocol"];
        let protError;
        if (serverProt !== void 0) {
          if (!protocolSet.size) {
            protError = "Server sent a subprotocol but none was requested";
          } else if (!protocolSet.has(serverProt)) {
            protError = "Server sent an invalid subprotocol";
          }
        } else if (protocolSet.size) {
          protError = "Server sent no subprotocol";
        }
        if (protError) {
          abortHandshake(websocket, socket, protError);
          return;
        }
        if (serverProt) websocket._protocol = serverProt;
        const secWebSocketExtensions = res.headers["sec-websocket-extensions"];
        if (secWebSocketExtensions !== void 0) {
          if (!perMessageDeflate) {
            const message = "Server sent a Sec-WebSocket-Extensions header but no extension was requested";
            abortHandshake(websocket, socket, message);
            return;
          }
          let extensions;
          try {
            extensions = parse(secWebSocketExtensions);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Extensions header";
            abortHandshake(websocket, socket, message);
            return;
          }
          const extensionNames = Object.keys(extensions);
          if (extensionNames.length !== 1 || extensionNames[0] !== PerMessageDeflate.extensionName) {
            const message = "Server indicated an extension that was not requested";
            abortHandshake(websocket, socket, message);
            return;
          }
          try {
            perMessageDeflate.accept(extensions[PerMessageDeflate.extensionName]);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Extensions header";
            abortHandshake(websocket, socket, message);
            return;
          }
          websocket._extensions[PerMessageDeflate.extensionName] = perMessageDeflate;
        }
        websocket.setSocket(socket, head, {
          allowSynchronousEvents: opts.allowSynchronousEvents,
          generateMask: opts.generateMask,
          maxPayload: opts.maxPayload,
          skipUTF8Validation: opts.skipUTF8Validation
        });
      });
      if (opts.finishRequest) {
        opts.finishRequest(req, websocket);
      } else {
        req.end();
      }
    }
    function emitErrorAndClose(websocket, err) {
      websocket._readyState = WebSocket2.CLOSING;
      websocket._errorEmitted = true;
      websocket.emit("error", err);
      websocket.emitClose();
    }
    function netConnect(options) {
      options.path = options.socketPath;
      return net.connect(options);
    }
    function tlsConnect(options) {
      options.path = void 0;
      if (!options.servername && options.servername !== "") {
        options.servername = net.isIP(options.host) ? "" : options.host;
      }
      return tls.connect(options);
    }
    function abortHandshake(websocket, stream, message) {
      websocket._readyState = WebSocket2.CLOSING;
      const err = new Error(message);
      Error.captureStackTrace(err, abortHandshake);
      if (stream.setHeader) {
        stream[kAborted] = true;
        stream.abort();
        if (stream.socket && !stream.socket.destroyed) {
          stream.socket.destroy();
        }
        process.nextTick(emitErrorAndClose, websocket, err);
      } else {
        stream.destroy(err);
        stream.once("error", websocket.emit.bind(websocket, "error"));
        stream.once("close", websocket.emitClose.bind(websocket));
      }
    }
    function sendAfterClose(websocket, data, cb) {
      if (data) {
        const length = isBlob(data) ? data.size : toBuffer(data).length;
        if (websocket._socket) websocket._sender._bufferedBytes += length;
        else websocket._bufferedAmount += length;
      }
      if (cb) {
        const err = new Error(
          `WebSocket is not open: readyState ${websocket.readyState} (${readyStates[websocket.readyState]})`
        );
        process.nextTick(cb, err);
      }
    }
    function receiverOnConclude(code, reason) {
      const websocket = this[kWebSocket];
      websocket._closeFrameReceived = true;
      websocket._closeMessage = reason;
      websocket._closeCode = code;
      if (websocket._socket[kWebSocket] === void 0) return;
      websocket._socket.removeListener("data", socketOnData);
      process.nextTick(resume, websocket._socket);
      if (code === 1005) websocket.close();
      else websocket.close(code, reason);
    }
    function receiverOnDrain() {
      const websocket = this[kWebSocket];
      if (!websocket.isPaused) websocket._socket.resume();
    }
    function receiverOnError(err) {
      const websocket = this[kWebSocket];
      if (websocket._socket[kWebSocket] !== void 0) {
        websocket._socket.removeListener("data", socketOnData);
        process.nextTick(resume, websocket._socket);
        websocket.close(err[kStatusCode]);
      }
      if (!websocket._errorEmitted) {
        websocket._errorEmitted = true;
        websocket.emit("error", err);
      }
    }
    function receiverOnFinish() {
      this[kWebSocket].emitClose();
    }
    function receiverOnMessage(data, isBinary) {
      this[kWebSocket].emit("message", data, isBinary);
    }
    function receiverOnPing(data) {
      const websocket = this[kWebSocket];
      if (websocket._autoPong) websocket.pong(data, !this._isServer, NOOP);
      websocket.emit("ping", data);
    }
    function receiverOnPong(data) {
      this[kWebSocket].emit("pong", data);
    }
    function resume(stream) {
      stream.resume();
    }
    function senderOnError(err) {
      const websocket = this[kWebSocket];
      if (websocket.readyState === WebSocket2.CLOSED) return;
      if (websocket.readyState === WebSocket2.OPEN) {
        websocket._readyState = WebSocket2.CLOSING;
        setCloseTimer(websocket);
      }
      this._socket.end();
      if (!websocket._errorEmitted) {
        websocket._errorEmitted = true;
        websocket.emit("error", err);
      }
    }
    function setCloseTimer(websocket) {
      websocket._closeTimer = setTimeout(
        websocket._socket.destroy.bind(websocket._socket),
        closeTimeout
      );
    }
    function socketOnClose() {
      const websocket = this[kWebSocket];
      this.removeListener("close", socketOnClose);
      this.removeListener("data", socketOnData);
      this.removeListener("end", socketOnEnd);
      websocket._readyState = WebSocket2.CLOSING;
      let chunk;
      if (!this._readableState.endEmitted && !websocket._closeFrameReceived && !websocket._receiver._writableState.errorEmitted && (chunk = websocket._socket.read()) !== null) {
        websocket._receiver.write(chunk);
      }
      websocket._receiver.end();
      this[kWebSocket] = void 0;
      clearTimeout(websocket._closeTimer);
      if (websocket._receiver._writableState.finished || websocket._receiver._writableState.errorEmitted) {
        websocket.emitClose();
      } else {
        websocket._receiver.on("error", receiverOnFinish);
        websocket._receiver.on("finish", receiverOnFinish);
      }
    }
    function socketOnData(chunk) {
      if (!this[kWebSocket]._receiver.write(chunk)) {
        this.pause();
      }
    }
    function socketOnEnd() {
      const websocket = this[kWebSocket];
      websocket._readyState = WebSocket2.CLOSING;
      websocket._receiver.end();
      this.end();
    }
    function socketOnError() {
      const websocket = this[kWebSocket];
      this.removeListener("error", socketOnError);
      this.on("error", NOOP);
      if (websocket) {
        websocket._readyState = WebSocket2.CLOSING;
        this.destroy();
      }
    }
  }
});

// node_modules/ws/lib/stream.js
var require_stream = __commonJS({
  "node_modules/ws/lib/stream.js"(exports2, module2) {
    "use strict";
    var { Duplex } = require("stream");
    function emitClose(stream) {
      stream.emit("close");
    }
    function duplexOnEnd() {
      if (!this.destroyed && this._writableState.finished) {
        this.destroy();
      }
    }
    function duplexOnError(err) {
      this.removeListener("error", duplexOnError);
      this.destroy();
      if (this.listenerCount("error") === 0) {
        this.emit("error", err);
      }
    }
    function createWebSocketStream(ws, options) {
      let terminateOnDestroy = true;
      const duplex = new Duplex({
        ...options,
        autoDestroy: false,
        emitClose: false,
        objectMode: false,
        writableObjectMode: false
      });
      ws.on("message", function message(msg, isBinary) {
        const data = !isBinary && duplex._readableState.objectMode ? msg.toString() : msg;
        if (!duplex.push(data)) ws.pause();
      });
      ws.once("error", function error(err) {
        if (duplex.destroyed) return;
        terminateOnDestroy = false;
        duplex.destroy(err);
      });
      ws.once("close", function close() {
        if (duplex.destroyed) return;
        duplex.push(null);
      });
      duplex._destroy = function(err, callback) {
        if (ws.readyState === ws.CLOSED) {
          callback(err);
          process.nextTick(emitClose, duplex);
          return;
        }
        let called = false;
        ws.once("error", function error(err2) {
          called = true;
          callback(err2);
        });
        ws.once("close", function close() {
          if (!called) callback(err);
          process.nextTick(emitClose, duplex);
        });
        if (terminateOnDestroy) ws.terminate();
      };
      duplex._final = function(callback) {
        if (ws.readyState === ws.CONNECTING) {
          ws.once("open", function open() {
            duplex._final(callback);
          });
          return;
        }
        if (ws._socket === null) return;
        if (ws._socket._writableState.finished) {
          callback();
          if (duplex._readableState.endEmitted) duplex.destroy();
        } else {
          ws._socket.once("finish", function finish() {
            callback();
          });
          ws.close();
        }
      };
      duplex._read = function() {
        if (ws.isPaused) ws.resume();
      };
      duplex._write = function(chunk, encoding, callback) {
        if (ws.readyState === ws.CONNECTING) {
          ws.once("open", function open() {
            duplex._write(chunk, encoding, callback);
          });
          return;
        }
        ws.send(chunk, callback);
      };
      duplex.on("end", duplexOnEnd);
      duplex.on("error", duplexOnError);
      return duplex;
    }
    module2.exports = createWebSocketStream;
  }
});

// node_modules/ws/lib/subprotocol.js
var require_subprotocol = __commonJS({
  "node_modules/ws/lib/subprotocol.js"(exports2, module2) {
    "use strict";
    var { tokenChars } = require_validation();
    function parse(header) {
      const protocols = /* @__PURE__ */ new Set();
      let start = -1;
      let end = -1;
      let i = 0;
      for (i; i < header.length; i++) {
        const code = header.charCodeAt(i);
        if (end === -1 && tokenChars[code] === 1) {
          if (start === -1) start = i;
        } else if (i !== 0 && (code === 32 || code === 9)) {
          if (end === -1 && start !== -1) end = i;
        } else if (code === 44) {
          if (start === -1) {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
          if (end === -1) end = i;
          const protocol2 = header.slice(start, end);
          if (protocols.has(protocol2)) {
            throw new SyntaxError(`The "${protocol2}" subprotocol is duplicated`);
          }
          protocols.add(protocol2);
          start = end = -1;
        } else {
          throw new SyntaxError(`Unexpected character at index ${i}`);
        }
      }
      if (start === -1 || end !== -1) {
        throw new SyntaxError("Unexpected end of input");
      }
      const protocol = header.slice(start, i);
      if (protocols.has(protocol)) {
        throw new SyntaxError(`The "${protocol}" subprotocol is duplicated`);
      }
      protocols.add(protocol);
      return protocols;
    }
    module2.exports = { parse };
  }
});

// node_modules/ws/lib/websocket-server.js
var require_websocket_server = __commonJS({
  "node_modules/ws/lib/websocket-server.js"(exports2, module2) {
    "use strict";
    var EventEmitter = require("events");
    var http = require("http");
    var { Duplex } = require("stream");
    var { createHash } = require("crypto");
    var extension = require_extension();
    var PerMessageDeflate = require_permessage_deflate();
    var subprotocol = require_subprotocol();
    var WebSocket2 = require_websocket();
    var { GUID, kWebSocket } = require_constants();
    var keyRegex = /^[+/0-9A-Za-z]{22}==$/;
    var RUNNING = 0;
    var CLOSING = 1;
    var CLOSED = 2;
    var WebSocketServer = class extends EventEmitter {
      /**
       * Create a `WebSocketServer` instance.
       *
       * @param {Object} options Configuration options
       * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {Boolean} [options.autoPong=true] Specifies whether or not to
       *     automatically send a pong in response to a ping
       * @param {Number} [options.backlog=511] The maximum length of the queue of
       *     pending connections
       * @param {Boolean} [options.clientTracking=true] Specifies whether or not to
       *     track clients
       * @param {Function} [options.handleProtocols] A hook to handle protocols
       * @param {String} [options.host] The hostname where to bind the server
       * @param {Number} [options.maxPayload=104857600] The maximum allowed message
       *     size
       * @param {Boolean} [options.noServer=false] Enable no server mode
       * @param {String} [options.path] Accept only connections matching this path
       * @param {(Boolean|Object)} [options.perMessageDeflate=false] Enable/disable
       *     permessage-deflate
       * @param {Number} [options.port] The port where to bind the server
       * @param {(http.Server|https.Server)} [options.server] A pre-created HTTP/S
       *     server to use
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       * @param {Function} [options.verifyClient] A hook to reject connections
       * @param {Function} [options.WebSocket=WebSocket] Specifies the `WebSocket`
       *     class to use. It must be the `WebSocket` class or class that extends it
       * @param {Function} [callback] A listener for the `listening` event
       */
      constructor(options, callback) {
        super();
        options = {
          allowSynchronousEvents: true,
          autoPong: true,
          maxPayload: 100 * 1024 * 1024,
          skipUTF8Validation: false,
          perMessageDeflate: false,
          handleProtocols: null,
          clientTracking: true,
          verifyClient: null,
          noServer: false,
          backlog: null,
          // use default (511 as implemented in net.js)
          server: null,
          host: null,
          path: null,
          port: null,
          WebSocket: WebSocket2,
          ...options
        };
        if (options.port == null && !options.server && !options.noServer || options.port != null && (options.server || options.noServer) || options.server && options.noServer) {
          throw new TypeError(
            'One and only one of the "port", "server", or "noServer" options must be specified'
          );
        }
        if (options.port != null) {
          this._server = http.createServer((req, res) => {
            const body = http.STATUS_CODES[426];
            res.writeHead(426, {
              "Content-Length": body.length,
              "Content-Type": "text/plain"
            });
            res.end(body);
          });
          this._server.listen(
            options.port,
            options.host,
            options.backlog,
            callback
          );
        } else if (options.server) {
          this._server = options.server;
        }
        if (this._server) {
          const emitConnection = this.emit.bind(this, "connection");
          this._removeListeners = addListeners(this._server, {
            listening: this.emit.bind(this, "listening"),
            error: this.emit.bind(this, "error"),
            upgrade: (req, socket, head) => {
              this.handleUpgrade(req, socket, head, emitConnection);
            }
          });
        }
        if (options.perMessageDeflate === true) options.perMessageDeflate = {};
        if (options.clientTracking) {
          this.clients = /* @__PURE__ */ new Set();
          this._shouldEmitClose = false;
        }
        this.options = options;
        this._state = RUNNING;
      }
      /**
       * Returns the bound address, the address family name, and port of the server
       * as reported by the operating system if listening on an IP socket.
       * If the server is listening on a pipe or UNIX domain socket, the name is
       * returned as a string.
       *
       * @return {(Object|String|null)} The address of the server
       * @public
       */
      address() {
        if (this.options.noServer) {
          throw new Error('The server is operating in "noServer" mode');
        }
        if (!this._server) return null;
        return this._server.address();
      }
      /**
       * Stop the server from accepting new connections and emit the `'close'` event
       * when all existing connections are closed.
       *
       * @param {Function} [cb] A one-time listener for the `'close'` event
       * @public
       */
      close(cb) {
        if (this._state === CLOSED) {
          if (cb) {
            this.once("close", () => {
              cb(new Error("The server is not running"));
            });
          }
          process.nextTick(emitClose, this);
          return;
        }
        if (cb) this.once("close", cb);
        if (this._state === CLOSING) return;
        this._state = CLOSING;
        if (this.options.noServer || this.options.server) {
          if (this._server) {
            this._removeListeners();
            this._removeListeners = this._server = null;
          }
          if (this.clients) {
            if (!this.clients.size) {
              process.nextTick(emitClose, this);
            } else {
              this._shouldEmitClose = true;
            }
          } else {
            process.nextTick(emitClose, this);
          }
        } else {
          const server = this._server;
          this._removeListeners();
          this._removeListeners = this._server = null;
          server.close(() => {
            emitClose(this);
          });
        }
      }
      /**
       * See if a given request should be handled by this server instance.
       *
       * @param {http.IncomingMessage} req Request object to inspect
       * @return {Boolean} `true` if the request is valid, else `false`
       * @public
       */
      shouldHandle(req) {
        if (this.options.path) {
          const index = req.url.indexOf("?");
          const pathname = index !== -1 ? req.url.slice(0, index) : req.url;
          if (pathname !== this.options.path) return false;
        }
        return true;
      }
      /**
       * Handle a HTTP Upgrade request.
       *
       * @param {http.IncomingMessage} req The request object
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @public
       */
      handleUpgrade(req, socket, head, cb) {
        socket.on("error", socketOnError);
        const key = req.headers["sec-websocket-key"];
        const upgrade = req.headers.upgrade;
        const version = +req.headers["sec-websocket-version"];
        if (req.method !== "GET") {
          const message = "Invalid HTTP method";
          abortHandshakeOrEmitwsClientError(this, req, socket, 405, message);
          return;
        }
        if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
          const message = "Invalid Upgrade header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (key === void 0 || !keyRegex.test(key)) {
          const message = "Missing or invalid Sec-WebSocket-Key header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (version !== 8 && version !== 13) {
          const message = "Missing or invalid Sec-WebSocket-Version header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (!this.shouldHandle(req)) {
          abortHandshake(socket, 400);
          return;
        }
        const secWebSocketProtocol = req.headers["sec-websocket-protocol"];
        let protocols = /* @__PURE__ */ new Set();
        if (secWebSocketProtocol !== void 0) {
          try {
            protocols = subprotocol.parse(secWebSocketProtocol);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Protocol header";
            abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
            return;
          }
        }
        const secWebSocketExtensions = req.headers["sec-websocket-extensions"];
        const extensions = {};
        if (this.options.perMessageDeflate && secWebSocketExtensions !== void 0) {
          const perMessageDeflate = new PerMessageDeflate(
            this.options.perMessageDeflate,
            true,
            this.options.maxPayload
          );
          try {
            const offers = extension.parse(secWebSocketExtensions);
            if (offers[PerMessageDeflate.extensionName]) {
              perMessageDeflate.accept(offers[PerMessageDeflate.extensionName]);
              extensions[PerMessageDeflate.extensionName] = perMessageDeflate;
            }
          } catch (err) {
            const message = "Invalid or unacceptable Sec-WebSocket-Extensions header";
            abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
            return;
          }
        }
        if (this.options.verifyClient) {
          const info = {
            origin: req.headers[`${version === 8 ? "sec-websocket-origin" : "origin"}`],
            secure: !!(req.socket.authorized || req.socket.encrypted),
            req
          };
          if (this.options.verifyClient.length === 2) {
            this.options.verifyClient(info, (verified, code, message, headers) => {
              if (!verified) {
                return abortHandshake(socket, code || 401, message, headers);
              }
              this.completeUpgrade(
                extensions,
                key,
                protocols,
                req,
                socket,
                head,
                cb
              );
            });
            return;
          }
          if (!this.options.verifyClient(info)) return abortHandshake(socket, 401);
        }
        this.completeUpgrade(extensions, key, protocols, req, socket, head, cb);
      }
      /**
       * Upgrade the connection to WebSocket.
       *
       * @param {Object} extensions The accepted extensions
       * @param {String} key The value of the `Sec-WebSocket-Key` header
       * @param {Set} protocols The subprotocols
       * @param {http.IncomingMessage} req The request object
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @throws {Error} If called more than once with the same socket
       * @private
       */
      completeUpgrade(extensions, key, protocols, req, socket, head, cb) {
        if (!socket.readable || !socket.writable) return socket.destroy();
        if (socket[kWebSocket]) {
          throw new Error(
            "server.handleUpgrade() was called more than once with the same socket, possibly due to a misconfiguration"
          );
        }
        if (this._state > RUNNING) return abortHandshake(socket, 503);
        const digest = createHash("sha1").update(key + GUID).digest("base64");
        const headers = [
          "HTTP/1.1 101 Switching Protocols",
          "Upgrade: websocket",
          "Connection: Upgrade",
          `Sec-WebSocket-Accept: ${digest}`
        ];
        const ws = new this.options.WebSocket(null, void 0, this.options);
        if (protocols.size) {
          const protocol = this.options.handleProtocols ? this.options.handleProtocols(protocols, req) : protocols.values().next().value;
          if (protocol) {
            headers.push(`Sec-WebSocket-Protocol: ${protocol}`);
            ws._protocol = protocol;
          }
        }
        if (extensions[PerMessageDeflate.extensionName]) {
          const params = extensions[PerMessageDeflate.extensionName].params;
          const value = extension.format({
            [PerMessageDeflate.extensionName]: [params]
          });
          headers.push(`Sec-WebSocket-Extensions: ${value}`);
          ws._extensions = extensions;
        }
        this.emit("headers", headers, req);
        socket.write(headers.concat("\r\n").join("\r\n"));
        socket.removeListener("error", socketOnError);
        ws.setSocket(socket, head, {
          allowSynchronousEvents: this.options.allowSynchronousEvents,
          maxPayload: this.options.maxPayload,
          skipUTF8Validation: this.options.skipUTF8Validation
        });
        if (this.clients) {
          this.clients.add(ws);
          ws.on("close", () => {
            this.clients.delete(ws);
            if (this._shouldEmitClose && !this.clients.size) {
              process.nextTick(emitClose, this);
            }
          });
        }
        cb(ws, req);
      }
    };
    module2.exports = WebSocketServer;
    function addListeners(server, map) {
      for (const event of Object.keys(map)) server.on(event, map[event]);
      return function removeListeners() {
        for (const event of Object.keys(map)) {
          server.removeListener(event, map[event]);
        }
      };
    }
    function emitClose(server) {
      server._state = CLOSED;
      server.emit("close");
    }
    function socketOnError() {
      this.destroy();
    }
    function abortHandshake(socket, code, message, headers) {
      message = message || http.STATUS_CODES[code];
      headers = {
        Connection: "close",
        "Content-Type": "text/html",
        "Content-Length": Buffer.byteLength(message),
        ...headers
      };
      socket.once("finish", socket.destroy);
      socket.end(
        `HTTP/1.1 ${code} ${http.STATUS_CODES[code]}\r
` + Object.keys(headers).map((h) => `${h}: ${headers[h]}`).join("\r\n") + "\r\n\r\n" + message
      );
    }
    function abortHandshakeOrEmitwsClientError(server, req, socket, code, message) {
      if (server.listenerCount("wsClientError")) {
        const err = new Error(message);
        Error.captureStackTrace(err, abortHandshakeOrEmitwsClientError);
        server.emit("wsClientError", err, socket, req);
      } else {
        abortHandshake(socket, code, message);
      }
    }
  }
});

// node_modules/ws/index.js
var require_ws = __commonJS({
  "node_modules/ws/index.js"(exports2, module2) {
    "use strict";
    var WebSocket2 = require_websocket();
    WebSocket2.createWebSocketStream = require_stream();
    WebSocket2.Server = require_websocket_server();
    WebSocket2.Receiver = require_receiver();
    WebSocket2.Sender = require_sender();
    WebSocket2.WebSocket = WebSocket2;
    WebSocket2.WebSocketServer = WebSocket2.Server;
    module2.exports = WebSocket2;
  }
});

// src/layout.js
var require_layout = __commonJS({
  "src/layout.js"(exports2, module2) {
    "use strict";
    function realPosition2(coords) {
      const column = Number(coords && coords.column) || 0;
      const row = Number(coords && coords.row) || 0;
      if (column >= 5) return { col: column, row };
      const index = row * 5 + column;
      return { col: 4 - Math.floor(index / 3), row: index % 3 };
    }
    function reportedPosition(col, row) {
      if (col >= 5) return { column: col, row };
      const index = (4 - col) * 3 + row;
      return { column: index % 5, row: Math.floor(index / 5) };
    }
    function buildGroups2(keys2) {
      const groups = [];
      const zones = /* @__PURE__ */ new Map();
      for (const k of keys2) {
        if (k.solo) {
          groups.push({ keys: [{ context: k.context, dx: 0, dy: 0 }], w: 1, h: 1, anchor: k.context });
          continue;
        }
        const zone = `${k.device}|${k.col >= 5 ? "side" : "main"}|${k.joinKey}`;
        if (!zones.has(zone)) zones.set(zone, []);
        zones.get(zone).push(k);
      }
      for (const list of zones.values()) {
        const at = new Map(list.map((k) => [`${k.col},${k.row}`, k]));
        const used = /* @__PURE__ */ new Set();
        const sorted = [...list].sort((a, b) => a.row - b.row || a.col - b.col);
        for (const k of sorted) {
          if (used.has(k.context)) continue;
          const free = (c, rr) => {
            const o = at.get(`${c},${rr}`);
            return o && !used.has(o.context) ? o : null;
          };
          let w = 1;
          while (free(k.col + w, k.row)) w++;
          let h = 1;
          for (; ; ) {
            let ok = true;
            for (let i = 0; i < w; i++) if (!free(k.col + i, k.row + h)) {
              ok = false;
              break;
            }
            if (!ok) break;
            h++;
          }
          let h2 = 1;
          while (free(k.col, k.row + h2)) h2++;
          let w2 = 1;
          for (; ; ) {
            let ok = true;
            for (let j = 0; j < h2; j++) if (!free(k.col + w2, k.row + j)) {
              ok = false;
              break;
            }
            if (!ok) break;
            w2++;
          }
          if (w2 * h2 > w * h) {
            w = w2;
            h = h2;
          }
          const g = { keys: [], w, h, anchor: k.context };
          for (let j = 0; j < h; j++) {
            for (let i = 0; i < w; i++) {
              const o = at.get(`${k.col + i},${k.row + j}`);
              used.add(o.context);
              g.keys.push({ context: o.context, dx: i, dy: j });
            }
          }
          groups.push(g);
        }
      }
      return groups;
    }
    module2.exports = { realPosition: realPosition2, reportedPosition, buildGroups: buildGroups2 };
  }
});

// src/native/vitals.ps1
var require_vitals = __commonJS({
  "src/native/vitals.ps1"(exports2, module2) {
    module2.exports = `# System Vitals collector for the Ajazz / Stream Dock plugin.
#
# Started by the plugin with Windows PowerShell 5.1 (built into Windows).
# Compiles Vitals.cs once (cached as a DLL next to this script), then prints one
# JSON line per second to stdout. Reads commands from stdin, one per line:
#   need gpu=1 top=0 sensors=1     which optional readings are wanted
#   interval 1000                  milliseconds between samples
# Exits when the plugin closes stdin or the parent process is gone.

param(
    [int]$ParentPid = 0,
    [string]$CacheDir = ''
)

$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false)
try { [Console]::OutputEncoding = $utf8 } catch { }
try { [Console]::InputEncoding = $utf8 } catch { }
$out = [Console]::Out

function Emit([string]$line) {
    $out.WriteLine($line)
    $out.Flush()
}
function Say([string]$level, [string]$msg) {
    $m = $msg.Replace('\\', '\\\\').Replace('"', '\\"').Replace("\`r", ' ').Replace("\`n", ' ')
    Emit ('{"type":"log","level":"' + $level + '","msg":"' + $m + '"}')
}

# ---------------------------------------------------------------- compile
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $CacheDir) { $CacheDir = $here }
$srcPath = Join-Path $here 'Vitals.cs'
try {
    $src = [IO.File]::ReadAllText($srcPath)
} catch {
    Say 'error' ("Cannot read Vitals.cs: " + $_.Exception.Message)
    exit 2
}

$sha = [Security.Cryptography.SHA1]::Create()
$hash = -join ($sha.ComputeHash($utf8.GetBytes($src + [IntPtr]::Size + $PSVersionTable.PSVersion)) | Select-Object -First 6 | ForEach-Object { $_.ToString('x2') })
$dll = Join-Path $CacheDir ("SysVitals-" + $hash + ".dll")

$loaded = $false
$t0 = [Diagnostics.Stopwatch]::StartNew()
if (Test-Path -LiteralPath $dll) {
    try {
        Add-Type -LiteralPath $dll
        $loaded = $true
    } catch {
        Say 'warn' ("Cached collector could not load, rebuilding: " + $_.Exception.Message)
    }
}
if (-not $loaded) {
    # Remove stale builds from older versions.
    try {
        Get-ChildItem -LiteralPath $CacheDir -Filter 'SysVitals-*.dll' -ErrorAction SilentlyContinue |
            Where-Object { $_.FullName -ne $dll } |
            ForEach-Object { try { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction Stop } catch { } }
    } catch { }
    try {
        Add-Type -TypeDefinition $src -Language CSharp -OutputAssembly $dll -OutputType Library -IgnoreWarnings
        if (-not ('SysVitals.Collector' -as [type])) { Add-Type -LiteralPath $dll }
        $loaded = $true
    } catch {
        Say 'warn' ("Could not save the collector build, compiling in memory: " + $_.Exception.Message)
        try {
            Add-Type -TypeDefinition $src -Language CSharp -IgnoreWarnings
            $loaded = $true
        } catch {
            Say 'error' ("Collector failed to compile: " + $_.Exception.Message)
            exit 3
        }
    }
}
Say 'info' ("Collector ready in " + $t0.ElapsedMilliseconds + " ms (PowerShell " + $PSVersionTable.PSVersion + ", " + ([IntPtr]::Size * 8) + "-bit)")

$c = New-Object SysVitals.Collector

# ---------------------------------------------------------------- LibreHardwareMonitor / OpenHardwareMonitor
$extNext = [DateTime]::MinValue
$extFails = 0
$extWorking = ''
function Read-External {
    foreach ($ns in @('root/LibreHardwareMonitor', 'root/OpenHardwareMonitor')) {
        try {
            $hw = @(Get-CimInstance -Namespace $ns -ClassName Hardware -OperationTimeoutSec 2 -ErrorAction Stop)
            $sens = @(Get-CimInstance -Namespace $ns -ClassName Sensor -OperationTimeoutSec 2 -ErrorAction Stop)
            if ($sens.Count -eq 0) { continue }
            $name = if ($ns -like '*Libre*') { 'LibreHardwareMonitor' } else { 'OpenHardwareMonitor' }
            $c.BeginExternal($name)
            foreach ($h in $hw) { $c.AddExternalHardware([string]$h.Identifier, [string]$h.Name) }
            foreach ($s in $sens) {
                if ($null -eq $s.Value) { continue }
                $c.AddExternalSensor([string]$s.Identifier, [string]$s.Parent, [string]$s.Name, [string]$s.SensorType, [double]$s.Value)
            }
            $c.EndExternal()
            return $name
        } catch { }
    }
    return ''
}

# ---------------------------------------------------------------- main loop
# A plain StreamReader: Console.In's ReadLineAsync blocks until a line arrives.
$stdin = New-Object System.IO.StreamReader([Console]::OpenStandardInput(), $utf8)
$pending = $stdin.ReadLineAsync()
$n = 0
while ($true) {
    $sw = [Diagnostics.Stopwatch]::StartNew()

    # commands from the plugin
    $closed = $false
    while ($pending.IsCompleted) {
        if ($pending.IsFaulted) { $closed = $true; break }
        $line = $pending.Result
        if ($null -eq $line) { $closed = $true; break }
        if ($line.Trim() -eq 'quit') { $closed = $true; break }
        try { $c.Command($line) } catch { Say 'warn' ("Bad command: " + $line) }
        $pending = $stdin.ReadLineAsync()
    }
    if ($closed) { break }

    # sensors from LibreHardwareMonitor / OpenHardwareMonitor (only when a key wants them)
    if ($c.WantExternal -and [DateTime]::UtcNow -ge $extNext) {
        $got = Read-External
        if ($got) {
            $extFails = 0
            $extNext = [DateTime]::UtcNow.AddSeconds(2)
            $extWorking = $got
        } else {
            if ($extWorking) { Say 'info' ($extWorking + ' stopped sharing sensors'); $extWorking = ''; $c.ClearExternal() }
            $extFails++
            $extNext = [DateTime]::UtcNow.AddSeconds([Math]::Min(30, 5 * $extFails))
        }
    }

    try {
        foreach ($l in $c.Tick()) { Emit $l }
    } catch {
        Say 'warn' ("Sample failed: " + $_.Exception.Message)
    }

    $n++
    if ($ParentPid -gt 0 -and ($n % 5) -eq 0) {
        if (-not [SysVitals.Collector]::ProcessAlive($ParentPid)) { break }
    }

    $wait = $c.IntervalMs - [int]$sw.ElapsedMilliseconds
    if ($wait -gt 5) { Start-Sleep -Milliseconds $wait }
}
`;
  }
});

// src/native/Vitals.cs
var require_Vitals = __commonJS({
  "src/native/Vitals.cs"(exports2, module2) {
    module2.exports = `// System Vitals collector for the Ajazz / Stream Dock plugin.
//
// Compiled at runtime by Windows PowerShell 5.1 (Add-Type), so this file must
// stay within C# 5 and only use mscorlib + System.dll (no LINQ).
//
// Every source is optional and wrapped in try/catch: a PC without an NVIDIA
// or AMD card, without a battery, or with counters disabled still gets every
// other reading. Output is one JSON object per line.
//
// Sources (all built into Windows or the graphics driver, nothing installed):
//   PDH performance counters (English names, so any Windows language works)
//   D3DKMT (the same GPU data Task Manager shows, incl. temperature on WDDM 2.9+)
//   NVIDIA NVML (nvml.dll ships with the NVIDIA driver)
//   AMD ADL (atiadlxx.dll ships with the AMD driver)
//   HWiNFO shared memory, if the user runs HWiNFO with shared memory enabled
//   LibreHardwareMonitor / OpenHardwareMonitor WMI (read by the PowerShell side)

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace SysVitals
{
    // ------------------------------------------------------------------ JSON
    public class Json
    {
        private readonly StringBuilder b = new StringBuilder(4096);
        private readonly Stack<bool> first = new Stack<bool>();
        private bool afterKey;

        private void Sep()
        {
            if (afterKey) { afterKey = false; return; }
            if (first.Count == 0) return;
            if (first.Peek()) { first.Pop(); first.Push(false); }
            else b.Append(',');
        }
        private readonly Stack<char> closers = new Stack<char>();
        public Json O() { Sep(); b.Append('{'); first.Push(true); closers.Push('}'); return this; }
        public Json A() { Sep(); b.Append('['); first.Push(true); closers.Push(']'); return this; }
        public Json End() { b.Append(closers.Pop()); first.Pop(); return this; }
        // Appends ready-made JSON text as one value.
        public Json Raw(string json) { Sep(); b.Append(json); return this; }
        public Json K(string k) { Sep(); Esc(k); b.Append(':'); afterKey = true; return this; }
        public Json S(string s) { Sep(); if (s == null) b.Append("null"); else Esc(s); return this; }
        public Json N(double v)
        {
            Sep();
            if (double.IsNaN(v) || double.IsInfinity(v)) b.Append("null");
            else b.Append(v.ToString("0.###", CultureInfo.InvariantCulture));
            return this;
        }
        public Json B(bool v) { Sep(); b.Append(v ? "true" : "false"); return this; }
        public Json Null() { Sep(); b.Append("null"); return this; }
        public Json P(string k, string v) { return K(k).S(v); }
        public Json P(string k, double v) { return K(k).N(v); }
        public Json P(string k, bool v) { return K(k).B(v); }
        private void Esc(string s)
        {
            b.Append('"');
            foreach (char c in s)
            {
                switch (c)
                {
                    case '"': b.Append("\\\\\\""); break;
                    case '\\\\': b.Append("\\\\\\\\"); break;
                    case '\\n': b.Append("\\\\n"); break;
                    case '\\r': b.Append("\\\\r"); break;
                    case '\\t': b.Append("\\\\t"); break;
                    default:
                        if (c < 0x20) b.Append("\\\\u").Append(((int)c).ToString("x4"));
                        else b.Append(c);
                        break;
                }
            }
            b.Append('"');
        }
        public override string ToString() { return b.ToString(); }
    }

    // ------------------------------------------------------------------ Native helpers
    internal static class Native
    {
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern IntPtr LoadLibraryW(string path);
        [DllImport("kernel32.dll", CharSet = CharSet.Ansi, SetLastError = true)]
        public static extern IntPtr GetProcAddress(IntPtr module, string name);
        [DllImport("kernel32.dll")]
        public static extern ulong GetTickCount64();
        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX m);
        [DllImport("kernel32.dll")]
        public static extern bool GetSystemPowerStatus(out SYSTEM_POWER_STATUS s);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern IntPtr OpenFileMappingW(uint access, bool inherit, string name);
        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern IntPtr MapViewOfFile(IntPtr h, uint access, uint offHigh, uint offLow, UIntPtr bytes);
        [DllImport("kernel32.dll")]
        public static extern bool UnmapViewOfFile(IntPtr p);
        [DllImport("kernel32.dll")]
        public static extern bool CloseHandle(IntPtr h);

        [StructLayout(LayoutKind.Sequential)]
        public struct MEMORYSTATUSEX
        {
            public uint dwLength;
            public uint dwMemoryLoad;
            public ulong ullTotalPhys;
            public ulong ullAvailPhys;
            public ulong ullTotalPageFile;
            public ulong ullAvailPageFile;
            public ulong ullTotalVirtual;
            public ulong ullAvailVirtual;
            public ulong ullAvailExtendedVirtual;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct SYSTEM_POWER_STATUS
        {
            public byte ACLineStatus;
            public byte BatteryFlag;
            public byte BatteryLifePercent;
            public byte SystemStatusFlag;
            public int BatteryLifeTime;
            public int BatteryFullLifeTime;
        }

        public static T Fn<T>(IntPtr module, string name) where T : class
        {
            if (module == IntPtr.Zero) return null;
            IntPtr p = GetProcAddress(module, name);
            if (p == IntPtr.Zero) return null;
            return Marshal.GetDelegateForFunctionPointer(p, typeof(T)) as T;
        }

        public static IntPtr Alloc(int size)
        {
            IntPtr p = Marshal.AllocHGlobal(size);
            for (int i = 0; i < size; i++) Marshal.WriteByte(p, i, 0);
            return p;
        }
    }

    // ------------------------------------------------------------------ PDH (performance counters)
    internal class Pdh
    {
        [DllImport("pdh.dll", CharSet = CharSet.Unicode)]
        static extern uint PdhOpenQueryW(string source, IntPtr user, out IntPtr query);
        [DllImport("pdh.dll", CharSet = CharSet.Unicode)]
        static extern uint PdhAddEnglishCounterW(IntPtr query, string path, IntPtr user, out IntPtr counter);
        [DllImport("pdh.dll")]
        static extern uint PdhCollectQueryData(IntPtr query);
        [DllImport("pdh.dll", CharSet = CharSet.Unicode)]
        static extern uint PdhGetFormattedCounterArrayW(IntPtr counter, uint format, ref uint bufferSize, out uint itemCount, IntPtr buffer);
        [DllImport("pdh.dll")]
        static extern uint PdhCloseQuery(IntPtr query);

        const uint FMT = 0x200 | 0x8000; // PDH_FMT_DOUBLE | PDH_FMT_NOCAP100
        const uint PDH_MORE_DATA = 0x800007D2;

        private IntPtr query = IntPtr.Zero;
        private readonly Dictionary<string, IntPtr> counters = new Dictionary<string, IntPtr>();
        public readonly List<string> Failed = new List<string>();
        public int Collections;
        public readonly DateTime Created = DateTime.UtcNow;

        public Pdh(string[] defs)
        {
            uint st = PdhOpenQueryW(null, IntPtr.Zero, out query);
            if (st != 0) { query = IntPtr.Zero; throw new Exception("PdhOpenQuery failed 0x" + st.ToString("X8")); }
            for (int i = 0; i + 1 < defs.Length; i += 2)
            {
                IntPtr c;
                st = PdhAddEnglishCounterW(query, defs[i + 1], IntPtr.Zero, out c);
                if (st == 0) counters[defs[i]] = c;
                else Failed.Add(defs[i] + " 0x" + st.ToString("X8"));
            }
        }

        public bool Has(string name) { return counters.ContainsKey(name); }
        public int Count { get { return counters.Count; } }

        public void Collect()
        {
            if (query == IntPtr.Zero) return;
            PdhCollectQueryData(query);
            Collections++;
        }

        // Rate counters need two collections before they hold a value.
        public bool Warm { get { return Collections >= 2; } }

        public List<KeyValuePair<string, double>> Values(string name)
        {
            List<KeyValuePair<string, double>> list = new List<KeyValuePair<string, double>>();
            IntPtr c;
            if (query == IntPtr.Zero || !counters.TryGetValue(name, out c)) return list;
            uint size = 0, count = 0;
            uint st = PdhGetFormattedCounterArrayW(c, FMT, ref size, out count, IntPtr.Zero);
            if (st != PDH_MORE_DATA || size == 0) return list;
            IntPtr buf = Marshal.AllocHGlobal((int)size);
            try
            {
                st = PdhGetFormattedCounterArrayW(c, FMT, ref size, out count, buf);
                if (st != 0) return list;
                int ps = IntPtr.Size;
                int item = ps == 8 ? 24 : 16;
                int vOff = ps == 8 ? 16 : 8;
                for (int i = 0; i < count; i++)
                {
                    int off = i * item;
                    IntPtr namePtr = Marshal.ReadIntPtr(buf, off);
                    int cs = Marshal.ReadInt32(buf, off + ps);
                    if (cs != 0 && cs != 1) continue; // PDH_CSTATUS_VALID_DATA / NEW_DATA
                    double v = BitConverter.Int64BitsToDouble(Marshal.ReadInt64(buf, off + vOff));
                    string n = namePtr == IntPtr.Zero ? "" : Marshal.PtrToStringUni(namePtr);
                    list.Add(new KeyValuePair<string, double>(n ?? "", v));
                }
            }
            finally { Marshal.FreeHGlobal(buf); }
            return list;
        }

        public double Single(string name)
        {
            List<KeyValuePair<string, double>> l = Values(name);
            return l.Count > 0 ? l[0].Value : double.NaN;
        }

        public void Close()
        {
            if (query != IntPtr.Zero) PdhCloseQuery(query);
            query = IntPtr.Zero;
            counters.Clear();
        }
    }

    // ------------------------------------------------------------------ Data holders
    public class GpuInfo
    {
        public string Id;          // LUID "HIGH_LOW" in hex, matches the counter instance names
        public string Name = "";
        public string Vendor = "";  // nvidia / amd / intel / other
        public int Bus = -1;
        public bool Integrated;
        public double DedTotal = double.NaN;
        public double ShrTotal = double.NaN;
        public uint Handle;         // D3DKMT adapter handle (kept open while enumerated)
        public bool PerfOk = true;

        // latest readings
        public double Util = double.NaN, Ded = double.NaN, Shr = double.NaN;
        public double Temp = double.NaN, Hot = double.NaN, MemTemp = double.NaN;
        public double Power = double.NaN, PowerLimit = double.NaN, PowerPct = double.NaN;
        public double Fan = double.NaN, FanPct = double.NaN, Clock = double.NaN, MemClock = double.NaN;
        public string TempSrc = "";
        public void ClearSensors()
        {
            Temp = Hot = MemTemp = Power = PowerLimit = PowerPct = Fan = FanPct = Clock = MemClock = double.NaN;
            TempSrc = "";
        }
    }

    public class NetState
    {
        public string Id, Name, Desc, Kind;
        public bool Up, Virt, Gw;
        public double Speed;
        public string Ip = "";
        public long LastRx = -1, LastTx = -1;
        public double Rx = double.NaN, Tx = double.NaN;
        public bool Seen;
    }

    public class SensorReading
    {
        public string Id, Hw, Name, Type, Unit;
        public double Value;
    }

    // ------------------------------------------------------------------ Collector
    public class Collector
    {
        private Pdh main, gpuQ, procQ;
        private readonly List<string> outLines = new List<string>();
        private readonly HashSet<string> loggedOnce = new HashSet<string>();
        private readonly Stopwatch clock = Stopwatch.StartNew();
        private long tick;

        // demand flags (set by the plugin from what the keys show)
        public bool NeedGpu = true, NeedTop, NeedSensors;
        public bool UseHwinfo = true, UseWmi = true; // which sensor apps to read (from the Setup key)
        public int IntervalMs = 1000;

        // static info
        private string cpuName = "", cpuVendor = "";
        private double baseMhz = double.NaN;
        private int threads = Environment.ProcessorCount;
        private bool useUtility = true;

        private readonly List<GpuInfo> gpus = new List<GpuInfo>();
        private DateTime gpuEnumAt = DateTime.MinValue;
        private bool kmtOk = true;
        private readonly Dictionary<string, NetState> nets = new Dictionary<string, NetState>();
        private long netLastMs = -1;
        private DateTime netPropsAt = DateTime.MinValue;
        private List<string[]> vols = new List<string[]>();
        private DateTime volsAt = DateTime.MinValue;
        private bool infoDirty = true;

        private readonly Dictionary<string, double> lastTop = new Dictionary<string, double>();
        private string topJson = null;
        private string sensorsJson = null;
        private DateTime sensorsAt = DateTime.MinValue;

        public Collector()
        {
            ReadCpuInfo();
        }

        // ---------------- logging
        private void Log(string level, string msg)
        {
            Json j = new Json();
            j.O().P("type", "log").P("level", level).P("msg", msg).End();
            outLines.Add(j.ToString());
        }
        private void LogOnce(string key, string level, string msg)
        {
            if (loggedOnce.Contains(key)) return;
            loggedOnce.Add(key);
            Log(level, msg);
        }
        public static string LogLine(string level, string msg)
        {
            Json j = new Json();
            j.O().P("type", "log").P("level", level).P("msg", msg).End();
            return j.ToString();
        }

        // ---------------- commands from the plugin, e.g. "need gpu=1 top=0 sensors=1"
        public void Command(string line)
        {
            if (string.IsNullOrEmpty(line)) return;
            string[] parts = line.Trim().Split(' ');
            if (parts.Length == 0) return;
            if (parts[0] == "need")
            {
                for (int i = 1; i < parts.Length; i++)
                {
                    string[] kv = parts[i].Split('=');
                    if (kv.Length != 2) continue;
                    bool on = kv[1] == "1" || kv[1] == "true";
                    if (kv[0] == "gpu") NeedGpu = on;
                    else if (kv[0] == "top") NeedTop = on;
                    else if (kv[0] == "sensors") NeedSensors = on;
                    else if (kv[0] == "hwinfo") UseHwinfo = on;
                    else if (kv[0] == "wmi") UseWmi = on;
                }
                if (!NeedTop) { if (procQ != null) procQ.Close(); if (procNext != null) procNext.Close(); procQ = null; procNext = null; topJson = null; }
                if (!NeedSensors || !UseHwinfo) CloseHwinfo();
                if (!NeedSensors) sensorsJson = null;
            }
            else if (parts[0] == "interval" && parts.Length > 1)
            {
                int ms;
                if (int.TryParse(parts[1], out ms)) IntervalMs = Math.Max(250, Math.Min(10000, ms));
            }
        }

        // ---------------- CPU static info
        private void ReadCpuInfo()
        {
            try
            {
                using (RegistryKey k = Registry.LocalMachine.OpenSubKey(@"HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0"))
                {
                    if (k != null)
                    {
                        object n = k.GetValue("ProcessorNameString");
                        if (n != null) cpuName = Regex.Replace(n.ToString().Trim(), @"\\s+", " ");
                        object m = k.GetValue("~MHz");
                        if (m != null) baseMhz = Convert.ToDouble(m, CultureInfo.InvariantCulture);
                        object v = k.GetValue("VendorIdentifier");
                        string vs = v == null ? "" : v.ToString();
                        if (vs.IndexOf("AMD", StringComparison.OrdinalIgnoreCase) >= 0) cpuVendor = "amd";
                        else if (vs.IndexOf("Intel", StringComparison.OrdinalIgnoreCase) >= 0) cpuVendor = "intel";
                        else if (vs.Length > 0) cpuVendor = vs.ToLowerInvariant();
                    }
                }
            }
            catch (Exception e) { Log("warn", "CPU info: " + e.Message); }
            if (cpuVendor == "" && cpuName.IndexOf("Snapdragon", StringComparison.OrdinalIgnoreCase) >= 0) cpuVendor = "qualcomm";
        }

        // ---------------- PDH queries
        private void OpenMain()
        {
            if (main != null) main.Close();
            main = null;
            try
            {
                main = new Pdh(new string[] {
                    "util", @"\\Processor Information(*)\\% Processor Utility",
                    "perf", @"\\Processor Information(_Total)\\% Processor Performance",
                    "ptime", @"\\Processor(*)\\% Processor Time",
                    "didle", @"\\PhysicalDisk(*)\\% Idle Time",
                    "drd", @"\\PhysicalDisk(*)\\Disk Read Bytes/sec",
                    "dwr", @"\\PhysicalDisk(*)\\Disk Write Bytes/sec",
                    "procs", @"\\System\\Processes",
                    "threads", @"\\System\\Threads",
                    "therm", @"\\Thermal Zone Information(*)\\Temperature"
                });
                useUtility = main.Has("util");
                if (main.Failed.Count > 0) LogOnce("pdhmain:" + string.Join(",", main.Failed.ToArray()), "info", "Counters not available on this PC: " + string.Join(", ", main.Failed.ToArray()));
                main.Collect();
            }
            catch (Exception e) { LogOnce("pdhmain", "error", "Performance counters failed: " + e.Message); main = null; }
        }

        private void OpenGpuQuery()
        {
            if (gpuQ != null) gpuQ.Close();
            gpuQ = null;
            try
            {
                gpuQ = new Pdh(new string[] {
                    "eng", @"\\GPU Engine(*)\\Utilization Percentage",
                    "ded", @"\\GPU Adapter Memory(*)\\Dedicated Usage",
                    "shr", @"\\GPU Adapter Memory(*)\\Shared Usage"
                });
                if (gpuQ.Failed.Count > 0) LogOnce("pdhgpu", "info", "GPU counters not available: " + string.Join(", ", gpuQ.Failed.ToArray()));
                gpuQ.Collect();
            }
            catch (Exception e) { LogOnce("pdhgpu2", "warn", "GPU counters failed: " + e.Message); gpuQ = null; }
        }

        private void OpenProcQuery()
        {
            if (procQ != null) procQ.Close();
            procQ = null;
            try
            {
                procQ = new Pdh(new string[] {
                    "cpu", @"\\Process(*)\\% Processor Time",
                    "mem", @"\\Process(*)\\Working Set - Private"
                });
                procQ.Collect();
            }
            catch (Exception e) { LogOnce("pdhproc", "warn", "Process counters failed: " + e.Message); procQ = null; }
        }

        // ---------------- main entry: one sample
        public string[] Tick()
        {
            tick++;
            try
            {
                if (main == null || (DateTime.UtcNow - main.Created).TotalMinutes > 30) OpenMain();
                else main.Collect();
            }
            catch (Exception e) { LogOnce("collect", "warn", "Collect failed: " + e.Message); }

            if (NeedGpu)
            {
                try
                {
                    // The GPU engine list changes as apps start and stop; rebuilding the
                    // query now and then keeps new apps counted.
                    if (gpuQ == null || (DateTime.UtcNow - gpuQ.Created).TotalSeconds > 30) { GpuQueryFlip(); }
                    else gpuQ.Collect();
                }
                catch (Exception e) { LogOnce("gpuq", "warn", "GPU counters: " + e.Message); }
                if (gpus.Count == 0 || (DateTime.UtcNow - gpuEnumAt).TotalMinutes > 5) EnumGpus();
            }
            else if (gpus.Count == 0 && gpuEnumAt == DateTime.MinValue) EnumGpus();

            if (NeedTop)
            {
                try
                {
                    if (procQ == null || (DateTime.UtcNow - procQ.Created).TotalSeconds > 30) ProcQueryFlip();
                    else procQ.Collect();
                }
                catch (Exception e) { LogOnce("procq", "warn", "Process counters: " + e.Message); }
            }

            if (infoDirty) { outLines.Add(InfoJson()); infoDirty = false; }

            Json j = new Json();
            j.O().P("type", "sample").P("ms", (double)clock.ElapsedMilliseconds);
            Safe(j, "cpu", WriteCpu);
            Safe(j, "mem", WriteMem);
            if (NeedGpu) Safe(j, "gpu", WriteGpus);
            Safe(j, "disk", WriteDisks);
            Safe(j, "vol", WriteVols);
            Safe(j, "net", WriteNets);
            Safe(j, "sys", WriteSys);
            Safe(j, "bat", WriteBattery);
            if (NeedTop) Safe(j, "top", WriteTop);
            if (NeedSensors) Safe(j, "sensors", WriteSensors);
            if (NeedSensors) Safe(j, "apps", WriteApps);
            j.End();
            outLines.Add(j.ToString());

            string[] res = outLines.ToArray();
            outLines.Clear();
            return res;
        }

        // A rebuilt query needs a second collection before rates exist; keep the old
        // query running until the new one is warm.
        private Pdh gpuNext, procNext;
        private void GpuQueryFlip()
        {
            if (gpuQ == null) { OpenGpuQuery(); return; }
            gpuQ.Collect();
            if (gpuNext == null)
            {
                Pdh keep = gpuQ; gpuQ = null; OpenGpuQuery(); gpuNext = gpuQ; gpuQ = keep;
                return;
            }
            gpuNext.Collect();
            if (gpuNext.Warm) { gpuQ.Close(); gpuQ = gpuNext; gpuNext = null; }
        }
        private void ProcQueryFlip()
        {
            if (procQ == null) { OpenProcQuery(); return; }
            procQ.Collect();
            if (procNext == null)
            {
                Pdh keep = procQ; procQ = null; OpenProcQuery(); procNext = procQ; procQ = keep;
                return;
            }
            procNext.Collect();
            if (procNext.Warm) { procQ.Close(); procQ = procNext; procNext = null; }
        }

        // Each section writes into its own buffer so a failure halfway through
        // cannot leave broken JSON behind.
        private delegate void Part(Json j);
        private void Safe(Json parent, string name, Part s)
        {
            try
            {
                Json part = new Json();
                s(part);
                string text = part.ToString();
                if (text.Length > 0) parent.Raw(text);
            }
            catch (Exception e) { LogOnce("sec:" + name + ":" + e.GetType().Name, "warn", "Reading " + name + " failed: " + e.GetType().Name + ": " + e.Message); }
        }

        // ---------------- info
        private string InfoJson()
        {
            Json j = new Json();
            j.O().P("type", "info");
            j.K("cpu").O().P("name", cpuName).P("vendor", cpuVendor).P("threads", threads).P("baseMhz", baseMhz).End();
            j.K("gpus").A();
            foreach (GpuInfo g in gpus)
            {
                j.O().P("id", g.Id).P("name", g.Name).P("vendor", g.Vendor).P("bus", g.Bus).P("integrated", g.Integrated)
                    .P("dedTotal", g.DedTotal).P("shrTotal", g.ShrTotal).End();
            }
            j.End();
            Native.MEMORYSTATUSEX m = new Native.MEMORYSTATUSEX();
            m.dwLength = (uint)Marshal.SizeOf(typeof(Native.MEMORYSTATUSEX));
            double total = double.NaN;
            try { if (Native.GlobalMemoryStatusEx(ref m)) total = m.ullTotalPhys; } catch { }
            j.P("memTotal", total);
            j.K("sources").O().P("pdh", main != null).P("kmt", kmtOk).P("nvml", nvmlState).P("adl", adlState).End();
            j.P("os", Environment.OSVersion.VersionString).P("x64", IntPtr.Size == 8);
            j.End();
            return j.ToString();
        }

        // ---------------- CPU
        private void WriteCpu(Json j)
        {
            j.K("cpu").O();
            if (main != null && main.Warm)
            {
                List<KeyValuePair<string, double>> vals = main.Values(useUtility ? "util" : "ptime");
                if (vals.Count == 0 && useUtility) { vals = main.Values("ptime"); }
                double total = double.NaN;
                List<long> keys = new List<long>();
                Dictionary<long, double> cores = new Dictionary<long, double>();
                foreach (KeyValuePair<string, double> kv in vals)
                {
                    string n = kv.Key;
                    if (n == "_Total") { total = kv.Value; continue; }
                    if (n.IndexOf("_Total", StringComparison.Ordinal) >= 0) continue;
                    long key;
                    int comma = n.IndexOf(',');
                    if (comma > 0)
                    {
                        int g, i;
                        if (!int.TryParse(n.Substring(0, comma), out g) || !int.TryParse(n.Substring(comma + 1), out i)) continue;
                        key = (long)g * 65536L + i;
                    }
                    else
                    {
                        int i;
                        if (!int.TryParse(n, out i)) continue;
                        key = i;
                    }
                    if (!cores.ContainsKey(key)) keys.Add(key);
                    cores[key] = kv.Value;
                }
                keys.Sort();
                if (keys.Count > 0 && keys.Count != threads) { threads = keys.Count; infoDirty = true; }
                j.P("load", Clamp100(total));
                j.K("cores").A();
                foreach (long k in keys) j.N(Math.Round(Clamp100(cores[k]), 1));
                j.End();
                double perf = main.Single("perf");
                j.P("perf", perf);
                if (!double.IsNaN(perf) && !double.IsNaN(baseMhz)) j.P("mhz", Math.Round(baseMhz * perf / 100.0));
            }
            j.End();
        }

        private static double Clamp100(double v)
        {
            if (double.IsNaN(v)) return v;
            return Math.Max(0, Math.Min(100, v));
        }

        // ---------------- memory
        private void WriteMem(Json j)
        {
            Native.MEMORYSTATUSEX m = new Native.MEMORYSTATUSEX();
            m.dwLength = (uint)Marshal.SizeOf(typeof(Native.MEMORYSTATUSEX));
            if (!Native.GlobalMemoryStatusEx(ref m)) return;
            j.K("mem").O()
                .P("total", (double)m.ullTotalPhys)
                .P("avail", (double)m.ullAvailPhys)
                .P("commitLimit", (double)m.ullTotalPageFile)
                .P("commit", (double)(m.ullTotalPageFile - m.ullAvailPageFile))
                .End();
        }

        // ---------------- GPUs: D3DKMT enumeration (names, LUIDs, memory size, temperature)
        [StructLayout(LayoutKind.Sequential)]
        struct LUID { public uint Low; public int High; }
        [StructLayout(LayoutKind.Sequential)]
        struct D3DKMT_ENUMADAPTERS2 { public uint NumAdapters; public IntPtr pAdapters; }
        [StructLayout(LayoutKind.Sequential)]
        struct D3DKMT_QUERYADAPTERINFO { public uint hAdapter; public int Type; public IntPtr pData; public uint DataSize; }
        [StructLayout(LayoutKind.Sequential)]
        struct D3DKMT_CLOSEADAPTER { public uint hAdapter; }

        [DllImport("gdi32.dll")] static extern int D3DKMTEnumAdapters2(ref D3DKMT_ENUMADAPTERS2 p);
        [DllImport("gdi32.dll")] static extern int D3DKMTQueryAdapterInfo(ref D3DKMT_QUERYADAPTERINFO p);
        [DllImport("gdi32.dll")] static extern int D3DKMTCloseAdapter(ref D3DKMT_CLOSEADAPTER p);

        const int KMTQAITYPE_GETSEGMENTSIZE = 3, KMTQAITYPE_ADAPTERADDRESS = 6, KMTQAITYPE_ADAPTERREGISTRYINFO = 8,
            KMTQAITYPE_ADAPTERTYPE = 15, KMTQAITYPE_PHYSICALADAPTERDEVICEIDS = 31, KMTQAITYPE_ADAPTERPERFDATA = 62;

        private static int KmtQuery(uint h, int type, IntPtr buf, int size)
        {
            D3DKMT_QUERYADAPTERINFO q = new D3DKMT_QUERYADAPTERINFO();
            q.hAdapter = h; q.Type = type; q.pData = buf; q.DataSize = (uint)size;
            return D3DKMTQueryAdapterInfo(ref q);
        }

        private void CloseGpuHandles()
        {
            foreach (GpuInfo g in gpus)
            {
                if (g.Handle == 0) continue;
                try { D3DKMT_CLOSEADAPTER c = new D3DKMT_CLOSEADAPTER(); c.hAdapter = g.Handle; D3DKMTCloseAdapter(ref c); } catch { }
                g.Handle = 0;
            }
        }

        private void EnumGpus()
        {
            gpuEnumAt = DateTime.UtcNow;
            Dictionary<string, GpuInfo> old = new Dictionary<string, GpuInfo>();
            foreach (GpuInfo g in gpus) old[g.Id] = g;
            string before = GpuSignature();
            CloseGpuHandles();
            gpus.Clear();
            try
            {
                D3DKMT_ENUMADAPTERS2 e = new D3DKMT_ENUMADAPTERS2();
                int st = D3DKMTEnumAdapters2(ref e);
                if (st != 0 || e.NumAdapters == 0) { LogOnce("kmtenum" + st, "info", "Graphics adapter list unavailable (status 0x" + st.ToString("X8") + ")"); kmtOk = false; return; }
                int itemSize = 20;
                IntPtr arr = Native.Alloc(itemSize * (int)e.NumAdapters);
                try
                {
                    e.pAdapters = arr;
                    st = D3DKMTEnumAdapters2(ref e);
                    if (st != 0) { LogOnce("kmtenum2" + st, "info", "Graphics adapter list failed (0x" + st.ToString("X8") + ")"); kmtOk = false; return; }
                    for (int i = 0; i < e.NumAdapters; i++)
                    {
                        int off = i * itemSize;
                        uint h = (uint)Marshal.ReadInt32(arr, off);
                        uint low = (uint)Marshal.ReadInt32(arr, off + 4);
                        int high = Marshal.ReadInt32(arr, off + 8);
                        GpuInfo g = ReadAdapter(h, ((uint)high).ToString("X8") + "_" + low.ToString("X8"));
                        if (g == null)
                        {
                            D3DKMT_CLOSEADAPTER c = new D3DKMT_CLOSEADAPTER(); c.hAdapter = h; D3DKMTCloseAdapter(ref c);
                            continue;
                        }
                        GpuInfo prev;
                        if (old.TryGetValue(g.Id, out prev)) { g.PerfOk = prev.PerfOk; }
                        gpus.Add(g);
                    }
                }
                finally { Marshal.FreeHGlobal(arr); }
                kmtOk = true;
            }
            catch (EntryPointNotFoundException) { kmtOk = false; LogOnce("kmtep", "info", "This Windows version has no D3DKMTEnumAdapters2"); }
            catch (DllNotFoundException) { kmtOk = false; LogOnce("kmtdll", "info", "gdi32 not available"); }
            catch (Exception ex) { kmtOk = false; LogOnce("kmtex", "warn", "Graphics adapter list: " + ex.Message); }

            // Fall back to the counters' adapter list (names unknown) when D3DKMT is missing.
            if (gpus.Count == 0 && gpuQ != null)
            {
                foreach (KeyValuePair<string, double> kv in gpuQ.Values("ded"))
                {
                    string id = LuidFromInstance(kv.Key);
                    if (id == null) continue;
                    bool dup = false;
                    foreach (GpuInfo x in gpus) if (x.Id == id) dup = true;
                    if (dup) continue;
                    GpuInfo g = new GpuInfo(); g.Id = id; g.Name = "GPU " + (gpus.Count + 1); g.Vendor = "other";
                    gpus.Add(g);
                }
            }
            if (GpuSignature() != before)
            {
                infoDirty = true;
                foreach (GpuInfo g in gpus)
                    Log("info", "GPU found: " + g.Name + " (" + g.Vendor + (g.Integrated ? ", integrated" : "") + ", bus " + g.Bus + ", " + Math.Round(g.DedTotal / 1048576.0) + " MB)");
            }
        }

        private string GpuSignature()
        {
            StringBuilder sb = new StringBuilder();
            foreach (GpuInfo g in gpus) sb.Append(g.Id).Append('|').Append(g.Name).Append(';');
            return sb.ToString();
        }

        private GpuInfo ReadAdapter(uint h, string id)
        {
            GpuInfo g = new GpuInfo();
            g.Id = id;
            g.Handle = h;
            IntPtr buf = Native.Alloc(2200);
            try
            {
                uint flags = 0;
                if (KmtQuery(h, KMTQAITYPE_ADAPTERTYPE, buf, 4) == 0) flags = (uint)Marshal.ReadInt32(buf);
                bool render = (flags & 1) != 0, software = (flags & 4) != 0, indirect = (flags & 64) != 0;
                if (flags != 0 && (!render || software || indirect)) return null;
                g.Integrated = (flags & 32) != 0; // HybridIntegrated

                if (KmtQuery(h, KMTQAITYPE_ADAPTERREGISTRYINFO, buf, 2080) == 0)
                    g.Name = (Marshal.PtrToStringUni(buf) ?? "").Trim();
                if (g.Name.IndexOf("Microsoft Basic", StringComparison.OrdinalIgnoreCase) >= 0) return null;
                if (g.Name.IndexOf("Remote Display", StringComparison.OrdinalIgnoreCase) >= 0) return null;

                for (int i = 0; i < 32; i++) Marshal.WriteByte(buf, i, 0);
                if (KmtQuery(h, KMTQAITYPE_ADAPTERADDRESS, buf, 12) == 0) g.Bus = Marshal.ReadInt32(buf);

                for (int i = 0; i < 32; i++) Marshal.WriteByte(buf, i, 0);
                if (KmtQuery(h, KMTQAITYPE_GETSEGMENTSIZE, buf, 24) == 0)
                {
                    g.DedTotal = (double)(ulong)Marshal.ReadInt64(buf, 0);
                    g.ShrTotal = (double)(ulong)Marshal.ReadInt64(buf, 16);
                }

                int vendorId = 0;
                for (int i = 0; i < 32; i++) Marshal.WriteByte(buf, i, 0);
                if (KmtQuery(h, KMTQAITYPE_PHYSICALADAPTERDEVICEIDS, buf, 28) == 0) vendorId = Marshal.ReadInt32(buf, 4);
                string n = g.Name;
                if (vendorId == 0x10DE || n.IndexOf("NVIDIA", StringComparison.OrdinalIgnoreCase) >= 0) g.Vendor = "nvidia";
                else if (vendorId == 0x1002 || vendorId == 0x1022 || Regex.IsMatch(n, @"\\b(AMD|Radeon|ATI)\\b", RegexOptions.IgnoreCase)) g.Vendor = "amd";
                else if (vendorId == 0x8086 || n.IndexOf("Intel", StringComparison.OrdinalIgnoreCase) >= 0) g.Vendor = "intel";
                else if (n.IndexOf("Qualcomm", StringComparison.OrdinalIgnoreCase) >= 0 || n.IndexOf("Adreno", StringComparison.OrdinalIgnoreCase) >= 0) g.Vendor = "qualcomm";
                else g.Vendor = "other";
                if (vendorId == 0x1414) return null; // Microsoft software / virtual adapters

                if (!g.Integrated && !double.IsNaN(g.DedTotal) && g.DedTotal < 1.1 * 1073741824.0 && g.Vendor != "nvidia") g.Integrated = true;
                if (g.Name == "") g.Name = "GPU";
            }
            finally { Marshal.FreeHGlobal(buf); }
            return g;
        }

        private static string LuidFromInstance(string inst)
        {
            Match m = Regex.Match(inst, @"luid_0x([0-9A-Fa-f]{8})_0x([0-9A-Fa-f]{8})");
            if (!m.Success) return null;
            return m.Groups[1].Value.ToUpperInvariant() + "_" + m.Groups[2].Value.ToUpperInvariant();
        }

        private static readonly Regex EngRx = new Regex(@"luid_0x([0-9A-Fa-f]{8})_0x([0-9A-Fa-f]{8})_phys_(\\d+)_eng_(\\d+)", RegexOptions.Compiled);

        private void WriteGpus(Json j)
        {
            // utilisation: sum each engine over all processes, then take the busiest engine (like Task Manager)
            Dictionary<string, double> engines = new Dictionary<string, double>();
            Dictionary<string, double> ded = new Dictionary<string, double>();
            Dictionary<string, double> shr = new Dictionary<string, double>();
            bool haveCounters = gpuQ != null && gpuQ.Warm;
            if (haveCounters)
            {
                foreach (KeyValuePair<string, double> kv in gpuQ.Values("eng"))
                {
                    Match m = EngRx.Match(kv.Key);
                    if (!m.Success) continue;
                    string key = m.Groups[1].Value.ToUpperInvariant() + "_" + m.Groups[2].Value.ToUpperInvariant() + "|" + m.Groups[3].Value + "|" + m.Groups[4].Value;
                    double cur;
                    engines.TryGetValue(key, out cur);
                    engines[key] = cur + kv.Value;
                }
                foreach (KeyValuePair<string, double> kv in gpuQ.Values("ded"))
                {
                    string id = LuidFromInstance(kv.Key); if (id == null) continue;
                    double cur; ded.TryGetValue(id, out cur); ded[id] = cur + kv.Value;
                }
                foreach (KeyValuePair<string, double> kv in gpuQ.Values("shr"))
                {
                    string id = LuidFromInstance(kv.Key); if (id == null) continue;
                    double cur; shr.TryGetValue(id, out cur); shr[id] = cur + kv.Value;
                }
            }

            foreach (GpuInfo g in gpus)
            {
                if (haveCounters)
                {
                    double best = 0; bool any = false;
                    foreach (KeyValuePair<string, double> kv in engines)
                    {
                        if (!kv.Key.StartsWith(g.Id + "|", StringComparison.Ordinal)) continue;
                        any = true;
                        if (kv.Value > best) best = kv.Value;
                    }
                    g.Util = any ? Clamp100(best) : (ded.ContainsKey(g.Id) ? 0 : double.NaN);
                    double v;
                    g.Ded = ded.TryGetValue(g.Id, out v) ? v : double.NaN;
                    g.Shr = shr.TryGetValue(g.Id, out v) ? v : double.NaN;
                }
                g.ClearSensors();
            }

            ReadNvml();
            ReadAdl();
            ReadKmtPerf();

            j.K("gpus").A();
            foreach (GpuInfo g in gpus)
            {
                j.O().P("id", g.Id).P("util", g.Util).P("ded", g.Ded).P("shr", g.Shr)
                    .P("temp", g.Temp).P("hot", g.Hot).P("memTemp", g.MemTemp)
                    .P("power", g.Power).P("powerLimit", g.PowerLimit).P("powerPct", g.PowerPct)
                    .P("fan", g.Fan).P("fanPct", g.FanPct).P("clock", g.Clock).P("memClock", g.MemClock)
                    .P("src", g.TempSrc).End();
            }
            j.End();
        }

        private void ReadKmtPerf()
        {
            if (!kmtOk) return;
            IntPtr buf = Native.Alloc(64);
            try
            {
                foreach (GpuInfo g in gpus)
                {
                    if (g.Handle == 0 || !g.PerfOk) continue;
                    if (!double.IsNaN(g.Temp) && !double.IsNaN(g.Fan)) continue; // the driver library already gave us everything
                    for (int i = 0; i < 64; i++) Marshal.WriteByte(buf, i, 0);
                    int st = KmtQuery(g.Handle, KMTQAITYPE_ADAPTERPERFDATA, buf, 64);
                    if (st != 0)
                    {
                        g.PerfOk = false;
                        LogOnce("kmtperf:" + g.Id, "info", "Windows has no temperature for " + g.Name + " (driver too old or not supported, 0x" + st.ToString("X8") + ")");
                        continue;
                    }
                    uint fan = (uint)Marshal.ReadInt32(buf, 48);
                    uint power = (uint)Marshal.ReadInt32(buf, 52);
                    uint temp = (uint)Marshal.ReadInt32(buf, 56);
                    if (double.IsNaN(g.Temp) && temp > 0 && temp < 1500) { g.Temp = temp / 10.0; g.TempSrc = "windows"; }
                    if (double.IsNaN(g.Fan) && fan > 0 && fan < 20000) g.Fan = fan;
                    if (double.IsNaN(g.PowerPct) && power > 0 && power <= 2000) g.PowerPct = power / 10.0;
                    ulong memHz = (ulong)Marshal.ReadInt64(buf, 8);
                    if (double.IsNaN(g.MemClock) && memHz > 0) g.MemClock = memHz / 1000000.0;
                }
            }
            catch (Exception e) { LogOnce("kmtperfex", "warn", "GPU temperature (Windows): " + e.Message); }
            finally { Marshal.FreeHGlobal(buf); }
        }

        // ---------------- NVIDIA NVML
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int NvVoid();
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int NvOutU(out uint v);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int NvHandle(uint index, out IntPtr dev);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int NvDevU(IntPtr dev, out uint v);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int NvDevArgU(IntPtr dev, int arg, out uint v);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int NvDevBuf(IntPtr dev, IntPtr buf);

        private string nvmlState = "not tried";
        private bool nvmlTried;
        private NvDevU nvPower, nvFan, nvLimit;
        private NvDevArgU nvTemp, nvClock;
        private NvDevBuf nvPci;
        private readonly List<KeyValuePair<IntPtr, int>> nvDevices = new List<KeyValuePair<IntPtr, int>>(); // handle, bus

        private bool HasVendor(string v)
        {
            foreach (GpuInfo g in gpus) if (g.Vendor == v) return true;
            return false;
        }

        private void InitNvml()
        {
            nvmlTried = true;
            IntPtr mod = Native.LoadLibraryW("nvml.dll");
            if (mod == IntPtr.Zero)
            {
                string pf = Environment.GetEnvironmentVariable("ProgramW6432") ?? Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
                string p = Path.Combine(pf, @"NVIDIA Corporation\\NVSMI\\nvml.dll");
                if (File.Exists(p)) mod = Native.LoadLibraryW(p);
            }
            if (mod == IntPtr.Zero)
            {
                try
                {
                    string repo = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), @"DriverStore\\FileRepository");
                    foreach (string d in Directory.GetDirectories(repo, "nv*"))
                    {
                        string p = Path.Combine(d, "nvml.dll");
                        if (File.Exists(p)) { mod = Native.LoadLibraryW(p); if (mod != IntPtr.Zero) break; }
                    }
                }
                catch { }
            }
            if (mod == IntPtr.Zero) { nvmlState = "missing"; Log("info", "NVIDIA driver library (nvml.dll) not found"); return; }
            NvVoid init = Native.Fn<NvVoid>(mod, "nvmlInit_v2") ?? Native.Fn<NvVoid>(mod, "nvmlInit");
            NvOutU count = Native.Fn<NvOutU>(mod, "nvmlDeviceGetCount_v2") ?? Native.Fn<NvOutU>(mod, "nvmlDeviceGetCount");
            NvHandle byIndex = Native.Fn<NvHandle>(mod, "nvmlDeviceGetHandleByIndex_v2") ?? Native.Fn<NvHandle>(mod, "nvmlDeviceGetHandleByIndex");
            nvTemp = Native.Fn<NvDevArgU>(mod, "nvmlDeviceGetTemperature");
            nvClock = Native.Fn<NvDevArgU>(mod, "nvmlDeviceGetClockInfo");
            nvPower = Native.Fn<NvDevU>(mod, "nvmlDeviceGetPowerUsage");
            nvLimit = Native.Fn<NvDevU>(mod, "nvmlDeviceGetEnforcedPowerLimit");
            nvFan = Native.Fn<NvDevU>(mod, "nvmlDeviceGetFanSpeed");
            nvPci = Native.Fn<NvDevBuf>(mod, "nvmlDeviceGetPciInfo_v3") ?? Native.Fn<NvDevBuf>(mod, "nvmlDeviceGetPciInfo_v2") ?? Native.Fn<NvDevBuf>(mod, "nvmlDeviceGetPciInfo");
            if (init == null || count == null || byIndex == null) { nvmlState = "error"; Log("warn", "NVIDIA driver library is missing functions"); return; }
            int st = init();
            if (st != 0) { nvmlState = "error"; Log("warn", "NVIDIA driver library did not start (code " + st + ")"); return; }
            uint n;
            if (count(out n) != 0) n = 0;
            IntPtr pci = Native.Alloc(128);
            try
            {
                for (uint i = 0; i < n; i++)
                {
                    IntPtr dev;
                    if (byIndex(i, out dev) != 0) continue;
                    int bus = -1;
                    if (nvPci != null)
                    {
                        for (int b = 0; b < 128; b++) Marshal.WriteByte(pci, b, 0);
                        if (nvPci(dev, pci) == 0) bus = Marshal.ReadInt32(pci, 20);
                    }
                    nvDevices.Add(new KeyValuePair<IntPtr, int>(dev, bus));
                }
            }
            finally { Marshal.FreeHGlobal(pci); }
            nvmlState = "ok";
            infoDirty = true;
            Log("info", "NVIDIA driver library ready: " + nvDevices.Count + " GPU(s)");
        }

        private void ReadNvml()
        {
            if (!HasVendor("nvidia")) return;
            if (!nvmlTried) { try { InitNvml(); } catch (Exception e) { nvmlState = "error"; Log("warn", "NVIDIA driver library: " + e.Message); } }
            if (nvmlState != "ok") return;
            int idx = 0;
            foreach (GpuInfo g in gpus)
            {
                if (g.Vendor != "nvidia") continue;
                IntPtr dev = IntPtr.Zero;
                foreach (KeyValuePair<IntPtr, int> d in nvDevices) if (d.Value >= 0 && d.Value == g.Bus) dev = d.Key;
                if (dev == IntPtr.Zero && idx < nvDevices.Count) dev = nvDevices[idx].Key;
                idx++;
                if (dev == IntPtr.Zero) continue;
                uint v;
                try
                {
                    if (nvTemp != null && nvTemp(dev, 0, out v) == 0 && v > 0 && v < 150) { g.Temp = v; g.TempSrc = "nvidia"; }
                    if (nvPower != null && nvPower(dev, out v) == 0) g.Power = v / 1000.0;
                    if (nvLimit != null && nvLimit(dev, out v) == 0 && v > 0) g.PowerLimit = v / 1000.0;
                    if (nvFan != null && nvFan(dev, out v) == 0 && v <= 100) g.FanPct = v;
                    if (nvClock != null && nvClock(dev, 0, out v) == 0 && v > 0) g.Clock = v;
                    if (nvClock != null && nvClock(dev, 2, out v) == 0 && v > 0) g.MemClock = v;
                    if (!double.IsNaN(g.Power) && !double.IsNaN(g.PowerLimit) && g.PowerLimit > 0) g.PowerPct = g.Power / g.PowerLimit * 100;
                }
                catch (Exception e) { LogOnce("nvread", "warn", "NVIDIA reading: " + e.Message); }
            }
        }

        // ---------------- AMD ADL
        [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate IntPtr AdlAllocCb(int size);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int AdlCreate(AdlAllocCb cb, int connectedOnly, out IntPtr ctx);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int AdlCtxOut(IntPtr ctx, out int v);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int AdlCtxBuf(IntPtr ctx, IntPtr buf, int size);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int AdlCaps(IntPtr ctx, int idx, out int supported, out int enabled, out int version);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int AdlIdxBuf(IntPtr ctx, int idx, IntPtr buf);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int AdlIdxArgOut(IntPtr ctx, int idx, int arg, out int v);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int AdlIdxArgBuf(IntPtr ctx, int idx, int arg, IntPtr buf);

        private static AdlAllocCb adlAlloc; // kept alive for the lifetime of the process
        private static IntPtr AdlAllocImpl(int size) { return Marshal.AllocCoTaskMem(size); }
        private string adlState = "not tried";
        private bool adlTried;
        private IntPtr adlCtx;
        private AdlIdxBuf adlPmLog;
        private AdlIdxArgOut adlOdnTemp;
        private AdlIdxArgBuf adlOd5Temp;
        private class AdlGpu { public int Index; public int Bus; public int OdVersion; public bool PmOk = true; public bool Listed; }
        // CPU readings the AMD driver may offer (documented for Ryzen chips with built-in graphics)
        private double adlCpuTemp = double.NaN, adlCpuPower = double.NaN, adlCpuClock = double.NaN;
        private long adlReadTick = -1;
        private static readonly string[] PmNames = {
            "", "GFX clock", "Mem clock", "SoC clock", "UVD1 clock", "UVD2 clock", "VCE clock", "VCN clock",
            "Edge temp", "Mem temp", "VDDC VR temp", "MVDD VR temp", "Liquid temp", "PLX temp", "Fan RPM", "Fan %",
            "SoC volt", "SoC power", "SoC current", "GFX activity", "Mem activity", "GFX volt", "Mem volt", "ASIC power",
            "SoC VR temp", "MVDD0 VR temp", "MVDD1 VR temp", "Hotspot temp", "GFX temp", "SoC temp", "GFX power", "GFX current",
            "CPU temp", "CPU power", "CPU clock" };
        private readonly List<AdlGpu> adlGpus = new List<AdlGpu>();

        private void InitAdl()
        {
            adlTried = true;
            IntPtr mod = Native.LoadLibraryW(IntPtr.Size == 8 ? "atiadlxx.dll" : "atiadlxy.dll");
            if (mod == IntPtr.Zero) mod = Native.LoadLibraryW("atiadlxx.dll");
            if (mod == IntPtr.Zero) { adlState = "missing"; Log("info", "AMD driver library (atiadlxx.dll) not found"); return; }
            AdlCreate create = Native.Fn<AdlCreate>(mod, "ADL2_Main_Control_Create");
            AdlCtxOut numAdapters = Native.Fn<AdlCtxOut>(mod, "ADL2_Adapter_NumberOfAdapters_Get");
            AdlCtxBuf adapterInfo = Native.Fn<AdlCtxBuf>(mod, "ADL2_Adapter_AdapterInfo_Get");
            AdlCaps caps = Native.Fn<AdlCaps>(mod, "ADL2_Overdrive_Caps");
            adlPmLog = Native.Fn<AdlIdxBuf>(mod, "ADL2_New_QueryPMLogData_Get");
            adlOdnTemp = Native.Fn<AdlIdxArgOut>(mod, "ADL2_OverdriveN_Temperature_Get");
            adlOd5Temp = Native.Fn<AdlIdxArgBuf>(mod, "ADL2_Overdrive5_Temperature_Get");
            if (create == null || numAdapters == null || adapterInfo == null) { adlState = "error"; Log("warn", "AMD driver library is missing functions"); return; }
            adlAlloc = new AdlAllocCb(AdlAllocImpl);
            int st = create(adlAlloc, 1, out adlCtx);
            if (st != 0) { adlState = "error"; Log("warn", "AMD driver library did not start (code " + st + ")"); return; }
            int n;
            if (numAdapters(adlCtx, out n) != 0 || n <= 0) { adlState = "error"; Log("info", "AMD driver library found no adapters"); return; }
            const int infoSize = 1572;
            IntPtr buf = Native.Alloc(infoSize * n);
            try
            {
                for (int i = 0; i < n; i++) Marshal.WriteInt32(buf, i * infoSize, infoSize);
                st = adapterInfo(adlCtx, buf, infoSize * n);
                if (st != 0) { adlState = "error"; Log("warn", "AMD adapter info failed (code " + st + ")"); return; }
                HashSet<int> buses = new HashSet<int>();
                for (int i = 0; i < n; i++)
                {
                    int off = i * infoSize;
                    int index = Marshal.ReadInt32(buf, off + 4);
                    int bus = Marshal.ReadInt32(buf, off + 264);
                    int vendor = Marshal.ReadInt32(buf, off + 276);
                    int present = Marshal.ReadInt32(buf, off + 792);
                    if (vendor != 1002 && vendor != 0x1002) continue;
                    if (present == 0 || buses.Contains(bus)) continue;
                    buses.Add(bus);
                    AdlGpu a = new AdlGpu(); a.Index = index; a.Bus = bus;
                    if (caps != null)
                    {
                        int sup, en, ver;
                        if (caps(adlCtx, index, out sup, out en, out ver) == 0) a.OdVersion = ver;
                    }
                    adlGpus.Add(a);
                }
            }
            finally { Marshal.FreeHGlobal(buf); }
            adlState = adlGpus.Count > 0 ? "ok" : "error";
            infoDirty = true;
            Log("info", "AMD driver library ready: " + adlGpus.Count + " GPU(s)");
        }

        private void ReadAdl()
        {
            if (!HasVendor("amd")) return;
            if (!adlTried) { try { InitAdl(); } catch (Exception e) { adlState = "error"; Log("warn", "AMD driver library: " + e.Message); } }
            if (adlState != "ok") return;
            if (adlReadTick == tick) return;
            adlReadTick = tick;
            adlCpuTemp = adlCpuPower = adlCpuClock = double.NaN;
            const int pmSize = 4 + 256 * 8;
            IntPtr buf = Native.Alloc(pmSize);
            try
            {
                int idx = 0;
                foreach (GpuInfo g in gpus)
                {
                    if (g.Vendor != "amd") continue;
                    AdlGpu a = null;
                    foreach (AdlGpu x in adlGpus) if (g.Bus >= 0 && x.Bus == g.Bus) a = x;
                    if (a == null && idx < adlGpus.Count) a = adlGpus[idx];
                    idx++;
                    if (a == null) continue;

                    bool got = false;
                    if (adlPmLog != null && a.PmOk)
                    {
                        for (int i = 0; i < pmSize; i++) Marshal.WriteByte(buf, i, 0);
                        Marshal.WriteInt32(buf, 0, pmSize);
                        if (adlPmLog(adlCtx, a.Index, buf) == 0)
                        {
                            got = true;
                            if (!a.Listed) { a.Listed = true; ListPmSensors(g, buf); }
                            double ct = Sensor(buf, 32); if (Ok(ct, 1, 125)) adlCpuTemp = ct;
                            double cp = Sensor(buf, 33); if (Ok(cp, 0.1, 1000)) adlCpuPower = cp;
                            double cc = Sensor(buf, 34); if (Ok(cc, 100, 10000)) adlCpuClock = cc;
                            double t = Sensor(buf, 8); if (double.IsNaN(t)) t = Sensor(buf, 28); if (double.IsNaN(t)) t = Sensor(buf, 50);
                            if (Ok(t, 1, 150)) { g.Temp = t; g.TempSrc = "amd"; }
                            double hot = Sensor(buf, 27); if (double.IsNaN(hot)) hot = Sensor(buf, 50);
                            if (Ok(hot, 1, 150)) g.Hot = hot;
                            double mt = Sensor(buf, 9); if (Ok(mt, 1, 150)) g.MemTemp = mt;
                            double p = Sensor(buf, 73); if (double.IsNaN(p) || p <= 0) p = Sensor(buf, 23); if (double.IsNaN(p) || p <= 0) p = Sensor(buf, 30); if (double.IsNaN(p) || p <= 0) p = Sensor(buf, 17);
                            if (Ok(p, 0, 2000)) g.Power = p;
                            double rpm = Sensor(buf, 14); if (Ok(rpm, 0, 20000)) g.Fan = rpm;
                            double fp = Sensor(buf, 15); if (Ok(fp, 0, 100)) g.FanPct = fp;
                            double c = Sensor(buf, 1); if (Ok(c, 1, 10000)) g.Clock = c;
                            double mc = Sensor(buf, 2); if (Ok(mc, 1, 30000)) g.MemClock = mc;
                        }
                        else a.PmOk = false;
                    }
                    if (!got)
                    {
                        int v;
                        if (adlOdnTemp != null && adlOdnTemp(adlCtx, a.Index, 1, out v) == 0 && v > 0)
                        {
                            double t = v > 1000 ? v / 1000.0 : v;
                            if (Ok(t, 1, 150)) { g.Temp = t; g.TempSrc = "amd"; }
                        }
                        else if (adlOd5Temp != null)
                        {
                            for (int i = 0; i < 8; i++) Marshal.WriteByte(buf, i, 0);
                            Marshal.WriteInt32(buf, 0, 8);
                            if (adlOd5Temp(adlCtx, a.Index, 0, buf) == 0)
                            {
                                double t = Marshal.ReadInt32(buf, 4) / 1000.0;
                                if (Ok(t, 1, 150)) { g.Temp = t; g.TempSrc = "amd"; }
                            }
                        }
                    }
                }
            }
            catch (Exception e) { LogOnce("adlread", "warn", "AMD reading: " + e.Message); }
            finally { Marshal.FreeHGlobal(buf); }
        }

        private static double Sensor(IntPtr buf, int index)
        {
            int off = 4 + index * 8;
            if (Marshal.ReadInt32(buf, off) == 0) return double.NaN;
            return Marshal.ReadInt32(buf, off + 4);
        }
        private static bool Ok(double v, double lo, double hi) { return !double.IsNaN(v) && v >= lo && v <= hi; }

        // Writes every reading the AMD driver offers for this card to the log (once).
        private void ListPmSensors(GpuInfo g, IntPtr buf)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 1; i < 256; i++)
            {
                double v = Sensor(buf, i);
                if (double.IsNaN(v)) continue;
                if (sb.Length > 0) sb.Append(", ");
                sb.Append(i).Append(i < PmNames.Length && PmNames[i] != "" ? " " + PmNames[i] : "").Append('=').Append(v.ToString(CultureInfo.InvariantCulture));
            }
            Log("info", "AMD driver readings for " + g.Name + ": " + (sb.Length > 0 ? sb.ToString() : "none"));
            bool cpu = !double.IsNaN(Sensor(buf, 32)) || !double.IsNaN(Sensor(buf, 33));
            Log("info", cpu ? "AMD driver offers CPU readings" : "AMD driver offers no CPU temperature or power on this PC");
        }

        // ---------------- disks
        private void WriteDisks(Json j)
        {
            if (main == null || !main.Warm) return;
            Dictionary<string, double[]> d = new Dictionary<string, double[]>();
            List<string> order = new List<string>();
            string[] names = { "didle", "drd", "dwr" };
            for (int c = 0; c < 3; c++)
            {
                foreach (KeyValuePair<string, double> kv in main.Values(names[c]))
                {
                    double[] a;
                    if (!d.TryGetValue(kv.Key, out a)) { a = new double[] { double.NaN, double.NaN, double.NaN }; d[kv.Key] = a; order.Add(kv.Key); }
                    a[c] = kv.Value;
                }
            }
            j.K("disks").A();
            foreach (string n in order)
            {
                double[] a = d[n];
                j.O().P("id", n).P("act", double.IsNaN(a[0]) ? double.NaN : Clamp100(100 - a[0])).P("rd", a[1]).P("wr", a[2]).End();
            }
            j.End();
        }

        private void WriteVols(Json j)
        {
            if ((DateTime.UtcNow - volsAt).TotalSeconds >= 10)
            {
                volsAt = DateTime.UtcNow;
                List<string[]> list = new List<string[]>();
                foreach (DriveInfo di in DriveInfo.GetDrives())
                {
                    try
                    {
                        if (di.DriveType != DriveType.Fixed && di.DriveType != DriveType.Removable) continue;
                        if (!di.IsReady) continue;
                        string id = di.Name.TrimEnd('\\\\');
                        list.Add(new string[] {
                            id, di.VolumeLabel ?? "", di.DriveType.ToString(),
                            di.TotalSize.ToString(CultureInfo.InvariantCulture),
                            di.AvailableFreeSpace.ToString(CultureInfo.InvariantCulture) });
                    }
                    catch { }
                }
                vols = list;
            }
            j.K("vols").A();
            foreach (string[] v in vols)
                j.O().P("id", v[0]).P("label", v[1]).P("kind", v[2]).P("total", double.Parse(v[3], CultureInfo.InvariantCulture)).P("free", double.Parse(v[4], CultureInfo.InvariantCulture)).End();
            j.End();
        }

        // ---------------- network
        private static readonly Regex VirtRx = new Regex(@"Hyper-V|vEthernet|VirtualBox|VMware|Virtual|Loopback|TAP-|TAP\\b|Npcap|WireGuard|Tailscale|ZeroTier|OpenVPN|Wintun|WAN Miniport|Bluetooth|Teredo|isatap|Pseudo|Kernel Debug|VPN|Docker|WSL", RegexOptions.IgnoreCase | RegexOptions.Compiled);

        private void WriteNets(Json j)
        {
            long now = clock.ElapsedMilliseconds;
            double dt = netLastMs < 0 ? 0 : (now - netLastMs) / 1000.0;
            netLastMs = now;
            bool props = (DateTime.UtcNow - netPropsAt).TotalSeconds >= 10;
            if (props) netPropsAt = DateTime.UtcNow;
            foreach (NetState s in nets.Values) s.Seen = false;
            foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                NetworkInterfaceType t = ni.NetworkInterfaceType;
                if (t == NetworkInterfaceType.Loopback || t == NetworkInterfaceType.Tunnel) continue;
                NetState s;
                if (!nets.TryGetValue(ni.Id, out s)) { s = new NetState(); s.Id = ni.Id; nets[ni.Id] = s; props = true; }
                s.Seen = true;
                s.Name = ni.Name; s.Desc = ni.Description; s.Kind = t.ToString();
                s.Up = ni.OperationalStatus == OperationalStatus.Up;
                s.Virt = VirtRx.IsMatch(ni.Description + " " + ni.Name);
                try { s.Speed = ni.Speed; } catch { s.Speed = -1; }
                long rx = -1, tx = -1;
                try
                {
                    IPInterfaceStatistics st = ni.GetIPStatistics();
                    rx = st.BytesReceived; tx = st.BytesSent;
                }
                catch
                {
                    try { IPv4InterfaceStatistics st4 = ni.GetIPv4Statistics(); rx = st4.BytesReceived; tx = st4.BytesSent; } catch { }
                }
                if (rx >= 0 && s.LastRx >= 0 && dt > 0.05)
                {
                    s.Rx = Math.Max(0, (rx - s.LastRx) / dt);
                    s.Tx = Math.Max(0, (tx - s.LastTx) / dt);
                }
                else if (!s.Up) { s.Rx = 0; s.Tx = 0; }
                s.LastRx = rx; s.LastTx = tx;
                if (props)
                {
                    try
                    {
                        IPInterfaceProperties p = ni.GetIPProperties();
                        string ip = "";
                        foreach (UnicastIPAddressInformation a in p.UnicastAddresses)
                        {
                            if (a.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork) { ip = a.Address.ToString(); break; }
                        }
                        s.Ip = ip;
                        bool gw = false;
                        foreach (GatewayIPAddressInformation g in p.GatewayAddresses)
                        {
                            string gs = g.Address.ToString();
                            if (gs != "0.0.0.0" && gs != "::") gw = true;
                        }
                        s.Gw = gw;
                    }
                    catch { }
                }
            }
            j.K("nets").A();
            foreach (NetState s in nets.Values)
            {
                if (!s.Seen) continue;
                j.O().P("id", s.Id).P("name", s.Name).P("desc", s.Desc).P("kind", s.Kind).P("up", s.Up)
                    .P("speed", s.Speed).P("rx", s.Rx).P("tx", s.Tx).P("ip", s.Ip).P("gw", s.Gw).P("virt", s.Virt).End();
            }
            j.End();
        }

        // ---------------- system
        private readonly Dictionary<string, double> thermFirst = new Dictionary<string, double>();
        private void WriteSys(Json j)
        {
            j.K("sys").O().P("up", Native.GetTickCount64() / 1000.0);
            if (main != null && main.Warm)
            {
                j.P("procs", main.Single("procs")).P("threads", main.Single("threads"));
                // ACPI thermal zones: many desktops report a fixed fake value, so a zone
                // is only offered after its reading has changed at least once.
                j.K("therm").A();
                foreach (KeyValuePair<string, double> kv in main.Values("therm"))
                {
                    double c = kv.Value - 273.15;
                    if (c < 5 || c > 125) continue;
                    double f;
                    if (!thermFirst.TryGetValue(kv.Key, out f)) { thermFirst[kv.Key] = c; f = c; }
                    bool live = Math.Abs(f - c) > 0.01 || double.IsNaN(f);
                    if (live) thermFirst[kv.Key] = double.NaN;
                    j.O().P("id", kv.Key).P("c", Math.Round(c, 1)).P("live", live).End();
                }
                j.End();
            }
            j.End();
        }

        private void WriteBattery(Json j)
        {
            Native.SYSTEM_POWER_STATUS s;
            if (!Native.GetSystemPowerStatus(out s)) return;
            if (s.BatteryFlag == 128 || s.BatteryFlag == 255 || s.BatteryLifePercent > 100) { j.K("bat").Null(); return; }
            j.K("bat").O().P("pct", (double)s.BatteryLifePercent).P("ac", s.ACLineStatus == 1)
                .P("charging", (s.BatteryFlag & 8) != 0).P("secs", s.BatteryLifeTime >= 0 ? (double)s.BatteryLifeTime : double.NaN).End();
        }

        // ---------------- busiest apps
        private void WriteTop(Json j)
        {
            if (procQ == null || !procQ.Warm) { if (topJson != null) { j.K("top"); RawAppend(j, topJson); } return; }
            Dictionary<string, double> cpu = new Dictionary<string, double>();
            Dictionary<string, double> mem = new Dictionary<string, double>();
            foreach (KeyValuePair<string, double> kv in procQ.Values("cpu"))
            {
                string n = BaseName(kv.Key);
                if (n == "_Total" || n == "Idle" || n == "") continue;
                double c; cpu.TryGetValue(n, out c); cpu[n] = c + kv.Value;
            }
            foreach (KeyValuePair<string, double> kv in procQ.Values("mem"))
            {
                string n = BaseName(kv.Key);
                if (n == "_Total" || n == "Idle" || n == "") continue;
                double c; mem.TryGetValue(n, out c); mem[n] = c + kv.Value;
            }
            int th = Math.Max(1, threads);
            Json t = new Json();
            t.O();
            t.K("cpu").A();
            foreach (KeyValuePair<string, double> kv in Top(cpu, 5)) t.A().S(kv.Key).N(Math.Round(Clamp100(kv.Value / th), 1)).End();
            t.End();
            t.K("mem").A();
            foreach (KeyValuePair<string, double> kv in Top(mem, 5)) t.A().S(kv.Key).N(kv.Value).End();
            t.End();
            t.End();
            topJson = t.ToString();
            j.K("top"); RawAppend(j, topJson);
        }

        private static string BaseName(string n)
        {
            int h = n.LastIndexOf('#');
            if (h > 0) n = n.Substring(0, h);
            return n;
        }

        private static List<KeyValuePair<string, double>> Top(Dictionary<string, double> d, int n)
        {
            List<KeyValuePair<string, double>> l = new List<KeyValuePair<string, double>>(d);
            l.Sort(delegate (KeyValuePair<string, double> a, KeyValuePair<string, double> b) { return b.Value.CompareTo(a.Value); });
            if (l.Count > n) l.RemoveRange(n, l.Count - n);
            return l;
        }

        private static void RawAppend(Json j, string raw) { j.Raw(raw); }

        // ---------------- external sensors (HWiNFO shared memory, LHM/OHM via PowerShell)
        private readonly List<SensorReading> external = new List<SensorReading>();
        private readonly List<SensorReading> externalNext = new List<SensorReading>();
        private readonly Dictionary<string, string> externalHw = new Dictionary<string, string>();
        private string externalSource = "";
        public bool WantExternal { get { return NeedSensors && UseWmi; } }

        public void BeginExternal(string source) { externalNext.Clear(); externalHw.Clear(); externalSource = source; }
        public void AddExternalHardware(string id, string name) { if (id != null) externalHw[id] = name ?? ""; }
        public void AddExternalSensor(string id, string parent, string name, string type, double value)
        {
            if (id == null || double.IsNaN(value)) return;
            SensorReading r = new SensorReading();
            string hw;
            if (parent == null || !externalHw.TryGetValue(parent, out hw)) hw = parent ?? "";
            r.Id = (externalSource.IndexOf("Libre", StringComparison.OrdinalIgnoreCase) >= 0 ? "lhm:" : "ohm:") + id;
            r.Hw = hw; r.Name = name ?? ""; r.Type = MapLhmType(type); r.Unit = UnitFor(r.Type, type); r.Value = value;
            externalNext.Add(r);
        }
        public void EndExternal()
        {
            external.Clear(); external.AddRange(externalNext); externalNext.Clear();
            LogOnce("ext:" + externalSource, "info", "Reading sensors from " + externalSource + " (" + external.Count + " readings)");
        }
        public void ClearExternal() { external.Clear(); }

        private static string MapLhmType(string t)
        {
            switch (t)
            {
                case "Temperature": return "temp";
                case "Fan": return "fan";
                case "Voltage": return "volt";
                case "Power": return "power";
                case "Clock": return "clock";
                case "Load": return "usage";
                case "Control": return "usage";
                case "Level": return "usage";
                case "Current": return "current";
                case "Frequency": return "clock";
                case "Throughput": return "rate";
                case "Data": return "data";
                case "SmallData": return "smalldata";
                default: return "other";
            }
        }
        private static string UnitFor(string type, string orig)
        {
            switch (type)
            {
                case "temp": return "\\u00B0C";
                case "fan": return "RPM";
                case "volt": return "V";
                case "power": return "W";
                case "clock": return "MHz";
                case "usage": return "%";
                case "current": return "A";
                case "rate": return "B/s";
                case "data": return "GB";
                case "smalldata": return "MB";
                default: return "";
            }
        }

        // HWiNFO: "Shared Memory Support" must be ticked in HWiNFO's settings.
        private IntPtr hwMap = IntPtr.Zero, hwView = IntPtr.Zero;
        private DateTime hwRetryAt = DateTime.MinValue;
        private bool hwLogged;

        private void CloseHwinfo()
        {
            if (hwView != IntPtr.Zero) Native.UnmapViewOfFile(hwView);
            if (hwMap != IntPtr.Zero) Native.CloseHandle(hwMap);
            hwView = IntPtr.Zero; hwMap = IntPtr.Zero;
        }

        private List<SensorReading> ReadHwinfo()
        {
            List<SensorReading> list = new List<SensorReading>();
            if (hwView == IntPtr.Zero)
            {
                if (DateTime.UtcNow < hwRetryAt) return list;
                hwRetryAt = DateTime.UtcNow.AddSeconds(10);
                hwMap = Native.OpenFileMappingW(4, false, "Global\\\\HWiNFO_SENS_SM2");
                if (hwMap == IntPtr.Zero) hwMap = Native.OpenFileMappingW(4, false, "HWiNFO_SENS_SM2");
                if (hwMap == IntPtr.Zero) return list;
                hwView = Native.MapViewOfFile(hwMap, 4, 0, 0, UIntPtr.Zero);
                if (hwView == IntPtr.Zero) { CloseHwinfo(); return list; }
            }
            uint sig = (uint)Marshal.ReadInt32(hwView, 0);
            if (sig != 0x53695748) // "HWiS"; HWiNFO writes "DEAD" when it closes
            {
                CloseHwinfo();
                if (hwLogged) { Log("info", "HWiNFO stopped sharing sensors"); hwLogged = false; }
                return list;
            }
            int sOff = Marshal.ReadInt32(hwView, 20), sSize = Marshal.ReadInt32(hwView, 24), sNum = Marshal.ReadInt32(hwView, 28);
            int rOff = Marshal.ReadInt32(hwView, 32), rSize = Marshal.ReadInt32(hwView, 36), rNum = Marshal.ReadInt32(hwView, 40);
            if (sNum < 0 || sNum > 4096 || rNum < 0 || rNum > 65536 || sSize < 264 || rSize < 316) return list;
            string[] sensorNames = new string[sNum];
            uint[] sensorIds = new uint[sNum];
            uint[] sensorInst = new uint[sNum];
            for (int i = 0; i < sNum; i++)
            {
                IntPtr p = new IntPtr(hwView.ToInt64() + sOff + (long)i * sSize);
                sensorIds[i] = (uint)Marshal.ReadInt32(p, 0);
                sensorInst[i] = (uint)Marshal.ReadInt32(p, 4);
                string user = Marshal.PtrToStringAnsi(new IntPtr(p.ToInt64() + 136));
                string orig = Marshal.PtrToStringAnsi(new IntPtr(p.ToInt64() + 8));
                sensorNames[i] = string.IsNullOrEmpty(user) ? (orig ?? "") : user;
            }
            for (int i = 0; i < rNum; i++)
            {
                IntPtr p = new IntPtr(hwView.ToInt64() + rOff + (long)i * rSize);
                int type = Marshal.ReadInt32(p, 0);
                int sIdx = Marshal.ReadInt32(p, 4);
                uint rid = (uint)Marshal.ReadInt32(p, 8);
                string label = Marshal.PtrToStringAnsi(new IntPtr(p.ToInt64() + 140));
                if (string.IsNullOrEmpty(label)) label = Marshal.PtrToStringAnsi(new IntPtr(p.ToInt64() + 12));
                string unit = Marshal.PtrToStringAnsi(new IntPtr(p.ToInt64() + 268)) ?? "";
                double v = BitConverter.Int64BitsToDouble(Marshal.ReadInt64(p, 284));
                if (sIdx < 0 || sIdx >= sNum || double.IsNaN(v)) continue;
                SensorReading r = new SensorReading();
                r.Id = "hwi:" + sensorIds[sIdx].ToString("X") + "-" + sensorInst[sIdx] + "-" + rid.ToString("X");
                r.Hw = sensorNames[sIdx];
                r.Name = label ?? "";
                string[] types = { "other", "temp", "volt", "fan", "current", "power", "clock", "usage", "other" };
                r.Type = type >= 0 && type < types.Length ? types[type] : "other";
                r.Unit = unit.Replace("\\u00C2", "");
                r.Value = v;
                list.Add(r);
            }
            if (!hwLogged) { Log("info", "Reading sensors from HWiNFO (" + list.Count + " readings)"); hwLogged = true; }
            return list;
        }

        // Which sensor apps are running (checked every 5 seconds).
        private string appsJson;
        private DateTime appsAt = DateTime.MinValue;
        private void WriteApps(Json j)
        {
            if (appsJson == null || (DateTime.UtcNow - appsAt).TotalSeconds >= 5)
            {
                appsAt = DateTime.UtcNow;
                Json a = new Json();
                a.O().P("lhm", Running("LibreHardwareMonitor")).P("hwinfo", Running("HWiNFO64") || Running("HWiNFO32") || Running("HWiNFO") || Running("HWiNFO_ARM64"))
                    .P("ohm", Running("OpenHardwareMonitor")).End();
                appsJson = a.ToString();
            }
            j.K("apps").Raw(appsJson);
        }
        private static bool Running(string name)
        {
            Process[] p = Process.GetProcessesByName(name);
            bool any = p.Length > 0;
            foreach (Process x in p) x.Dispose();
            return any;
        }

        private void AddAmdCpu(List<SensorReading> list, string type, string name, string unit, double v)
        {
            if (double.IsNaN(v)) return;
            SensorReading r = new SensorReading();
            r.Id = "amd:cpu-" + type; r.Hw = "CPU (AMD driver)"; r.Name = name; r.Type = type; r.Unit = unit; r.Value = v;
            list.Add(r);
        }

        private void WriteSensors(Json j)
        {
            if (sensorsJson != null && (DateTime.UtcNow - sensorsAt).TotalMilliseconds < 1900) { j.K("sensors"); j.Raw(sensorsJson); return; }
            sensorsAt = DateTime.UtcNow;
            List<SensorReading> all = new List<SensorReading>();
            if (UseHwinfo)
            {
                try { all.AddRange(ReadHwinfo()); } catch (Exception e) { LogOnce("hwinfo", "warn", "HWiNFO: " + e.Message); CloseHwinfo(); }
            }
            if (UseWmi) all.AddRange(external);
            // CPU readings from the AMD graphics driver, when it has them
            if (HasVendor("amd"))
            {
                try { ReadAdl(); } catch (Exception e) { LogOnce("adlcpu", "warn", "AMD CPU readings: " + e.Message); }
                AddAmdCpu(all, "temp", "CPU Temperature", "\\u00B0C", adlCpuTemp);
                AddAmdCpu(all, "power", "CPU Power", "W", adlCpuPower);
                AddAmdCpu(all, "clock", "CPU Clock", "MHz", adlCpuClock);
            }
            Json s = new Json();
            s.A();
            foreach (SensorReading r in all)
                s.O().P("id", r.Id).P("hw", r.Hw).P("name", r.Name).P("type", r.Type).P("unit", r.Unit).P("v", r.Value).End();
            s.End();
            sensorsJson = s.ToString();
            j.K("sensors"); j.Raw(sensorsJson);
        }

        // ---------------- parent watch
        public static bool ProcessAlive(int pid)
        {
            if (pid <= 0) return true;
            try { Process p = Process.GetProcessById(pid); return !p.HasExited; }
            catch (ArgumentException) { return false; }
            catch { return true; }
        }
    }
}
`;
  }
});

// src/collector.js
var require_collector = __commonJS({
  "src/collector.js"(exports2, module2) {
    "use strict";
    var fs2 = require("fs");
    var path2 = require("path");
    var { spawn: spawn2 } = require("child_process");
    var readline = require("readline");
    var { EventEmitter } = require("events");
    var SCRIPT = require_vitals();
    var CSHARP = require_Vitals();
    function powershellPath() {
      const root = process.env.SystemRoot || process.env.windir || "C:\\Windows";
      const sys = process.arch === "ia32" && process.env.PROCESSOR_ARCHITEW6432 ? "Sysnative" : "System32";
      const p = path2.join(root, sys, "WindowsPowerShell", "v1.0", "powershell.exe");
      return fs2.existsSync(p) ? p : "powershell.exe";
    }
    function writeIfChanged(file, content) {
      try {
        if (fs2.readFileSync(file, "utf8") === content) return;
      } catch (_) {
      }
      fs2.writeFileSync(file, content, "utf8");
    }
    var Collector2 = class extends EventEmitter {
      constructor(log2, pluginDir) {
        super();
        this.log = log2;
        this.pluginDir = pluginDir;
        this.proc = null;
        this.stopping = false;
        this.restarts = 0;
        this.needs = { gpu: true, top: false, sensors: false, hwinfo: true, wmi: true };
        this.sentNeeds = "";
        this.lastSampleAt = 0;
        this.startedAt = 0;
        this.status = "starting";
        this.statusText = "Starting\u2026";
        this.stderrCount = 0;
      }
      command() {
        if (process.env.SYSVITALS_COLLECTOR) {
          const parts = JSON.parse(process.env.SYSVITALS_COLLECTOR);
          return { cmd: parts[0], args: parts.slice(1).concat(["-ParentPid", String(process.pid)]) };
        }
        const dir = path2.join(this.pluginDir, "runtime");
        fs2.mkdirSync(dir, { recursive: true });
        const script = path2.join(dir, "vitals.ps1");
        writeIfChanged(script, "\uFEFF" + SCRIPT);
        writeIfChanged(path2.join(dir, "Vitals.cs"), CSHARP);
        return {
          cmd: powershellPath(),
          args: ["-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", script, "-ParentPid", String(process.pid), "-CacheDir", dir]
        };
      }
      start() {
        if (this.proc || this.stopping) return;
        let spec;
        try {
          spec = this.command();
        } catch (e) {
          this.setStatus("error", "Can't start");
          this.log.error("Could not prepare the collector", e);
          return this.retryLater();
        }
        this.log.info(`Starting collector: ${path2.basename(spec.cmd)}`);
        this.startedAt = Date.now();
        let proc;
        try {
          proc = spawn2(spec.cmd, spec.args, { windowsHide: true, stdio: ["pipe", "pipe", "pipe"] });
        } catch (e) {
          this.log.error("Could not start PowerShell", e);
          this.setStatus("error", "Can't start");
          return this.retryLater();
        }
        this.proc = proc;
        this.sentNeeds = "";
        proc.on("error", (e) => {
          this.log.error("Collector error", e.message);
        });
        proc.stdin.on("error", () => {
        });
        const rl = readline.createInterface({ input: proc.stdout });
        rl.on("line", (line) => this.onLine(line));
        const rle = readline.createInterface({ input: proc.stderr });
        rle.on("line", (line) => {
          if (!line.trim()) return;
          if (++this.stderrCount <= 40) this.log.warn("Collector:", line.slice(0, 500));
        });
        proc.on("exit", (code, signal) => {
          this.proc = null;
          if (this.stopping) return;
          this.log.warn(`Collector stopped (code ${code}${signal ? ", " + signal : ""})`);
          this.setStatus("error", code === 3 ? "Collector failed" : "Restarting\u2026");
          this.retryLater();
        });
        this.sendNeeds();
      }
      retryLater() {
        if (this.stopping) return;
        const ran = Date.now() - this.startedAt;
        if (ran > 6e4) this.restarts = 0;
        const wait = [2e3, 5e3, 15e3, 3e4, 6e4][Math.min(this.restarts, 4)];
        this.restarts++;
        clearTimeout(this.retryTimer);
        this.retryTimer = setTimeout(() => this.start(), wait);
      }
      setStatus(status, text) {
        if (this.status === status && this.statusText === text) return;
        this.status = status;
        this.statusText = text;
        this.emit("status");
      }
      onLine(line) {
        line = line.trim();
        if (!line || line[0] !== "{") return;
        let msg;
        try {
          msg = JSON.parse(line);
        } catch (e) {
          if (++this.stderrCount <= 40) this.log.warn("Collector sent unreadable data:", line.slice(0, 200));
          return;
        }
        if (msg.type === "log") {
          const fn = msg.level === "error" ? "error" : msg.level === "warn" ? "warn" : "info";
          this.log[fn]("Collector:", String(msg.msg || "").slice(0, 800));
        } else if (msg.type === "info") {
          this.emit("info", msg);
        } else if (msg.type === "sample") {
          this.lastSampleAt = Date.now();
          if (this.status !== "running") {
            this.restarts = 0;
            this.setStatus("running", "");
          }
          this.emit("sample", msg);
        }
      }
      setNeeds(needs) {
        this.needs = { ...this.needs, ...needs };
        this.sendNeeds();
      }
      sendNeeds() {
        const n = this.needs;
        const line = `need gpu=${n.gpu ? 1 : 0} top=${n.top ? 1 : 0} sensors=${n.sensors ? 1 : 0} hwinfo=${n.hwinfo ? 1 : 0} wmi=${n.wmi ? 1 : 0}`;
        if (line === this.sentNeeds || !this.proc) return;
        this.sentNeeds = line;
        try {
          this.proc.stdin.write(line + "\n");
        } catch (_) {
        }
      }
      stop() {
        this.stopping = true;
        clearTimeout(this.retryTimer);
        const p = this.proc;
        if (!p) return;
        try {
          p.stdin.write("quit\n");
          p.stdin.end();
        } catch (_) {
        }
        setTimeout(() => {
          try {
            p.kill();
          } catch (_) {
          }
        }, 800).unref();
      }
    };
    module2.exports = { Collector: Collector2, powershellPath };
  }
});

// src/nvidia.js
var require_nvidia = __commonJS({
  "src/nvidia.js"(exports2, module2) {
    "use strict";
    var fs2 = require("fs");
    var path2 = require("path");
    var { spawn: spawn2 } = require("child_process");
    var readline = require("readline");
    var FULL = ["pci.bus_id", "temperature.gpu", "power.draw", "power.limit", "fan.speed", "clocks.gr", "clocks.mem"];
    var BASIC = ["pci.bus_id", "temperature.gpu", "power.draw", "fan.speed", "clocks.gr"];
    function findNvidiaSmi() {
      if (process.env.SYSVITALS_NVIDIA_SMI) return process.env.SYSVITALS_NVIDIA_SMI;
      const root = process.env.SystemRoot || "C:\\Windows";
      const pf = process.env.ProgramW6432 || process.env.ProgramFiles || "C:\\Program Files";
      const list = [path2.join(root, "System32", "nvidia-smi.exe"), path2.join(pf, "NVIDIA Corporation", "NVSMI", "nvidia-smi.exe")];
      for (const p of list) if (fs2.existsSync(p)) return p;
      try {
        const repo = path2.join(root, "System32", "DriverStore", "FileRepository");
        for (const d of fs2.readdirSync(repo)) {
          if (!/^nv/i.test(d)) continue;
          const p = path2.join(repo, d, "nvidia-smi.exe");
          if (fs2.existsSync(p)) return p;
        }
      } catch (_) {
      }
      return null;
    }
    function num(s) {
      const v = parseFloat(String(s).trim());
      return Number.isFinite(v) ? v : null;
    }
    function parseLine(line, fields) {
      const parts = line.split(",").map((s) => s.trim());
      if (parts.length < fields.length) return null;
      const o = {};
      fields.forEach((f, i) => o[f] = parts[i]);
      const m = /^[0-9a-f]+:([0-9a-f]+):/i.exec(o["pci.bus_id"] || "");
      if (!m) return null;
      return {
        bus: parseInt(m[1], 16),
        temp: num(o["temperature.gpu"]),
        power: num(o["power.draw"]),
        powerLimit: num(o["power.limit"]),
        fanPct: num(o["fan.speed"]),
        clock: num(o["clocks.gr"]),
        memClock: num(o["clocks.mem"]),
        at: Date.now()
      };
    }
    var NvidiaSmi2 = class {
      constructor(log2) {
        this.log = log2;
        this.exe = void 0;
        this.proc = null;
        this.fields = FULL;
        this.byBus = /* @__PURE__ */ new Map();
        this.wanted = false;
        this.failures = 0;
      }
      setWanted(on) {
        if (on === this.wanted) return;
        this.wanted = on;
        if (on) this.start();
        else this.stop();
      }
      start() {
        if (this.proc || !this.wanted) return;
        if (this.exe === void 0) {
          this.exe = findNvidiaSmi();
          this.log.info(this.exe ? `Using nvidia-smi for NVIDIA readings: ${this.exe}` : "nvidia-smi not found");
        }
        if (!this.exe) return;
        const fields = this.fields;
        const proc = spawn2(this.exe, [`--query-gpu=${fields.join(",")}`, "--format=csv,noheader,nounits", "-lms", "1000"], {
          windowsHide: true,
          stdio: ["ignore", "pipe", "pipe"]
        });
        this.proc = proc;
        let gotData = false;
        let errText = "";
        proc.on("error", (e) => this.log.warn("nvidia-smi failed to start", e.message));
        readline.createInterface({ input: proc.stdout }).on("line", (line) => {
          const d = parseLine(line, fields);
          if (d) {
            gotData = true;
            this.failures = 0;
            this.byBus.set(d.bus, d);
          } else if (/not a valid field|invalid/i.test(line)) errText += line;
        });
        readline.createInterface({ input: proc.stderr }).on("line", (l) => errText += l + " ");
        proc.on("exit", (code) => {
          this.proc = null;
          if (!this.wanted) return;
          if (!gotData && this.fields === FULL) {
            this.fields = BASIC;
            this.log.info("nvidia-smi: retrying with fewer fields", errText.slice(0, 200));
          } else {
            this.failures++;
            if (errText) this.log.warn("nvidia-smi stopped:", errText.slice(0, 300));
          }
          if (this.failures > 5) return;
          setTimeout(() => this.start(), Math.min(6e4, 2e3 * (this.failures + 1))).unref();
        });
      }
      stop() {
        if (this.proc) {
          try {
            this.proc.kill();
          } catch (_) {
          }
          this.proc = null;
        }
      }
      get(bus) {
        const d = this.byBus.get(bus);
        return d && Date.now() - d.at < 5e3 ? d : null;
      }
      any() {
        for (const d of this.byBus.values()) if (Date.now() - d.at < 5e3) return d;
        return null;
      }
    };
    module2.exports = { NvidiaSmi: NvidiaSmi2, parseLine, FULL };
  }
});

// src/store.js
var require_store = __commonJS({
  "src/store.js"(exports2, module2) {
    "use strict";
    var HIST = 600;
    var Ring = class {
      constructor(n = HIST) {
        this.a = new Float64Array(n).fill(NaN);
        this.i = 0;
        this.n = n;
      }
      push(v) {
        this.a[this.i] = Number.isFinite(v) ? v : NaN;
        this.i = (this.i + 1) % this.n;
      }
      // last `count` values, oldest first
      last(count) {
        count = Math.max(2, Math.min(this.n, count));
        const out = new Array(count);
        for (let k = 0; k < count; k++) out[k] = this.a[(this.i - count + k + this.n * 2) % this.n];
        return out;
      }
    };
    var fin = (v) => v == null || !Number.isFinite(Number(v)) ? null : Number(v);
    var CPUISH = /\b(cpu|processor|ryzen|threadripper|epyc|core i\d|core ultra|xeon|intel core|amd cpu|intelcpu|amdcpu|celeron|pentium|athlon|snapdragon)\b/i;
    var GPUISH = /\b(gpu|radeon|geforce|rtx|gtx|arc|nvidia|graphics)\b/i;
    var CPU_TEMP_PREFS = [
      /^cpu package$/i,
      /^package$/i,
      /^cpu \(tctl\/tdie\)$/i,
      /^core \(tctl\/tdie\)$/i,
      /tctl\/tdie|^tdie$|^tctl$/i,
      /^cpu die \(average\)$/i,
      /^core max$/i,
      /^core average$/i,
      /^cpu( temperature)?$/i,
      /^cpu cores?$/i,
      /cpu/i
    ];
    var CPU_POWER_PREFS = [/^cpu package power$/i, /^package$/i, /^cpu package$/i, /^cpu ppt$/i, /^package power$/i, /^cpu power$/i, /package/i, /cpu/i];
    function pickSensor(sensors, type, prefs, wantHw) {
      let best = null;
      let bestScore = Infinity;
      for (const s of sensors.values()) {
        if (s.type !== type || !Number.isFinite(s.v)) continue;
        const hw = s.hw || "";
        const cpuHw = CPUISH.test(hw) && !GPUISH.test(hw);
        if (wantHw === "cpu" && !cpuHw && !/^cpu/i.test(s.name)) continue;
        if (GPUISH.test(hw) || /gpu/i.test(s.name)) continue;
        const idx = prefs.findIndex((re) => re.test(s.name));
        if (idx < 0) continue;
        const score = idx * 10 + (cpuHw ? 0 : 5) + (/#1|\/1\//.test(hw + s.id) ? 1 : 0);
        if (score < bestScore) {
          bestScore = score;
          best = s;
        }
      }
      return best;
    }
    function sourceName(id) {
      if (!id) return "";
      if (id.startsWith("hwi:")) return "HWiNFO";
      if (id.startsWith("lhm:")) return "LibreHardwareMonitor";
      if (id.startsWith("ohm:")) return "OpenHardwareMonitor";
      if (id.startsWith("amd:")) return "AMD driver";
      return "";
    }
    var Store2 = class {
      constructor() {
        this.info = null;
        this.cur = { cpu: {}, mem: {}, gpus: [], disks: [], vols: [], nets: [], sys: {}, bat: null, top: null };
        this.samples = 0;
        this.hist = /* @__PURE__ */ new Map();
        this.sensors = /* @__PURE__ */ new Map();
        this.sensorsSeen = 0;
        this.cpuTemp = null;
        this.cpuPower = null;
        this.nvidia = null;
        this.source = "auto";
        this.apps = { lhm: false, hwinfo: false, ohm: false };
      }
      // Which readings the Setup key's choice allows. Built-in ones (AMD driver) always count.
      allowed(id) {
        const src = String(id).split(":")[0];
        if (src === "amd") return true;
        if (this.source === "none") return false;
        if (this.source === "lhm") return src === "lhm";
        if (this.source === "hwinfo") return src === "hwi";
        return true;
      }
      // Readings from LibreHardwareMonitor's web server (merged with the collector's).
      addLhm(list) {
        const now = Date.now();
        for (const r of list) this.sensors.set(r.id, { ...r, seen: now });
        this.sensorsSeen = now;
      }
      ring(key) {
        let h = this.hist.get(key);
        if (!h) {
          h = new Ring();
          this.hist.set(key, h);
        }
        return h;
      }
      series(key, count) {
        const h = this.hist.get(key);
        return h ? h.last(count) : new Array(Math.max(2, count)).fill(NaN);
      }
      setInfo(info) {
        this.info = info;
      }
      gpuInfo(id) {
        return this.info && this.info.gpus.find((g) => g.id === id) || null;
      }
      add(s) {
        this.samples++;
        const cur = this.cur;
        if (s.cpu && s.cpu.load != null) cur.cpu = s.cpu;
        if (s.mem) cur.mem = s.mem;
        if (s.gpus) cur.gpus = s.gpus;
        if (s.disks && s.disks.length) cur.disks = s.disks;
        if (s.vols) cur.vols = s.vols;
        if (s.nets) cur.nets = s.nets;
        if (s.sys) cur.sys = { ...cur.sys, ...s.sys, therm: s.sys.therm || cur.sys.therm };
        if ("bat" in s) cur.bat = s.bat;
        if (s.top) cur.top = s.top;
        if (s.apps) this.apps = s.apps;
        cur.at = Date.now();
        if (s.sensors) {
          const now = Date.now();
          for (const r of s.sensors) this.sensors.set(r.id, { ...r, seen: now });
          for (const [id, r] of this.sensors) if (now - r.seen > 15e3) this.sensors.delete(id);
          this.sensorsSeen = now;
        }
        this.mergeNvidiaSmi();
        this.derive();
        this.record();
      }
      mergeNvidiaSmi() {
        if (!this.nvidia || !this.info) return;
        for (const g of this.cur.gpus) {
          const gi = this.gpuInfo(g.id);
          if (!gi || gi.vendor !== "nvidia") continue;
          const d = this.nvidia.get(gi.bus) || (this.info.gpus.filter((x) => x.vendor === "nvidia").length === 1 ? this.nvidia.any() : null);
          if (!d) continue;
          if (d.temp != null) {
            g.temp = d.temp;
            g.src = "nvidia";
          }
          if (d.power != null) g.power = d.power;
          if (d.powerLimit != null) g.powerLimit = d.powerLimit;
          if (d.power != null && d.powerLimit) g.powerPct = d.power / d.powerLimit * 100;
          if (d.fanPct != null) g.fanPct = d.fanPct;
          if (d.clock != null) g.clock = d.clock;
          if (d.memClock != null) g.memClock = d.memClock;
        }
      }
      derive() {
        let t = null;
        const usable = this.usableSensors();
        const s = pickSensor(usable, "temp", CPU_TEMP_PREFS, "cpu");
        if (s && s.v > 0 && s.v < 130) t = { c: s.v, src: sourceName(s.id), id: s.id };
        if (!t) {
          const live = (this.cur.sys.therm || []).filter((z) => z.live && z.c > 15 && z.c < 115);
          if (live.length) {
            const z = live.reduce((a, b) => b.c > a.c ? b : a);
            t = { c: z.c, src: "Windows", id: "therm:" + z.id };
          }
        }
        this.cpuTemp = t;
        const p = pickSensor(usable, "power", CPU_POWER_PREFS, "cpu");
        this.cpuPower = p && p.v >= 0 && p.v < 1e3 ? { w: p.v, src: sourceName(p.id), id: p.id } : null;
      }
      memPct() {
        const m = this.cur.mem;
        return m && m.total ? (m.total - m.avail) / m.total * 100 : null;
      }
      // GPU memory: dedicated for cards, shared for integrated graphics.
      gpuMem(g) {
        const gi = this.gpuInfo(g.id) || {};
        const integrated = gi.integrated || !(gi.dedTotal > 1.1 * 1073741824);
        const used = integrated ? fin(g.shr) : fin(g.ded);
        let total = integrated ? fin(gi.shrTotal) : fin(gi.dedTotal);
        if (integrated && used != null && fin(g.ded) != null) {
          return { used: used + g.ded, total: (total || 0) + (fin(gi.dedTotal) || 0) || null, integrated };
        }
        return { used, total, integrated };
      }
      record() {
        const c = this.cur;
        this.ring("cpu").push(fin(c.cpu.load));
        this.ring("cpuTemp").push(this.cpuTemp ? this.cpuTemp.c : NaN);
        this.ring("cpuPower").push(this.cpuPower ? this.cpuPower.w : NaN);
        this.ring("mem").push(this.memPct());
        let gpuMax = NaN;
        for (const g of c.gpus) {
          this.ring("gpu:" + g.id).push(fin(g.util));
          const m = this.gpuMem(g);
          this.ring("vram:" + g.id).push(m.used != null && m.total ? m.used / m.total * 100 : NaN);
          this.ring("gtemp:" + g.id).push(fin(g.temp));
          this.ring("gpower:" + g.id).push(fin(g.power));
          if (Number.isFinite(g.util) && !(g.util <= gpuMax)) gpuMax = g.util;
        }
        this.ring("gpu:auto").push(this.autoGpu() ? fin(this.autoGpu().util) : gpuMax);
        let act = NaN;
        let rd = 0;
        let wr = 0;
        for (const d of c.disks) {
          if (d.id === "_Total") continue;
          this.ring(`disk:${d.id}:act`).push(fin(d.act));
          this.ring(`disk:${d.id}:rd`).push(fin(d.rd));
          this.ring(`disk:${d.id}:wr`).push(fin(d.wr));
          if (Number.isFinite(d.act) && !(d.act <= act)) act = d.act;
          rd += fin(d.rd) || 0;
          wr += fin(d.wr) || 0;
        }
        this.ring("disk:*:act").push(act);
        this.ring("disk:*:rd").push(rd);
        this.ring("disk:*:wr").push(wr);
        let rx = 0;
        let tx = 0;
        for (const n of c.nets) {
          this.ring(`net:${n.id}:rx`).push(fin(n.rx));
          this.ring(`net:${n.id}:tx`).push(fin(n.tx));
          if (n.up && !n.virt) {
            rx += fin(n.rx) || 0;
            tx += fin(n.tx) || 0;
          }
        }
        this.ring("net:*:rx").push(rx);
        this.ring("net:*:tx").push(tx);
        for (const sn of this.sensors.values()) this.ring("sensor:" + sn.id).push(fin(sn.v));
      }
      // ---------------------------------------------------------------- lookups used by keys
      gpuList() {
        const live = new Map(this.cur.gpus.map((g) => [g.id, g]));
        return (this.info && this.info.gpus || []).map((gi) => ({ ...gi, ...live.get(gi.id) || {} }));
      }
      // Automatic GPU: the dedicated card with the most memory, else the first one.
      autoGpu() {
        const list = this.gpuList();
        if (!list.length) return null;
        const ded = list.filter((g) => !g.integrated);
        const pool = ded.length ? ded : list;
        return pool.reduce((a, b) => (b.dedTotal || 0) > (a.dedTotal || 0) ? b : a);
      }
      gpu(id) {
        const list = this.gpuList();
        if (id) {
          const g = list.find((x) => x.id === id);
          if (g) return g;
        }
        return this.autoGpu();
      }
      gpuLabel(g) {
        if (!g) return "GPU";
        const list = this.gpuList();
        if (list.length > 1 && g.integrated && list.some((x) => !x.integrated)) return "iGPU";
        return "GPU";
      }
      // Drive letter -> physical disk counters. Automatic = the Windows drive.
      driveId(sel) {
        if (sel === "*") return "*";
        if (sel) return sel.toUpperCase();
        return (process.env.SystemDrive || "C:").toUpperCase();
      }
      diskFor(sel) {
        const id = this.driveId(sel);
        if (id === "*") {
          const list = this.cur.disks.filter((d) => d.id !== "_Total");
          if (!list.length) return null;
          return {
            id: "*",
            act: Math.max(...list.map((d) => fin(d.act) || 0)),
            rd: list.reduce((a, d) => a + (fin(d.rd) || 0), 0),
            wr: list.reduce((a, d) => a + (fin(d.wr) || 0), 0)
          };
        }
        const letter = id.replace(/\\$/, "");
        return this.cur.disks.find((d) => d.id !== "_Total" && d.id.toUpperCase().split(/\s+/).includes(letter)) || null;
      }
      volFor(sel) {
        const id = this.driveId(sel);
        if (id === "*") {
          const list = this.cur.vols.filter((v) => v.kind === "Fixed");
          if (!list.length) return null;
          return { id: "*", label: "All drives", total: list.reduce((a, v) => a + v.total, 0), free: list.reduce((a, v) => a + v.free, 0) };
        }
        return this.cur.vols.find((v) => v.id.toUpperCase() === id) || null;
      }
      drives() {
        return this.cur.vols.map((v) => ({ id: v.id, label: v.label, kind: v.kind, total: v.total }));
      }
      // Automatic adapter: the connected, non-virtual adapter with a gateway and the most traffic.
      autoNet() {
        const list = this.cur.nets.filter((n) => n.up);
        if (!list.length) return null;
        const score = (n) => (n.gw ? 4 : 0) + (n.virt ? 0 : 2) + (n.kind === "Wireless80211" || n.kind === "Ethernet" || /Ethernet/.test(n.kind) ? 1 : 0);
        let best = null;
        for (const n of list) {
          if (!best) best = n;
          else {
            const a = score(n);
            const b = score(best);
            const traffic = (x) => this.series(`net:${x.id}:rx`, 30).reduce((s, v) => s + (v || 0), 0) || 0;
            if (a > b || a === b && traffic(n) > traffic(best)) best = n;
          }
        }
        return best;
      }
      netFor(sel) {
        if (sel === "*") {
          const list = this.cur.nets.filter((n) => n.up && !n.virt);
          return {
            id: "*",
            name: "All adapters",
            up: list.length > 0,
            rx: list.reduce((a, n) => a + (fin(n.rx) || 0), 0),
            tx: list.reduce((a, n) => a + (fin(n.tx) || 0), 0),
            speed: Math.max(0, ...list.map((n) => n.speed > 0 && n.speed < 4e11 ? n.speed : 0)),
            ip: (list.find((n) => n.gw && n.ip) || list[0] || {}).ip || ""
          };
        }
        if (sel) {
          const n = this.cur.nets.find((x) => x.id === sel);
          if (n) return n;
          return { id: sel, name: "Adapter", up: false, rx: 0, tx: 0, missing: true };
        }
        return this.autoNet();
      }
      adapters() {
        return this.cur.nets.map((n) => ({ id: n.id, name: n.name, desc: n.desc, up: n.up, virt: n.virt }));
      }
      usableSensors() {
        const m = /* @__PURE__ */ new Map();
        for (const [id, s] of this.sensors) if (this.allowed(id) && Date.now() - s.seen < 15e3) m.set(id, s);
        return m;
      }
      sensorList() {
        return [...this.usableSensors().values()].map((s) => ({ id: s.id, hw: s.hw, name: s.name, type: s.type, unit: s.unit, src: sourceName(s.id) }));
      }
      sensor(id) {
        const s = this.sensors.get(id);
        return s && this.allowed(id) && Date.now() - s.seen < 15e3 ? s : null;
      }
      sensorSource() {
        const names = new Set([...this.usableSensors().keys()].map(sourceName).filter(Boolean));
        return [...names].join(" + ");
      }
      countFrom(prefix) {
        let n = 0;
        for (const [id, s] of this.sensors) if (id.startsWith(prefix) && Date.now() - s.seen < 15e3) n++;
        return n;
      }
    };
    module2.exports = { Store: Store2, Ring, HIST, pickSensor, CPU_TEMP_PREFS, sourceName };
  }
});

// src/native/install-lhm.ps1
var require_install_lhm = __commonJS({
  "src/native/install-lhm.ps1"(exports2, module2) {
    module2.exports = `# Installs or updates LibreHardwareMonitor for the System Vitals plugin, or with
# -ConfigOnly just switches how it shares readings. Runs elevated (Windows asks
# for permission once). Steps:
#   1. Download the latest LibreHardwareMonitor.zip from its official GitHub releases
#   2. Copy it to "C:\\Program Files\\LibreHardwareMonitor" (keeps an existing .config)
#   3. Share readings the chosen way (-Mode):
#        web: its web server for this PC only (127.0.0.1:<Port>), logging off
#        log: its sensor log file every 2 s (one file a day), web server off, and a
#             daily task that deletes log files older than 2 days
#      and start minimised to the tray
#   4. Install PawnIO (signed driver LibreHardwareMonitor uses to read the CPU) if missing/old
#   5. Start it at logon with a scheduled task (the same one its own "Run On Windows Startup" uses)
#   6. Start it now
# Progress is written as JSON to -StatusFile so the plugin can show it.

param(
    [int]$Port = 8085,
    [ValidateSet('web', 'log')][string]$Mode = 'web',
    [string]$User = '',
    [string]$StatusFile = '',
    [switch]$ConfigOnly
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

function Write-Status([string]$step, [bool]$done = $false, [string]$err = '') {
    if (-not $StatusFile) { return }
    $o = @{ step = $step; done = $done; error = $err; at = [DateTime]::UtcNow.ToString('o') }
    try { [IO.File]::WriteAllText($StatusFile, (ConvertTo-Json $o -Compress)) } catch { }
}

function Stop-Lhm {
    Get-Process -Name 'LibreHardwareMonitor' -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Sleep -Milliseconds 800
}

$dest = Join-Path $env:ProgramFiles 'LibreHardwareMonitor'
$work = Join-Path $env:ProgramFiles 'LibreHardwareMonitor.setup'
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    if (Test-Path -LiteralPath $work) { Remove-Item -LiteralPath $work -Recurse -Force }
    New-Item -ItemType Directory -Path $work | Out-Null

    if (-not $ConfigOnly) {
    Write-Status 'Downloading LibreHardwareMonitor'
    $zip = Join-Path $work 'LibreHardwareMonitor.zip'
    Invoke-WebRequest -UseBasicParsing -Uri 'https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/releases/latest/download/LibreHardwareMonitor.zip' -OutFile $zip

    Write-Status 'Unpacking'
    $ex = Join-Path $work 'files'
    Expand-Archive -LiteralPath $zip -DestinationPath $ex -Force
    $exe = Get-ChildItem -LiteralPath $ex -Recurse -Filter 'LibreHardwareMonitor.exe' | Select-Object -First 1
    if (-not $exe) { throw 'The download did not contain LibreHardwareMonitor.exe' }

    Write-Status 'Copying to Program Files'
    Get-Process -Name 'LibreHardwareMonitor' -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Sleep -Milliseconds 800
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    $cfgPath = Join-Path $dest 'LibreHardwareMonitor.config'
    $oldCfg = $null
    if (Test-Path -LiteralPath $cfgPath) { $oldCfg = [IO.File]::ReadAllText($cfgPath) }
    Copy-Item -Path (Join-Path $exe.DirectoryName '*') -Destination $dest -Recurse -Force
    if ($oldCfg) { [IO.File]::WriteAllText($cfgPath, $oldCfg) }
    Get-ChildItem -LiteralPath $dest -Recurse -File | Unblock-File
    }
    else {
        if (-not (Test-Path -LiteralPath (Join-Path $dest 'LibreHardwareMonitor.exe'))) { throw 'LibreHardwareMonitor is not installed in Program Files' }
        Write-Status 'Stopping LibreHardwareMonitor'
        Stop-Lhm
    }
    $cfgPath = Join-Path $dest 'LibreHardwareMonitor.config'

    Write-Status ($(if ($Mode -eq 'log') { 'Turning on its log file' } else { 'Turning on its web server' }))
    $xml = New-Object System.Xml.XmlDocument
    $loaded = $false
    if (Test-Path -LiteralPath $cfgPath) { try { $xml.Load($cfgPath); $loaded = $true } catch { } }
    if (-not $loaded) { $xml.LoadXml('<?xml version="1.0" encoding="utf-8"?><configuration><appSettings /></configuration>') }
    $app = $xml.SelectSingleNode('/configuration/appSettings')
    if (-not $app) {
        $root = $xml.SelectSingleNode('/configuration')
        if (-not $root) { $root = $xml.AppendChild($xml.CreateElement('configuration')) }
        $app = $root.AppendChild($xml.CreateElement('appSettings'))
    }
    $values = [ordered]@{
        runWebServerMenuItem = $(if ($Mode -eq 'web') { 'true' } else { 'false' })
        listenerIp           = '127.0.0.1'
        listenerPort         = [string]$Port
        logSensorsMenuItem   = $(if ($Mode -eq 'log') { 'true' } else { 'false' })
        loggingInterval      = '1'
        'logger.fileRotation' = '1'
        startMinMenuItem     = 'true'
        minTrayMenuItem      = 'true'
        minCloseMenuItem     = 'true'
    }
    foreach ($k in $values.Keys) {
        $node = $app.SelectSingleNode("add[@key='$k']")
        if (-not $node) {
            $node = $xml.CreateElement('add')
            $node.SetAttribute('key', $k)
            [void]$app.AppendChild($node)
        }
        $node.SetAttribute('value', $values[$k])
    }
    $xml.Save($cfgPath)

    # PawnIO: LibreHardwareMonitor needs version 2 or newer to read the CPU.
    $pawnVersion = $null
    foreach ($view in 'Registry64', 'Registry32') {
        try {
            $base = [Microsoft.Win32.RegistryKey]::OpenBaseKey('LocalMachine', $view)
            $k = $base.OpenSubKey('SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\PawnIO')
            if ($k) { $v = [string]$k.GetValue('DisplayVersion'); if ($v) { $pawnVersion = [Version]$v } }
        } catch { }
        if ($pawnVersion) { break }
    }
    if (-not $pawnVersion -or $pawnVersion -lt [Version]'2.0.0.0') {
        Write-Status 'Installing PawnIO'
        $setup = Join-Path $work 'PawnIO_setup.exe'
        Invoke-WebRequest -UseBasicParsing -Uri 'https://github.com/namazso/PawnIO.Setup/releases/latest/download/PawnIO_setup.exe' -OutFile $setup
        $sig = Get-AuthenticodeSignature -LiteralPath $setup
        if ($sig.Status -ne 'Valid') { throw "PawnIO setup is not properly signed ($($sig.Status)); not installing it" }
        $p = Start-Process -FilePath $setup -ArgumentList '-install', '-silent' -Wait -PassThru
        if ($p.ExitCode -ne 0) { throw "PawnIO setup failed (code $($p.ExitCode))" }
    }

    Write-Status 'Setting it to start with Windows'
    $userId = $User
    if (-not $userId) { $userId = "$env:USERDOMAIN\\$env:USERNAME" }

    # Log files: one per day, about 50 MB each at 2-second logging; keep the last two days.
    $cleanName = 'LibreHardwareMonitor log cleanup'
    if ($Mode -eq 'log') {
        $cmd = "Get-ChildItem -LiteralPath '" + $dest.Replace("'", "''") + "' -Filter 'LibreHardwareMonitorLog-*.csv' | Where-Object { \`$_.LastWriteTime -lt (Get-Date).AddDays(-2) } | Remove-Item -Force -ErrorAction SilentlyContinue"
        $cAction = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument ('-NoProfile -WindowStyle Hidden -Command "' + $cmd + '"')
        $cTriggers = @((New-ScheduledTaskTrigger -Daily -At '3:00'), (New-ScheduledTaskTrigger -AtLogOn -User $userId))
        $cPrincipal = New-ScheduledTaskPrincipal -UserId $userId -LogonType Interactive -RunLevel Highest
        $cSettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable
        Register-ScheduledTask -TaskName $cleanName -Action $cAction -Trigger $cTriggers -Principal $cPrincipal -Settings $cSettings -Force | Out-Null
    }
    elseif (Get-ScheduledTask -TaskName $cleanName -ErrorAction SilentlyContinue) {
        Unregister-ScheduledTask -TaskName $cleanName -Confirm:$false
    }
    $exePath = Join-Path $dest 'LibreHardwareMonitor.exe'
    $action = New-ScheduledTaskAction -Execute $exePath -WorkingDirectory $dest
    $trigger = New-ScheduledTaskTrigger -AtLogOn -User $userId
    $principal = New-ScheduledTaskPrincipal -UserId $userId -LogonType Interactive -RunLevel Highest
    $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero)
    Register-ScheduledTask -TaskName 'LibreHardwareMonitor' -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null

    Write-Status 'Starting LibreHardwareMonitor'
    Start-ScheduledTask -TaskName 'LibreHardwareMonitor'
    Write-Status $(if ($ConfigOnly) { 'Applied' } else { 'Installed' }) $true
}
catch {
    Write-Status 'Failed' $true $_.Exception.Message
    exit 1
}
finally {
    try { if (Test-Path -LiteralPath $work) { Remove-Item -LiteralPath $work -Recurse -Force } } catch { }
}
`;
  }
});

// src/lhm.js
var require_lhm = __commonJS({
  "src/lhm.js"(exports2, module2) {
    "use strict";
    var fs2 = require("fs");
    var path2 = require("path");
    var http = require("http");
    var { spawn: spawn2 } = require("child_process");
    var { EventEmitter } = require("events");
    var TYPE = {
      Temperature: ["temp", "\xB0C"],
      Fan: ["fan", "RPM"],
      Voltage: ["volt", "V"],
      Power: ["power", "W"],
      Clock: ["clock", "MHz"],
      Load: ["usage", "%"],
      Control: ["usage", "%"],
      Level: ["usage", "%"],
      Current: ["current", "A"],
      Frequency: ["clock", "Hz"],
      Throughput: ["rate", "B/s"],
      Data: ["data", "GB"],
      SmallData: ["smalldata", "MB"],
      Energy: ["energy", "mWh"],
      Noise: ["noise", "dBA"],
      Humidity: ["usage", "%"],
      Flow: ["flow", "L/h"],
      Factor: ["other", ""],
      TimeSpan: ["other", "s"]
    };
    var SEGMENT = {
      temperature: "Temperature",
      fan: "Fan",
      voltage: "Voltage",
      power: "Power",
      clock: "Clock",
      load: "Load",
      control: "Control",
      level: "Level",
      current: "Current",
      frequency: "Frequency",
      throughput: "Throughput",
      data: "Data",
      smalldata: "SmallData",
      energy: "Energy",
      noise: "Noise",
      humidity: "Humidity",
      flow: "Flow",
      factor: "Factor",
      timespan: "TimeSpan"
    };
    function parseTree(root) {
      const out = [];
      const walk = (node, hw) => {
        if (!node || typeof node !== "object") return;
        if (node.HardwareId) hw = node.Text || hw;
        if (node.SensorId && node.Type) {
          let v = node.RawValue;
          if (typeof v !== "number") v = parseFloat(String(node.Value || "").replace(",", "."));
          if (Number.isFinite(v)) {
            const [type, unit] = TYPE[node.Type] || ["other", ""];
            out.push({ id: "lhm:" + node.SensorId, hw: hw || "", name: node.Text || "", type, unit, v });
          }
        }
        for (const c of node.Children || []) walk(c, hw);
      };
      walk(root, "");
      return out;
    }
    function csvSplit(line) {
      const out = [];
      let cur = "";
      let q = false;
      for (let i = 0; i < line.length; i++) {
        const c = line[i];
        if (q) {
          if (c === '"' && line[i + 1] === '"') {
            cur += '"';
            i++;
          } else if (c === '"') q = false;
          else cur += c;
        } else if (c === '"') q = true;
        else if (c === ",") {
          out.push(cur);
          cur = "";
        } else cur += c;
      }
      out.push(cur);
      return out;
    }
    function hwFromId(id) {
      const p = String(id).split("/").filter(Boolean);
      const kind = (p[0] || "").toLowerCase();
      if (/cpu$/.test(kind)) return "CPU";
      if (/^gpu/.test(kind)) return "GPU";
      if (kind === "lpc" || kind === "motherboard") return p[1] ? `Motherboard (${p[1].toUpperCase()})` : "Motherboard";
      if (kind === "ram" || kind === "vram") return "Memory";
      if (/^(nvme|hdd|ssd|storage)/.test(kind)) return `Drive ${p[1] || ""}`.trim();
      if (kind === "nic") return "Network";
      if (kind === "battery") return "Battery";
      if (kind === "psu") return "Power supply";
      return kind ? kind.charAt(0).toUpperCase() + kind.slice(1) : "Other";
    }
    function parseLog(idLine, nameLine, lastLine) {
      const ids = csvSplit(idLine).slice(1);
      const names = csvSplit(nameLine).slice(1);
      const vals = csvSplit(lastLine).slice(1);
      const out = [];
      ids.forEach((id, i) => {
        const v = parseFloat(vals[i]);
        if (!id || !Number.isFinite(v)) return;
        const seg = (String(id).split("/").filter(Boolean).slice(-2)[0] || "").toLowerCase();
        const [type, unit] = TYPE[SEGMENT[seg]] || ["other", ""];
        out.push({ id: "lhm:" + id, hw: hwFromId(id), name: names[i] || id, type, unit, v });
      });
      return out;
    }
    function psQuote(s) {
      return "'" + String(s).replace(/'/g, "''") + "'";
    }
    var Lhm2 = class extends EventEmitter {
      constructor(log2, pluginDir) {
        super();
        this.log = log2;
        this.pluginDir = pluginDir;
        this.port = 8085;
        this.mode = "web";
        this.wanted = false;
        this.connected = false;
        this.readings = [];
        this.lastError = "";
        this.installing = null;
        this.installEndedAt = 0;
        this.timer = null;
        this.busy = false;
        this.logFile = null;
        this.programFiles = process.env.ProgramW6432 || process.env.ProgramFiles || "C:\\Program Files";
        this.host = process.env.SYSVITALS_LHM_HOST || "127.0.0.1";
      }
      get dir() {
        return process.env.SYSVITALS_LHM_DIR || path2.join(this.programFiles, "LibreHardwareMonitor");
      }
      get exePath() {
        return path2.join(this.dir, "LibreHardwareMonitor.exe");
      }
      get installed() {
        if (process.env.SYSVITALS_LHM_INSTALLED) return process.env.SYSVITALS_LHM_INSTALLED === "1";
        try {
          return fs2.existsSync(this.exePath);
        } catch (_) {
          return false;
        }
      }
      // Web server / log settings in its config file (readable without admin rights).
      get config() {
        try {
          const xml = fs2.readFileSync(path2.join(this.dir, "LibreHardwareMonitor.config"), "utf8");
          const get = (k) => (new RegExp(`key="${k}"\\s+value="([^"]*)"`).exec(xml) || [])[1];
          return { web: get("runWebServerMenuItem") === "true", log: get("logSensorsMenuItem") === "true", port: Number(get("listenerPort") || 8085) };
        } catch (_) {
          return null;
        }
      }
      configure({ port: port2, mode, wanted }) {
        const p = Number(port2) > 0 && Number(port2) < 65536 ? Math.round(Number(port2)) : 8085;
        const m = mode === "log" ? "log" : "web";
        const changed = p !== this.port || m !== this.mode;
        this.port = p;
        this.mode = m;
        if (changed) {
          this.logFile = null;
          this.setConnected(false);
        }
        if (wanted !== this.wanted || changed && wanted) {
          this.wanted = wanted;
          clearInterval(this.timer);
          this.timer = null;
          if (wanted) {
            this.poll();
            this.timer = setInterval(() => this.poll(), 2e3);
          } else {
            this.setConnected(false);
            this.readings = [];
          }
        }
      }
      setConnected(ok, why) {
        if (ok === this.connected) return;
        this.connected = ok;
        const how = this.mode === "log" ? "log file" : `web server on port ${this.port}`;
        if (ok) this.log.info(`LibreHardwareMonitor connected through its ${how} (${this.readings.length} readings)`);
        else if (why) this.log.info(`LibreHardwareMonitor ${how}: ${why}`);
        this.emit("status");
      }
      fail(why) {
        this.lastError = why;
        this.setConnected(false, why);
      }
      ok(list) {
        this.readings = list;
        this.lastError = "";
        this.setConnected(true);
        this.emit("readings", list);
      }
      poll() {
        if (this.mode === "log") return this.pollLog();
        if (this.busy) return;
        this.busy = true;
        const req = http.get({ host: this.host, port: this.port, path: "/data.json", timeout: 1500, headers: { Accept: "application/json" } }, (res) => {
          if (res.statusCode !== 200) {
            res.resume();
            this.busy = false;
            return this.fail(res.statusCode === 401 ? "the web server asks for a password" : `HTTP ${res.statusCode}`);
          }
          const chunks = [];
          res.on("data", (c) => chunks.push(c));
          res.on("end", () => {
            this.busy = false;
            try {
              this.ok(parseTree(JSON.parse(Buffer.concat(chunks).toString("utf8"))));
            } catch (e) {
              this.fail("unreadable data: " + e.message);
            }
          });
        });
        req.on("timeout", () => req.destroy(new Error("timed out")));
        req.on("error", (e) => {
          this.busy = false;
          this.fail(e.code === "ECONNREFUSED" ? "not running or web server off" : e.message);
        });
      }
      // Reads the newest line of the newest log file (only its last few KB).
      pollLog() {
        let files;
        try {
          files = fs2.readdirSync(this.dir).filter((f) => /^LibreHardwareMonitorLog-.*\.csv$/i.test(f));
        } catch (_) {
          return this.fail("its folder was not found");
        }
        if (!files.length) return this.fail("no log file yet (logging off?)");
        let newest = null;
        for (const f of files) {
          try {
            const st = fs2.statSync(path2.join(this.dir, f));
            if (!newest || st.mtimeMs > newest.mtime) newest = { name: f, mtime: st.mtimeMs, size: st.size };
          } catch (_) {
          }
        }
        if (!newest) return this.fail("log file unreadable");
        if (Date.now() - newest.mtime > 15e3) return this.fail("log file not updating (not running?)");
        const file = path2.join(this.dir, newest.name);
        let fd;
        try {
          fd = fs2.openSync(file, "r");
          if (!this.logFile || this.logFile.name !== newest.name) {
            const head = Buffer.alloc(Math.min(newest.size, 512 * 1024));
            const n2 = fs2.readSync(fd, head, 0, head.length, 0);
            const lines2 = head.slice(0, n2).toString("utf8").replace(/^\uFEFF/, "").split(/\r?\n/);
            if (lines2.length < 3) return this.fail("log file has no readings yet");
            this.logFile = { name: newest.name, idLine: lines2[0], nameLine: lines2[1] };
          }
          const len = Math.min(newest.size, 64 * 1024);
          const tail = Buffer.alloc(len);
          const n = fs2.readSync(fd, tail, 0, len, newest.size - len);
          const lines = tail.slice(0, n).toString("utf8").split(/\r?\n/).filter((l) => l.trim());
          const last = lines[lines.length - 1];
          if (!last || last.startsWith(",") || last.startsWith("Time,")) return this.fail("log file has no readings yet");
          this.ok(parseLog(this.logFile.idLine, this.logFile.nameLine, last));
        } catch (e) {
          this.fail("log file unreadable: " + e.message);
        } finally {
          if (fd !== void 0) fs2.closeSync(fd);
        }
      }
      // Start the installed copy. Its startup task runs it with admin rights without a prompt.
      start() {
        this.log.info("Starting LibreHardwareMonitor");
        const p = spawn2("schtasks.exe", ["/Run", "/TN", "LibreHardwareMonitor"], { windowsHide: true, stdio: "ignore" });
        p.on("error", () => this.startExe());
        p.on("exit", (code) => {
          if (code !== 0) this.startExe();
        });
      }
      startExe() {
        if (!this.installed) return;
        try {
          const p = spawn2("cmd.exe", ["/c", "start", "", this.exePath], { detached: true, windowsHide: true, stdio: "ignore" });
          p.on("error", (e) => this.log.warn("Could not start LibreHardwareMonitor", e.message));
          p.unref();
        } catch (e) {
          this.log.warn("Could not start LibreHardwareMonitor", e.message);
        }
      }
      // Install / update (configOnly=false), or only switch it to the chosen way of
      // sharing readings (configOnly=true). Both need Windows' permission once.
      install(configOnly) {
        if (this.installing && !this.installing.done) return;
        const what = configOnly ? "apply" : "install";
        const dir = path2.join(this.pluginDir, "runtime");
        fs2.mkdirSync(dir, { recursive: true });
        const script = path2.join(dir, "install-lhm.ps1");
        const statusFile = path2.join(dir, "install-lhm.status.json");
        fs2.writeFileSync(script, "\uFEFF" + require_install_lhm(), "utf8");
        try {
          fs2.unlinkSync(statusFile);
        } catch (_) {
        }
        const user = process.env.USERDOMAIN && process.env.USERNAME ? `${process.env.USERDOMAIN}\\${process.env.USERNAME}` : "";
        const ps = path2.join(process.env.SystemRoot || "C:\\Windows", "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
        const inner = ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", `"${script}"`, "-Port", String(this.port), "-Mode", this.mode, "-StatusFile", `"${statusFile}"`];
        if (user) inner.push("-User", `"${user}"`);
        if (configOnly) inner.push("-ConfigOnly");
        const cmd = `Start-Process -FilePath ${psQuote(ps)} -Verb RunAs -Wait -WindowStyle Hidden -ArgumentList @(${inner.map(psQuote).join(",")})`;
        this.installing = { step: "Waiting for Windows permission", done: false, error: "", what };
        this.emit("status");
        this.log.info(`${configOnly ? "Switching LibreHardwareMonitor to its " + this.mode + " setting" : "Installing LibreHardwareMonitor (" + this.mode + ")"} (asking Windows for permission)`);
        let errText = "";
        const proc = spawn2(process.env.SYSVITALS_INSTALL_SHELL || ps, ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", cmd], { windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
        proc.stderr.on("data", (d) => errText += d);
        proc.on("error", (e) => errText += e.message);
        const read = () => {
          try {
            const st = JSON.parse(fs2.readFileSync(statusFile, "utf8").replace(/^\uFEFF/, ""));
            if (st.step !== this.installing.step || st.done !== this.installing.done) {
              this.installing = { step: st.step, done: !!st.done, error: st.error || "", what };
              this.emit("status");
            }
          } catch (_) {
          }
        };
        const watch = setInterval(read, 500);
        proc.on("exit", (code) => {
          clearInterval(watch);
          read();
          this.installEndedAt = Date.now();
          if (!this.installing.done) {
            const cancelled = /cancel/i.test(errText);
            this.installing = { step: "Failed", done: true, what, error: cancelled ? "Windows permission was not given" : (errText.trim().split("\n")[0] || `stopped (code ${code})`).slice(0, 200) };
          }
          if (this.installing.error) this.log.warn(`LibreHardwareMonitor ${what} failed:`, this.installing.error);
          else this.log.info(configOnly ? "LibreHardwareMonitor settings applied and restarted" : "LibreHardwareMonitor installed and started");
          this.logFile = null;
          this.emit("status");
          setTimeout(() => this.poll(), 3e3);
          setTimeout(() => this.poll(), 8e3);
        });
      }
    };
    module2.exports = { Lhm: Lhm2, parseTree, parseLog, csvSplit, hwFromId };
  }
});

// src/svg.js
var require_svg = __commonJS({
  "src/svg.js"(exports2, module2) {
    "use strict";
    var FONT = "Segoe UI, Inter, Arial, sans-serif";
    var C = {
      bg: "rgb(11,12,15)",
      panel: "rgb(21,23,28)",
      track: "rgb(36,39,46)",
      grid: "rgb(30,33,39)",
      line: "rgb(54,58,67)",
      text: "rgb(238,240,244)",
      muted: "rgb(140,147,160)",
      dim: "rgb(84,90,101)",
      cpu: "rgb(96,165,250)",
      mem: "rgb(167,139,250)",
      disk: "rgb(232,121,249)",
      down: "rgb(56,189,248)",
      up: "rgb(251,146,60)",
      sys: "rgb(45,212,191)",
      sensor: "rgb(250,204,21)",
      nvidia: "rgb(118,185,0)",
      amd: "rgb(255,96,96)",
      intel: "rgb(64,156,255)",
      gpu: "rgb(45,212,191)",
      good: "rgb(74,222,128)",
      warn: "rgb(251,191,36)",
      bad: "rgb(248,81,73)",
      power: "rgb(250,204,21)",
      fan: "rgb(103,232,249)",
      volt: "rgb(196,181,253)"
    };
    function r(n) {
      return Math.round(n * 10) / 10;
    }
    function esc(s) {
      return String(s == null ? "" : s).replace(/[\u0000-\u001f]/g, " ").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/#/g, "\uFF03").replace(/%/g, "\uFF05").trim();
    }
    function textWidth(str, size, bold) {
      let w = 0;
      for (const ch of String(str)) {
        if (/[ilI.,:;'|!]/.test(ch)) w += 0.28;
        else if (/[fjrt()\[\]]/.test(ch)) w += 0.36;
        else if (/[mwMW@]/.test(ch)) w += 0.86;
        else if (/[A-Z]/.test(ch)) w += 0.64;
        else if (/[0-9]/.test(ch)) w += 0.6;
        else if (ch === " ") w += 0.27;
        else if (ch === "\xB0") w += 0.4;
        else if (ch === "\u2026") w += 0.8;
        else if (ch.charCodeAt(0) > 11904) w += 1;
        else w += 0.53;
      }
      return w * size * (bold ? 1.06 : 1);
    }
    function fit(str, size, maxWidth, bold) {
      str = String(str == null ? "" : str).trim();
      if (textWidth(str, size, bold) <= maxWidth) return str;
      const chars = Array.from(str);
      while (chars.length > 1 && textWidth(chars.join("") + "\u2026", size, bold) > maxWidth) chars.pop();
      return chars.join("").trimEnd() + "\u2026";
    }
    function fitSize(str, size, maxWidth, bold, min = 19) {
      let s = size;
      while (s > min && textWidth(str, s, bold) > maxWidth) s -= 1;
      return s;
    }
    function text(x, y, str, { size = 22, fill = C.text, weight = 600, anchor = "start", opacity } = {}) {
      const s = esc(str);
      if (!s) return "";
      const op = opacity != null ? ` fill-opacity="${opacity}"` : "";
      return `<text x="${r(x)}" y="${r(y)}" font-family="${FONT}" font-size="${size}" font-weight="${weight}" fill="${fill}"${op} text-anchor="${anchor}">${s}</text>`;
    }
    function pctGlyph(x, y, size, color) {
      const s = size;
      const sw = Math.max(1.6, s * 0.085);
      const rad = s * 0.115;
      return `<g fill="none" stroke="${color}" stroke-width="${r(sw)}" stroke-linecap="round"><circle cx="${r(x + s * 0.16)}" cy="${r(y - s * 0.56)}" r="${r(rad)}"/><circle cx="${r(x + s * 0.48)}" cy="${r(y - s * 0.15)}" r="${r(rad)}"/><line x1="${r(x + s * 0.52)}" y1="${r(y - s * 0.71)}" x2="${r(x + s * 0.12)}" y2="${r(y)}"/></g>`;
    }
    var PCT_W = 0.66;
    function rich(x, y, segs, { anchor = "start", size = 22, fill = C.text, weight = 600 } = {}) {
      const parts = segs.filter((p) => p && p.t !== "" && p.t != null).map((p) => ({ t: String(p.t), size: p.size || size, fill: p.fill || fill, weight: p.weight || weight, gap: p.gap || 0 }));
      const width = (p) => p.t === "%" ? p.size * PCT_W : textWidth(p.t, p.size, p.weight >= 600);
      const total = parts.reduce((a, p) => a + width(p) + p.gap, 0);
      let cx = anchor === "middle" ? x - total / 2 : anchor === "end" ? x - total : x;
      let out = "";
      for (const p of parts) {
        cx += p.gap;
        if (p.t === "%") out += pctGlyph(cx + p.size * 0.04, y, p.size, p.fill);
        else {
          const lead = p.t.length - p.t.trimStart().length;
          const body = p.t.trim();
          const lx = cx + textWidth(" ".repeat(lead), p.size);
          if (body) out += `<text x="${r(lx)}" y="${r(y)}" font-family="${FONT}" font-size="${p.size}" font-weight="${p.weight}" fill="${p.fill}">${esc(body)}</text>`;
        }
        cx += width(p);
      }
      return out;
    }
    function richWidth(segs, size = 22, weight = 600) {
      return segs.filter(Boolean).reduce((a, p) => {
        const s = p.size || size;
        const wgt = p.weight || weight;
        return a + (p.gap || 0) + (p.t === "%" ? s * PCT_W : textWidth(p.t, s, wgt >= 600));
      }, 0);
    }
    function rect(x, y, w, h, fill, { rx = 0, opacity, stroke, sw } = {}) {
      const op = opacity != null ? ` fill-opacity="${opacity}"` : "";
      const st = stroke ? ` stroke="${stroke}" stroke-width="${sw || 1}"` : "";
      return `<rect x="${r(x)}" y="${r(y)}" width="${r(Math.max(0, w))}" height="${r(Math.max(0, h))}" rx="${rx}" ry="${rx}" fill="${fill}"${op}${st}/>`;
    }
    function circle(cx, cy, rad, fill, { opacity, stroke, sw } = {}) {
      const op = opacity != null ? ` fill-opacity="${opacity}"` : "";
      const st = stroke ? ` stroke="${stroke}" stroke-width="${sw || 1}"` : "";
      return `<circle cx="${r(cx)}" cy="${r(cy)}" r="${r(rad)}" fill="${fill}"${op}${st}/>`;
    }
    function line(x1, y1, x2, y2, stroke, sw = 2, opacity) {
      const op = opacity != null ? ` stroke-opacity="${opacity}"` : "";
      return `<line x1="${r(x1)}" y1="${r(y1)}" x2="${r(x2)}" y2="${r(y2)}" stroke="${stroke}" stroke-width="${sw}" stroke-linecap="round"${op}/>`;
    }
    function meter(x, y, w, h, frac, color, { segs = 10, gap = 3, track = C.track } = {}) {
      frac = Math.max(0, Math.min(1, Number(frac) || 0));
      const sw = (w - gap * (segs - 1)) / segs;
      const lit = frac * segs;
      let out = "";
      for (let i = 0; i < segs; i++) {
        const sx = x + i * (sw + gap);
        out += rect(sx, y, sw, h, track, { rx: 2 });
        const part = Math.max(0, Math.min(1, lit - i));
        if (part > 0.04) out += rect(sx, y, sw * part, h, color, { rx: 2 });
      }
      return out;
    }
    function bar(x, y, w, h, frac, color, { track = C.track } = {}) {
      frac = Math.max(0, Math.min(1, Number(frac) || 0));
      const rx = Math.min(h / 2, 4);
      let out = rect(x, y, w, h, track, { rx });
      if (frac > 5e-3) out += rect(x, y, Math.max(h, w * frac), h, color, { rx });
      return out;
    }
    function spark(x, y, w, h, values, color, { max, min = 0, fillOpacity = 0.18, sw = 3 } = {}) {
      const n = values ? values.length : 0;
      if (n < 2) return "";
      const finite = values.filter((v) => Number.isFinite(v));
      if (!finite.length) return "";
      const top = max != null ? max : Math.max(...finite, 1e-9);
      const span = Math.max(1e-9, top - min);
      let out = "";
      let run = [];
      const flush = () => {
        if (run.length >= 2) {
          const pts = run.map(([px, py]) => `${r(px)},${r(py)}`).join(" ");
          const area = `${r(run[0][0])},${r(y + h)} ${pts} ${r(run[run.length - 1][0])},${r(y + h)}`;
          if (fillOpacity > 0) out += `<polygon points="${area}" fill="${color}" fill-opacity="${fillOpacity}"/>`;
          out += `<polyline points="${pts}" fill="none" stroke="${color}" stroke-width="${sw}" stroke-linejoin="round" stroke-linecap="round"/>`;
        } else if (run.length === 1) {
          out += circle(run[0][0], run[0][1], sw / 2 + 0.5, color);
        }
        run = [];
      };
      values.forEach((v, i) => {
        if (!Number.isFinite(v)) return flush();
        const px = x + w * i / (n - 1);
        const fv = Math.max(0, Math.min(1, (v - min) / span));
        run.push([px, y + h - fv * h]);
      });
      flush();
      return out;
    }
    var ICONS = {
      cpu: '<rect x="5" y="5" width="14" height="14" rx="2.5"/><rect x="9.5" y="9.5" width="5" height="5" rx="1"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/>',
      gpu: '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="15" cy="12" r="3.2"/><path d="M6 10h4M6 14h4M5 18v3M9 18v3"/>',
      ram: '<rect x="2" y="6" width="20" height="11" rx="2"/><path d="M6 10v3M10 10v3M14 10v3M18 10v3M5 17v3M19 17v3"/>',
      disk: '<rect x="3" y="4" width="18" height="16" rx="2.5"/><circle cx="12" cy="11" r="4"/><path d="M12 11h.01M7 17h3"/>',
      down: '<path d="M12 4v15M6 13l6 6 6-6"/>',
      up: '<path d="M12 20V5M6 11l6-6 6 6"/>',
      net: '<circle cx="12" cy="12" r="9.5"/><path d="M2.5 12h19M12 2.5c2.6 2.7 4 6 4 9.5s-1.4 6.8-4 9.5c-2.6-2.7-4-6-4-9.5s1.4-6.8 4-9.5z"/>',
      link: '<path d="M7 3h10v7a5 5 0 0 1-10 0V3zM12 15v6M9 3v3M15 3v3"/>',
      pin: '<path d="M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
      clock: '<circle cx="12" cy="12" r="9.5"/><path d="M12 6.5V12l3.5 2"/>',
      battery: '<rect x="2" y="7" width="17" height="10" rx="2"/><path d="M22 10.5v3"/>',
      plug: '<path d="M9 2v6M15 2v6M6 8h12v3a6 6 0 0 1-12 0V8zM12 17v5"/>',
      bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z"/>',
      fan: '<circle cx="12" cy="12" r="2"/><path d="M12 10c-1-4 0-7.5 3-7.5 2.5 0 3 3-1 6.5M14 12c4-1 7.5 0 7.5 3 0 2.5-3 3-6.5-1M12 14c1 4 0 7.5-3 7.5-2.5 0-3-3 1-6.5M10 12c-4 1-7.5 0-7.5-3 0-2.5 3-3 6.5 1"/>',
      gauge: '<path d="M3.5 17a9 9 0 1 1 17 0"/><path d="M12 13l4.5-5"/><circle cx="12" cy="13" r="1.4"/>',
      thermo: '<path d="M14 14.8V4.5a2.5 2.5 0 0 0-5 0v10.3a4.5 4.5 0 1 0 5 0z"/><path d="M11.5 10v7"/>',
      flame: '<path d="M12 22c4 0 7-2.8 7-6.8 0-3.7-2.6-6-4.2-8.7-.5 2.2-1.6 3.4-2.8 4C12.3 7.6 10.9 4.4 8 2c.3 3.5-3 6.4-3 11.2C5 19.2 8 22 12 22z"/>',
      list: '<path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01"/>',
      bars: '<path d="M5 20V10M10 20V4M15 20v-8M20 20V7"/>',
      pulse: '<path d="M22 12h-4l-3 8L9 4l-3 8H2"/>',
      monitor: '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/>',
      layers: '<path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/>',
      sensor: '<circle cx="12" cy="12" r="3"/><path d="M6.3 6.3a8 8 0 0 0 0 11.4M17.7 6.3a8 8 0 0 1 0 11.4M3.5 3.5a12 12 0 0 0 0 17M20.5 3.5a12 12 0 0 1 0 17"/>',
      volt: '<path d="M4 4l8 16 8-16"/>',
      refresh: '<path d="M21 12a9 9 0 1 1-2.6-6.4"/><path d="M21 3v6h-6"/>',
      warn: '<path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9.5v4M12 17.2h.01"/>',
      off: '<circle cx="12" cy="12" r="9.5"/><path d="M5.5 5.5l13 13"/>',
      sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
      stack: '<rect x="3" y="3" width="18" height="6" rx="1.5"/><rect x="3" y="15" width="18" height="6" rx="1.5"/><path d="M7 6h.01M7 18h.01"/>'
    };
    function icon(name, x, y, size, color, sw = 2) {
      const body = ICONS[name];
      if (!body) return "";
      const s = size / 24;
      return `<g transform="translate(${r(x)} ${r(y)}) scale(${Math.round(s * 1e3) / 1e3})" fill="none" stroke="${color}" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round">${body}</g>`;
    }
    var LABEL = 22;
    function header(x, y, label, iconName, color, right, rightColor) {
      let out = "";
      let rw = 0;
      if (right) {
        const segs = typeof right === "string" ? [{ t: right }] : right;
        rw = richWidth(segs, LABEL, 700) + 6;
        out += rich(x + 134, y + 31, segs, { anchor: "end", size: LABEL, fill: rightColor || C.muted, weight: 700 });
      }
      const lab = String(label || "").toUpperCase();
      let lx = x + 10;
      if (iconName && textWidth(lab, LABEL, true) <= x + 134 - rw - (x + 40)) {
        out += icon(iconName, x + 9, y + 12, 23, color, 2.4);
        lx = x + 39;
      }
      out += text(lx, y + 31, fit(lab, LABEL, x + 134 - rw - lx, true), { size: LABEL, fill: C.muted, weight: 700 });
      return out;
    }
    function wrapSvg(content, w = 144, h = 144, ox = 0, oy = 0) {
      return `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">` + rect(0, 0, w, h, C.bg) + (ox || oy ? `<g transform="translate(${-ox} ${-oy})">${content}</g>` : content) + "</svg>";
    }
    function toDataUrl(svg) {
      return "data:image/svg+xml;charset=utf8," + svg.replace(/#/g, "").replace(/%/g, "");
    }
    function mix(a, b, t) {
      const pa = a.match(/\d+/g).map(Number);
      const pb = b.match(/\d+/g).map(Number);
      t = Math.max(0, Math.min(1, t));
      return `rgb(${pa.map((v, i) => Math.round(v + (pb[i] - v) * t)).join(",")})`;
    }
    function tempColor(c, { warm = 70, hot = 88 } = {}) {
      if (c == null || !Number.isFinite(c)) return C.dim;
      const cool = warm - 25;
      if (c <= cool) return C.good;
      if (c <= warm) return mix(C.good, C.warn, (c - cool) / (warm - cool));
      return mix(C.warn, C.bad, (c - warm) / (hot - warm));
    }
    function usageColor(frac, base) {
      if (frac >= 0.92) return C.bad;
      if (frac >= 0.8) return C.warn;
      return base;
    }
    function fmtBytes(n, digits) {
      n = Number(n) || 0;
      const units = ["B", "KB", "MB", "GB", "TB", "PB"];
      let i = 0;
      while (Math.abs(n) >= 1e3 && i < units.length - 1) {
        n /= 1024;
        i++;
      }
      const d = digits != null ? digits : n >= 100 || i === 0 ? 0 : n >= 10 ? 1 : 2;
      return { value: trimZeros(n.toFixed(d)), unit: units[i] };
    }
    function fmtRate(bytesPerSec, bits) {
      let n = Number(bytesPerSec) || 0;
      if (bits) {
        n *= 8;
        const units2 = ["b/s", "Kb/s", "Mb/s", "Gb/s"];
        let i2 = 0;
        while (n >= 1e3 && i2 < units2.length - 1) {
          n /= 1e3;
          i2++;
        }
        return { value: n.toFixed(n >= 100 || i2 === 0 ? 0 : n >= 10 ? 1 : 2), unit: units2[i2] };
      }
      const units = ["B/s", "KB/s", "MB/s", "GB/s"];
      let i = 0;
      while (n >= 1e3 && i < units.length - 1) {
        n /= 1024;
        i++;
      }
      return { value: n.toFixed(n >= 100 || i === 0 ? 0 : n >= 10 ? 1 : 2), unit: units[i] };
    }
    function trimZeros(s) {
      return s.includes(".") ? s.replace(/\.?0+$/, "") : s;
    }
    function fmtTemp(c, unit) {
      if (c == null || !Number.isFinite(c)) return null;
      if (unit === "F") return { value: String(Math.round(c * 9 / 5 + 32)), unit: "\xB0F", short: Math.round(c * 9 / 5 + 32) + "\xB0" };
      return { value: String(Math.round(c)), unit: "\xB0C", short: Math.round(c) + "\xB0" };
    }
    function fmtDuration(sec) {
      sec = Math.max(0, Math.floor(Number(sec) || 0));
      const d = Math.floor(sec / 86400);
      const h = Math.floor(sec % 86400 / 3600);
      const m = Math.floor(sec % 3600 / 60);
      if (d > 0) return { value: String(d), unit: "d", extra: `${h}h ${m}m` };
      if (h > 0) return { value: String(h), unit: "h", extra: `${m} min` };
      return { value: String(m), unit: "min", extra: "" };
    }
    function fmtMhz(mhz) {
      if (mhz == null || !Number.isFinite(mhz)) return null;
      if (mhz >= 1e3) return { value: (mhz / 1e3).toFixed(2), unit: "GHz" };
      return { value: String(Math.round(mhz)), unit: "MHz" };
    }
    module2.exports = {
      C,
      FONT,
      LABEL,
      r,
      esc,
      text,
      rich,
      richWidth,
      pctGlyph,
      textWidth,
      fit,
      fitSize,
      rect,
      circle,
      line,
      meter,
      bar,
      spark,
      icon,
      ICONS,
      header,
      wrapSvg,
      toDataUrl,
      mix,
      tempColor,
      usageColor,
      fmtBytes,
      fmtRate,
      fmtTemp,
      fmtDuration,
      fmtMhz,
      trimZeros
    };
  }
});

// src/render.js
var require_render = __commonJS({
  "src/render.js"(exports2, module2) {
    "use strict";
    var S2 = require_svg();
    var { buildGroups: buildGroups2 } = require_layout();
    var { C, text, rich, fit, fitSize, rect, circle, meter, spark, icon, header, textWidth } = S2;
    var K = 144;
    var GAP = 28;
    var PITCH = K + GAP;
    var BIG = 52;
    var SUB = 20;
    var ACTIONS = {
      cpu: { shows: ["load", "temp", "clock", "power", "cores", "graph", "top"], order: ["load", "temp", "clock", "power", "top"], span: ["graph", "cores"] },
      memory: { shows: ["used", "amount", "avail", "commit", "graph", "top"], order: ["used", "amount", "commit", "top"], span: ["graph"] },
      gpu: { shows: ["load", "temp", "hot", "vram", "power", "fan", "clock", "graph"], order: ["load", "temp", "vram", "power", "clock", "fan", "hot"], span: ["graph"] },
      disk: { shows: ["activity", "read", "write", "rw", "space", "free", "graph"], order: ["activity", "read", "write", "space", "free"], span: ["graph"] },
      network: { shows: ["both", "down", "up", "link", "ip", "graph"], order: ["down", "up", "link", "ip"], span: ["graph"] },
      system: { shows: ["summary", "uptime", "battery", "procs", "graph"], order: ["summary", "uptime", "battery", "procs"], span: ["graph"] },
      sensor: { shows: ["value", "graph"], order: ["value"], span: ["graph"] },
      setup: { shows: ["status"], order: ["status"], span: [] }
    };
    function groupSize(w, h) {
      return { W: w * K + (w - 1) * GAP, H: h * K + (h - 1) * GAP };
    }
    var fin = (v) => v != null && Number.isFinite(Number(v));
    var pct = (v) => fin(v) ? String(Math.round(v)) : "--";
    function bigValue(x, y, value, unit, { fill = C.text, size = BIG, unitSize, maxW = 130 } = {}) {
      const u = unit || "";
      const ratio = (unitSize || Math.round(size * 0.5)) / size;
      let s = size;
      const segs = (sz) => [{ t: String(value), size: sz, weight: 700 }, u ? { t: u, size: Math.max(19, Math.round(sz * ratio)), gap: 3, weight: 600 } : null];
      while (s > 30 && S2.richWidth(segs(s)) > maxW) s -= 2;
      const parts = segs(s);
      if (u && u !== "%") {
        const us = parts[1].size;
        return `<text x="${S2.r(x)}" y="${S2.r(y)}" font-family="${S2.FONT}" font-size="${s}" font-weight="700" fill="${fill}" text-anchor="middle">${S2.esc(value)}<tspan dx="3" font-size="${us}" font-weight="600" fill="${C.muted}">${S2.esc(u)}</tspan></text>`;
      }
      if (parts[1]) parts[1].fill = C.muted;
      return rich(x, y, parts, { anchor: "middle", fill });
    }
    function stat(x, y, o) {
      let out = header(x, y, o.label, o.icon, o.accent, o.right, o.rightColor);
      const hasMeter = o.meter != null;
      const hasSub = !!o.sub;
      const hasSpark = o.spark && o.spark.length > 1;
      let vy = 98;
      if (hasMeter && hasSub) vy = 84;
      else if (hasSub && hasSpark) vy = 84;
      else if (hasSub) vy = 92;
      else if (hasSpark) vy = 92;
      out += bigValue(x + 72, y + vy, o.value, o.unit, { fill: o.valueColor || C.text });
      if (hasMeter) {
        const my = hasSub ? y + 96 : y + 112;
        out += meter(x + 14, my, 116, hasSub ? 11 : 15, o.meter, o.meterColor || o.accent);
      }
      if (hasSub) out += text(x + 72, y + (hasSpark ? 112 : 132), fit(o.sub, SUB, 134, true), { size: SUB, fill: o.subColor || C.muted, weight: 600, anchor: "middle" });
      if (hasSpark && !hasMeter) {
        const top = hasSub ? y + 118 : y + 108;
        out += spark(x + 10, top, 124, y + 136 - top, o.spark, o.sparkColor || o.accent, { max: o.sparkMax, fillOpacity: 0.22, sw: 2.5 });
      }
      return out;
    }
    function wrapWords(str, size, width, maxLines, bold) {
      const words = String(str || "").split(/\s+/).filter(Boolean);
      const lines = [];
      let cur = "";
      let i = 0;
      for (; i < words.length; i++) {
        const t = cur ? cur + " " + words[i] : words[i];
        if (textWidth(t, size, bold) <= width) {
          cur = t;
          continue;
        }
        if (cur) lines.push(cur);
        if (lines.length >= maxLines) {
          cur = "";
          break;
        }
        cur = textWidth(words[i], size, bold) > width ? fit(words[i], size, width, bold) : words[i];
      }
      if (cur && lines.length < maxLines) lines.push(cur);
      if (i < words.length && lines.length) lines[lines.length - 1] = fit(lines[lines.length - 1] + " " + words.slice(i).join(" "), size, width, bold);
      return lines;
    }
    function message(x, y, iconName, color, title, sub) {
      let out = icon(iconName, x + 50, y + 14, 44, color, 2.2);
      const lines = wrapWords(title, 21, 132, sub ? 1 : 2, true);
      const y0 = sub ? 88 : lines.length > 1 ? 86 : 98;
      lines.forEach((l, i) => out += text(x + 72, y + y0 + i * 25, l, { size: 21, weight: 700, anchor: "middle" }));
      if (sub) out += text(x + 72, y + 118, fit(sub, SUB, 134, true), { size: SUB, fill: C.muted, weight: 600, anchor: "middle" });
      return out;
    }
    function statusKeys(w, h, kind, msg, sub) {
      const colors = { starting: C.cpu, error: C.warn };
      const icons = { starting: "refresh", error: "warn" };
      let out = "";
      for (let dy = 0; dy < h; dy++)
        for (let dx = 0; dx < w; dx++) {
          const x = dx * PITCH;
          const y = dy * PITCH;
          if (dx === 0 && dy === 0) out += message(x, y, icons[kind] || "pulse", colors[kind] || C.cpu, msg, sub);
          else out += icon("pulse", x + 50, y + 50, 44, C.track, 2.2);
        }
      return out;
    }
    function resample(values, n) {
      if (values.length <= n) return values;
      const out = [];
      const step = values.length / n;
      for (let i = 0; i < n; i++) {
        let sum = 0;
        let cnt = 0;
        for (let k = Math.floor(i * step); k < Math.floor((i + 1) * step); k++) {
          const v = values[k];
          if (Number.isFinite(v)) {
            sum += v;
            cnt++;
          }
        }
        out.push(cnt ? sum / cnt : NaN);
      }
      return out;
    }
    function graphTime(settings) {
      const t = Number(settings && settings.graphTime);
      return [60, 120, 300, 600].includes(t) ? t : 120;
    }
    function series(ctx, key, settings, width) {
      const secs = graphTime(settings);
      return resample(ctx.store.series(key, secs), Math.max(12, Math.round(width / 4)));
    }
    function sparkFor(ctx, key) {
      return resample(ctx.store.series(key, 60), 30);
    }
    function tempUnit(settings) {
      return settings && settings.tempUnit === "F" ? "F" : "C";
    }
    function cpuCell(role, x, y, ctx, st) {
      const s = ctx.store;
      const cpu = s.cur.cpu || {};
      const t = s.cpuTemp;
      const tf = t ? S2.fmtTemp(t.c, tempUnit(st)) : null;
      switch (role) {
        case "load": {
          const f = fin(cpu.load) ? cpu.load / 100 : 0;
          const col = S2.usageColor(f, C.cpu);
          return stat(x, y, { label: "CPU", icon: "cpu", accent: C.cpu, right: tf ? tf.short : "", rightColor: t ? S2.tempColor(t.c) : C.muted, value: pct(cpu.load), unit: "%", valueColor: col === C.cpu ? C.text : col, meter: f, meterColor: col });
        }
        case "temp": {
          if (!t) return needSetup(x, y, "thermo", ctx);
          return stat(x, y, { label: "TEMP", icon: "cpu", accent: C.cpu, value: tf.value, unit: tf.unit, valueColor: t.c >= 80 ? S2.tempColor(t.c) : C.text, meter: t.c / 100, meterColor: S2.tempColor(t.c) });
        }
        case "clock": {
          const m = S2.fmtMhz(cpu.mhz);
          if (!m) return message(x, y, "gauge", C.dim, "No clock", "speed yet");
          const base = S2.fmtMhz(s.info && s.info.cpu && s.info.cpu.baseMhz);
          return stat(x, y, { label: "CLOCK", icon: "cpu", accent: C.cpu, value: m.value, unit: m.unit, sub: base ? `Base ${Number(base.value).toFixed(1)} ${base.unit}` : "", spark: sparkFor(ctx, "cpu"), sparkMax: 100 });
        }
        case "power": {
          const p = s.cpuPower;
          if (!p) return needSetup(x, y, "bolt", ctx);
          return stat(x, y, { label: "POWER", icon: "cpu", accent: C.power, value: String(Math.round(p.w)), unit: "W", spark: sparkFor(ctx, "cpuPower"), sparkColor: C.power });
        }
        case "top":
          return topCell(x, y, ctx, "cpu");
        default:
          return "";
      }
    }
    var APP_NAMES = {
      msedge: "Edge",
      chrome: "Chrome",
      firefox: "Firefox",
      explorer: "Explorer",
      svchost: "Services",
      dwm: "Desktop",
      MsMpEng: "Defender",
      System: "System",
      Registry: "Registry",
      "Memory Compression": "Memory comp.",
      steam: "Steam",
      steamwebhelper: "Steam",
      discord: "Discord",
      Code: "VS Code",
      spotify: "Spotify",
      Spotify: "Spotify",
      obs64: "OBS",
      powershell: "PowerShell",
      node: "Node",
      Teams: "Teams",
      "ms-teams": "Teams",
      OUTLOOK: "Outlook",
      WINWORD: "Word",
      EXCEL: "Excel",
      POWERPNT: "PowerPoint",
      vmmem: "Virtual machine",
      vmmemWSL: "WSL",
      Taskmgr: "Task Manager",
      SearchHost: "Search",
      StartMenuExperienceHost: "Start menu",
      audiodg: "Audio",
      csrss: "Windows",
      "Stream Dock AJAZZ Global": "Stream Dock"
    };
    function appName(n) {
      if (APP_NAMES[n]) return APP_NAMES[n];
      const lower = Object.keys(APP_NAMES).find((k) => k.toLowerCase() === String(n).toLowerCase());
      if (lower) return APP_NAMES[lower];
      return String(n).charAt(0).toUpperCase() + String(n).slice(1);
    }
    function topCell(x, y, ctx, kind) {
      const top = ctx.store.cur.top;
      const list = top && top[kind];
      const accent = kind === "cpu" ? C.cpu : C.mem;
      let out = header(x, y, "TOP", kind === "cpu" ? "cpu" : "ram", accent);
      if (!list || !list.length) return out + text(x + 72, y + 96, "Loading\u2026", { size: 21, fill: C.muted, weight: 600, anchor: "middle" });
      const [name, v] = list[0];
      const label = appName(name);
      const ns = fitSize(label, 28, 130, true, 19);
      out += text(x + 72, y + 78, fit(label, ns, 132, true), { size: ns, weight: 700, anchor: "middle" });
      if (kind === "cpu") out += bigValue(x + 72, y + 128, String(Math.round(v)), "%", { size: 42 });
      else {
        const b = S2.fmtBytes(v);
        out += bigValue(x + 72, y + 128, b.value, b.unit, { size: 42 });
      }
      return out;
    }
    function coresRegion(reg, ctx) {
      const cores = ctx.store.cur.cpu && ctx.store.cur.cpu.cores || [];
      const cells = [];
      for (let dy = 0; dy < reg.h; dy++) for (let dx = 0; dx < reg.w; dx++) cells.push({ x: reg.x + dx * PITCH, y: reg.y + dy * PITCH });
      if (!cores.length) return message(cells[0].x, cells[0].y, "bars", C.dim, "Loading\u2026");
      const from = (k) => Math.floor(k * cores.length / cells.length);
      let out = "";
      cells.forEach((c, k) => {
        const sub = cores.slice(from(k), from(k + 1));
        if (k === 0) {
          out += header(c.x, c.y, "CORES", "cpu", C.cpu, [{ t: pct(Math.max(...cores)), weight: 700 }, { t: "%", fill: C.muted, size: 20 }], C.text);
        } else if (sub.length) {
          const a = from(k) + 1;
          const b = from(k) + sub.length;
          out += text(c.x + 12, c.y + 31, a === b ? `CORE ${a}` : `${a}\u2013${b}`, { size: SUB, fill: C.muted, weight: 700 });
        }
        if (!sub.length) return;
        const n = sub.length;
        const gap = n > 24 ? 1.2 : n > 12 ? 2 : 4;
        const bw = (124 - gap * (n - 1)) / n;
        const top = c.y + 44;
        const hgt = 90;
        sub.forEach((v, i) => {
          const bx = c.x + 10 + i * (bw + gap);
          const f = Math.max(0, Math.min(1, (v || 0) / 100));
          out += rect(bx, top, bw, hgt, C.track, { rx: Math.min(2, bw / 2) });
          if (f > 0.01) out += rect(bx, top + hgt * (1 - f), bw, hgt * f, S2.usageColor(f, C.cpu), { rx: Math.min(2, bw / 2) });
        });
      });
      return out;
    }
    function memCell(role, x, y, ctx) {
      const m = ctx.store.cur.mem || {};
      if (!m.total) return message(x, y, "ram", C.dim, "Loading\u2026");
      const used = m.total - m.avail;
      const f = used / m.total;
      const tot = S2.fmtBytes(m.total, 0);
      switch (role) {
        case "used": {
          const col = S2.usageColor(f, C.mem);
          return stat(x, y, { label: "RAM", icon: "ram", accent: C.mem, right: `${tot.value} ${tot.unit}`, value: pct(f * 100), unit: "%", valueColor: col === C.mem ? C.text : col, meter: f, meterColor: col });
        }
        case "amount": {
          const u = S2.fmtBytes(used, used >= 10 * 1073741824 ? 1 : 2);
          return stat(x, y, { label: "USED", icon: "ram", accent: C.mem, value: u.value, unit: u.unit, sub: `of ${tot.value} ${tot.unit}`, meter: f, meterColor: S2.usageColor(f, C.mem) });
        }
        case "avail": {
          const a = S2.fmtBytes(m.avail, m.avail >= 10 * 1073741824 ? 1 : 2);
          return stat(x, y, { label: "FREE", icon: "ram", accent: C.mem, value: a.value, unit: a.unit, sub: `of ${tot.value} ${tot.unit}`, meter: 1 - f, meterColor: C.mem });
        }
        case "commit": {
          const cf = m.commitLimit ? m.commit / m.commitLimit : 0;
          const c1 = S2.fmtBytes(m.commit, 0);
          const c2 = S2.fmtBytes(m.commitLimit, 0);
          return stat(x, y, { label: "COMMIT", icon: "ram", accent: C.mem, value: pct(cf * 100), unit: "%", sub: `${c1.value} / ${c2.value} ${c2.unit}`, meter: cf, meterColor: S2.usageColor(cf, C.mem) });
        }
        case "top":
          return topCell(x, y, ctx, "mem");
        default:
          return "";
      }
    }
    function gpuAccent(g) {
      return g && C[g.vendor] || C.gpu;
    }
    function gpuCell(role, x, y, ctx, st) {
      const s = ctx.store;
      const g = s.gpu(st.gpu);
      if (!g) return message(x, y, "gpu", C.dim, s.info ? "No GPU found" : "Loading\u2026");
      const acc = gpuAccent(g);
      const label = s.gpuLabel(g);
      const unit = tempUnit(st);
      const tf = S2.fmtTemp(g.temp, unit);
      const noSensor = (what) => message(x, y, "gpu", C.dim, `No ${what}`, "from this GPU");
      switch (role) {
        case "load": {
          const f = fin(g.util) ? g.util / 100 : 0;
          const col = S2.usageColor(f, acc);
          return stat(x, y, { label, icon: "gpu", accent: acc, right: tf ? tf.short : "", rightColor: S2.tempColor(g.temp, { warm: 75, hot: 90 }), value: pct(g.util), unit: "%", valueColor: col === acc ? C.text : col, meter: f, meterColor: col });
        }
        case "temp": {
          if (!tf) return noSensor("temperature");
          const col = S2.tempColor(g.temp, { warm: 75, hot: 90 });
          return stat(x, y, { label: "TEMP", icon: "gpu", accent: acc, right: label === "iGPU" ? "iGPU" : "", value: tf.value, unit: tf.unit, valueColor: g.temp >= 83 ? col : C.text, meter: g.temp / 100, meterColor: col });
        }
        case "hot": {
          const hf = S2.fmtTemp(g.hot, unit);
          if (!hf) return noSensor("hot spot");
          const col = S2.tempColor(g.hot, { warm: 85, hot: 100 });
          return stat(x, y, { label: "HOT SPOT", icon: "gpu", accent: acc, value: hf.value, unit: hf.unit, valueColor: g.hot >= 95 ? col : C.text, meter: g.hot / 110, meterColor: col });
        }
        case "vram": {
          const m = s.gpuMem(g);
          if (!fin(m.used)) return noSensor("memory data");
          const u = S2.fmtBytes(m.used, m.used >= 10 * 1073741824 ? 1 : 2);
          const t = m.total ? S2.fmtBytes(m.total, 0) : null;
          const f = m.total ? m.used / m.total : null;
          return stat(x, y, { label: m.integrated ? "SHARED" : "VRAM", icon: "gpu", accent: acc, value: u.value, unit: u.unit, sub: t ? `of ${t.value} ${t.unit}` : "", meter: f, meterColor: S2.usageColor(f || 0, acc) });
        }
        case "power": {
          if (!fin(g.power) && !fin(g.powerPct)) return noSensor("power data");
          if (!fin(g.power)) return stat(x, y, { label: "POWER", icon: "gpu", accent: C.power, value: pct(g.powerPct), unit: "%", meter: g.powerPct / 100, meterColor: C.power, sub: "of max" });
          const lim = fin(g.powerLimit) ? g.powerLimit : null;
          return stat(x, y, { label: "POWER", icon: "gpu", accent: C.power, value: String(Math.round(g.power)), unit: "W", sub: lim ? `of ${Math.round(lim)} W` : "", meter: lim ? g.power / lim : null, meterColor: C.power, spark: lim ? null : sparkFor(ctx, "gpower:" + g.id), sparkColor: C.power });
        }
        case "fan": {
          if (fin(g.fan) && g.fan > 0) return stat(x, y, { label: "FAN", icon: "gpu", accent: C.fan, value: String(Math.round(g.fan)), unit: "rpm", meter: fin(g.fanPct) ? g.fanPct / 100 : null, meterColor: C.fan, sub: fin(g.fanPct) ? "" : "" });
          if (fin(g.fanPct)) return stat(x, y, { label: "FAN", icon: "gpu", accent: C.fan, value: pct(g.fanPct), unit: "%", meter: g.fanPct / 100, meterColor: C.fan });
          if (fin(g.fan)) return stat(x, y, { label: "FAN", icon: "gpu", accent: C.fan, value: "0", unit: "rpm", sub: "Fans stopped" });
          return noSensor("fan data");
        }
        case "clock": {
          const m = S2.fmtMhz(g.clock);
          if (!m) return noSensor("clock data");
          const mm = S2.fmtMhz(g.memClock);
          return stat(x, y, { label: "CLOCK", icon: "gpu", accent: acc, value: m.value, unit: m.unit, sub: mm ? `Mem ${mm.unit === "GHz" ? Number(mm.value).toFixed(1) : mm.value} ${mm.unit}` : "" });
        }
        default:
          return "";
      }
    }
    function driveTag(sel, store2) {
      const id = store2.driveId(sel);
      return id === "*" ? "ALL" : id;
    }
    function rateValue(x, y, label, iconName, col, bytes, bits, sparkVals, right) {
      const rr = S2.fmtRate(bytes, bits);
      return stat(x, y, { label, icon: iconName, accent: col, right, value: rr.value, unit: "", sub: rr.unit, spark: sparkVals, sparkColor: col });
    }
    function compactRates(x, y, a, b, sparkA, sparkB, bits) {
      const ra = S2.fmtRate(a, bits);
      const rb = S2.fmtRate(b, bits);
      const row = (yy, ic, col, rr) => {
        let o = icon(ic, x + 6, y + yy - 25, 26, col, 3);
        const vs = fitSize(rr.value, 36, 54, true, 24);
        o += rich(x + 38, y + yy, [{ t: rr.value, size: vs, weight: 700 }, { t: rr.unit, size: 19, fill: C.muted, gap: 3 }], { size: 36 });
        return o;
      };
      let out = row(40, "down", C.down, ra) + row(84, "up", C.up, rb);
      const peak = Math.max(1, ...sparkA.filter(Number.isFinite), ...sparkB.filter(Number.isFinite)) * 1.1;
      out += spark(x + 8, y + 98, 128, 38, sparkA, C.down, { max: peak, sw: 2.5, fillOpacity: 0.25 });
      out += spark(x + 8, y + 98, 128, 38, sparkB, C.up, { max: peak, sw: 2.2, fillOpacity: 0.06 });
      return out;
    }
    function diskCell(role, x, y, ctx, st) {
      const s = ctx.store;
      const tag = driveTag(st.drive, s);
      const bits = st.diskUnits === "bits";
      const key = (k) => `disk:${tag === "ALL" ? "*" : (s.diskFor(st.drive) || {}).id}:${k}`;
      if (role === "space" || role === "free") {
        const v = s.volFor(st.drive);
        if (!v) return message(x, y, "disk", C.dim, s.samples ? "Drive not found" : "Loading\u2026", s.samples ? tag : "");
        const f = v.total ? (v.total - v.free) / v.total : 0;
        if (role === "space") {
          const col = S2.usageColor(f, C.disk);
          return stat(x, y, { label: "SPACE", icon: "disk", accent: C.disk, right: tag, value: pct(f * 100), unit: "%", valueColor: col === C.disk ? C.text : col, meter: f, meterColor: col });
        }
        const fr = S2.fmtBytes(v.free);
        const tt = S2.fmtBytes(v.total, 0);
        return stat(x, y, { label: "FREE", icon: "disk", accent: C.disk, right: tag, value: fr.value, unit: fr.unit, sub: `of ${tt.value} ${tt.unit}`, meter: 1 - f, meterColor: S2.usageColor(f, C.disk) });
      }
      const d = s.diskFor(st.drive);
      if (!d) return message(x, y, "disk", C.dim, s.samples ? "Disk not found" : "Loading\u2026", s.samples ? tag : "");
      switch (role) {
        case "activity": {
          const f = fin(d.act) ? d.act / 100 : 0;
          return stat(x, y, { label: "DISK", icon: "disk", accent: C.disk, right: tag, value: pct(d.act), unit: "%", meter: f, meterColor: S2.usageColor(f, C.disk) });
        }
        case "read":
          return rateValue(x, y, "READ", "disk", C.down, d.rd, bits, sparkFor(ctx, key("rd")), tag);
        case "write":
          return rateValue(x, y, "WRITE", "disk", C.up, d.wr, bits, sparkFor(ctx, key("wr")), tag);
        case "rw":
          return compactRates(x, y, d.rd, d.wr, sparkFor(ctx, key("rd")), sparkFor(ctx, key("wr")), bits);
        default:
          return "";
      }
    }
    function netCell(role, x, y, ctx, st) {
      const s = ctx.store;
      const n = s.netFor(st.adapter);
      const bits = st.netUnits !== "bytes";
      if (!n) return message(x, y, "net", C.dim, s.samples ? "Not connected" : "Loading\u2026");
      const key = (k) => `net:${n.id}:${k}`;
      switch (role) {
        case "down":
          return rateValue(x, y, "DOWN", "down", C.down, n.rx, bits, sparkFor(ctx, key("rx")));
        case "up":
          return rateValue(x, y, "UP", "up", C.up, n.tx, bits, sparkFor(ctx, key("tx")));
        case "both":
          return compactRates(x, y, n.rx, n.tx, sparkFor(ctx, key("rx")), sparkFor(ctx, key("tx")), bits);
        case "link": {
          let out = header(x, y, "LINK", "link", C.down);
          const name = n.name || "Adapter";
          const ns = fitSize(name, 28, 130, true, 19);
          out += text(x + 72, y + 84, fit(name, ns, 132, true), { size: ns, weight: 700, anchor: "middle" });
          const sp = n.speed > 0 && n.speed < 4e11 ? n.speed : 0;
          const spT = sp >= 1e9 ? `${S2.trimZeros((sp / 1e9).toFixed(1))} Gb/s` : sp > 0 ? `${Math.round(sp / 1e6)} Mb/s` : "Connected";
          const t = n.up ? spT : "Disconnected";
          const tw = textWidth(t, SUB, true);
          out += circle(x + 72 - tw / 2 - 6, y + 121, 5.5, n.up ? C.good : C.bad);
          out += text(x + 72 + 7, y + 128, fit(t, SUB, 118, true), { size: SUB, fill: C.muted, weight: 600, anchor: "middle" });
          return out;
        }
        case "ip": {
          let out = header(x, y, "IP", "pin", C.down);
          const ip = n.ip || "";
          if (!ip) return out + text(x + 72, y + 96, n.up ? "No IPv4" : "Disconnected", { size: 21, fill: C.muted, weight: 600, anchor: "middle" });
          const parts = ip.split(".");
          const l1 = parts.slice(0, 2).join(".") + ".";
          const l2 = parts.slice(2).join(".");
          const size = Math.min(fitSize(l1, 34, 128, true, 20), fitSize(l2, 34, 128, true, 20));
          out += text(x + 72, y + 84, l1, { size, weight: 700, anchor: "middle" });
          out += text(x + 72, y + 84 + size + 6, l2, { size, weight: 700, anchor: "middle" });
          return out;
        }
        default:
          return "";
      }
    }
    function systemCell(role, x, y, ctx, st) {
      const s = ctx.store;
      switch (role) {
        case "summary": {
          const g = s.autoGpu();
          const rows = [["CPU", s.cur.cpu && s.cur.cpu.load, C.cpu], ["RAM", s.memPct(), C.mem]];
          if (g) rows.push([s.gpuLabel(g), g.util, gpuAccent(g)]);
          else {
            const d = s.diskFor("");
            rows.push(["DISK", d && d.act, C.disk]);
          }
          let out = "";
          rows.forEach(([lab, v, col], i) => {
            const by = y + 8 + i * 44;
            const f = fin(v) ? v / 100 : 0;
            out += text(x + 12, by + 22, lab, { size: SUB, fill: C.muted, weight: 700 });
            out += rich(x + 132, by + 22, [{ t: pct(v), weight: 700 }, { t: "%", fill: C.muted, size: 19 }], { anchor: "end", size: 22 });
            out += S2.bar(x + 12, by + 29, 120, 7, f, S2.usageColor(f, col));
          });
          return out;
        }
        case "uptime": {
          const u = S2.fmtDuration(s.cur.sys && s.cur.sys.up ? s.cur.sys.up + (Date.now() - s.cur.at) / 1e3 : 0);
          return stat(x, y, { label: "UPTIME", icon: "clock", accent: C.sys, value: u.value, unit: u.unit, sub: u.extra || "since start" });
        }
        case "battery": {
          const b = s.cur.bat;
          if (!b) return message(x, y, "plug", C.dim, s.samples ? "No battery" : "Loading\u2026", s.samples ? "Mains power" : "");
          const f = b.pct / 100;
          const col = b.pct <= 15 ? C.bad : b.pct <= 30 ? C.warn : C.good;
          let sub = b.charging ? "Charging" : b.ac ? "Plugged in" : "On battery";
          if (!b.ac && fin(b.secs) && b.secs > 0) {
            const d = S2.fmtDuration(b.secs);
            sub = d.unit === "min" ? `${d.value} min left` : `${Math.floor(b.secs / 3600)}h ${Math.floor(b.secs % 3600 / 60)}m left`;
          }
          return stat(x, y, { label: "BATTERY", icon: "battery", accent: col, value: pct(b.pct), unit: "%", meter: f, meterColor: col, sub });
        }
        case "procs": {
          const sys = s.cur.sys || {};
          return stat(x, y, { label: "PROCS", icon: "layers", accent: C.sys, value: fin(sys.procs) ? String(Math.round(sys.procs)) : "--", unit: "", sub: fin(sys.threads) ? `${Math.round(sys.threads).toLocaleString("en-US")} threads` : "" });
        }
        default:
          return "";
      }
    }
    var SENSOR_ICON = { temp: "thermo", fan: "fan", volt: "volt", power: "bolt", clock: "gauge", usage: "bars", current: "bolt" };
    var SENSOR_COLOR = { temp: C.good, fan: C.fan, volt: C.volt, power: C.power, clock: C.cpu, usage: C.sys, current: C.power };
    function sensorValue(sn, st) {
      const u = sn.unit || "";
      if (sn.type === "temp" || /°C|^C$/.test(u)) {
        const t = S2.fmtTemp(sn.v, tempUnit(st));
        return { value: t.value, unit: t.unit };
      }
      const v = Number(sn.v);
      const abs = Math.abs(v);
      const d = abs >= 100 ? 0 : abs >= 10 ? 1 : 2;
      const unit = u;
      if (sn.type === "clock" && /MHz/i.test(u) && abs >= 1e3) return { value: (v / 1e3).toFixed(2), unit: "GHz" };
      return { value: S2.trimZeros(v.toFixed(sn.type === "fan" ? 0 : d)), unit };
    }
    function sensorCell(role, x, y, ctx, st) {
      const s = ctx.store;
      if (!st.sensor) {
        if (!s.usableSensors().size) return needSetup(x, y, "sensor", ctx);
        return message(x, y, "sensor", C.sensor, "Pick sensor", "in settings");
      }
      const sn = s.sensor(st.sensor);
      if (!sn) return s.usableSensors().size ? message(x, y, "sensor", C.dim, "Sensor gone", "See settings") : needSetup(x, y, "sensor", ctx);
      const v = sensorValue(sn, st);
      const col = sn.type === "temp" ? S2.tempColor(sn.v) : SENSOR_COLOR[sn.type] || C.sensor;
      const isPct = sn.unit === "%";
      const label = st.label || sn.name;
      return stat(x, y, {
        label,
        icon: SENSOR_ICON[sn.type] || "sensor",
        accent: col,
        value: v.value,
        unit: v.unit,
        valueColor: sn.type === "temp" && sn.v >= 80 ? col : C.text,
        meter: sn.type === "temp" ? sn.v / 100 : isPct ? sn.v / 100 : null,
        meterColor: col,
        sub: sn.hw ? shortHw(sn.hw) : "",
        spark: sn.type === "temp" || isPct ? null : sparkFor(ctx, "sensor:" + sn.id),
        sparkColor: col
      });
    }
    function shortHw(hw) {
      return String(hw).replace(/^(CPU|GPU|Memory|Drive|S\.M\.A\.R\.T\.)\s*\[#\d+\]:\s*/i, "").replace(/:\s*(DTS|Enhanced|Performance Limit Reasons|C-State Residency)$/i, "").replace(/\s+/g, " ").trim();
    }
    function legend(x, y, color, label, value, unit, iconName) {
      let size = 22;
      let segs;
      for (; ; ) {
        segs = [{ t: label ? label + " " : "", fill: C.muted, size: Math.max(19, size - 2), weight: 700 }, { t: value, weight: 700, size }, unit ? { t: unit, fill: C.muted, size: Math.max(19, size - 3), gap: unit === "%" ? 1 : 3 } : null].filter(Boolean);
        if (S2.richWidth(segs) <= 106 || size <= 19) break;
        size--;
      }
      let out = iconName ? icon(iconName, x + 8, y + 12, 22, color, 3) : circle(x + 18, y + 24, 6.5, color);
      out += rich(x + 32, y + 32, segs, { size });
      return out;
    }
    function graphRegion(action, reg, ctx) {
      const st = reg.settings || {};
      const s = ctx.store;
      const W = reg.W;
      let lines = [];
      let legends = [];
      switch (action) {
        case "cpu": {
          lines.push([series(ctx, "cpu", st, W), C.cpu, 0.25, 100]);
          legends.push([C.cpu, "CPU", pct(s.cur.cpu && s.cur.cpu.load), "%"]);
          if (s.cpuTemp) {
            const tf = S2.fmtTemp(s.cpuTemp.c, tempUnit(st));
            lines.push([series(ctx, "cpuTemp", st, W), C.warn, 0, 100, 2.5]);
            legends.push([C.warn, "TEMP", tf.value, tf.unit]);
          }
          break;
        }
        case "memory": {
          const m = s.cur.mem || {};
          lines.push([series(ctx, "mem", st, W), C.mem, 0.25, 100]);
          legends.push([C.mem, "RAM", pct(s.memPct()), "%"]);
          if (m.total) {
            const u = S2.fmtBytes(m.total - m.avail, 1);
            legends.push([C.mem, "", u.value, u.unit]);
          }
          break;
        }
        case "gpu": {
          const g = s.gpu(st.gpu);
          if (!g) return message(reg.x, reg.y, "gpu", C.dim, s.info ? "No GPU found" : "Loading\u2026");
          const acc = gpuAccent(g);
          lines.push([series(ctx, "vram:" + g.id, st, W), C.mem, 0, 100, 2.5]);
          lines.push([series(ctx, "gpu:" + g.id, st, W), acc, 0.25, 100]);
          legends.push([acc, s.gpuLabel(g), pct(g.util), "%"]);
          const m = s.gpuMem(g);
          legends.push([C.mem, m.integrated ? "MEM" : "VRAM", m.total ? pct(m.used / m.total * 100) : "--", "%"]);
          break;
        }
        case "disk": {
          const d = s.diskFor(st.drive);
          const id = s.driveId(st.drive) === "*" ? "*" : d && d.id;
          const bits = st.diskUnits === "bits";
          const rd = series(ctx, `disk:${id}:rd`, st, W);
          const wr = series(ctx, `disk:${id}:wr`, st, W);
          const peak = Math.max(1024 * 1024, ...rd.filter(Number.isFinite), ...wr.filter(Number.isFinite)) * 1.1;
          lines.push([rd, C.down, 0.25, peak], [wr, C.up, 0.08, peak, 2.5]);
          const r1 = S2.fmtRate(d ? d.rd : 0, bits);
          const r2 = S2.fmtRate(d ? d.wr : 0, bits);
          legends.push([C.down, "R", r1.value, r1.unit], [C.up, "W", r2.value, r2.unit]);
          break;
        }
        case "network": {
          const n = s.netFor(st.adapter);
          const id = n ? n.id : "*";
          const bits = st.netUnits !== "bytes";
          const rx = series(ctx, `net:${id}:rx`, st, W);
          const tx = series(ctx, `net:${id}:tx`, st, W);
          const peak = Math.max(16 * 1024, ...rx.filter(Number.isFinite), ...tx.filter(Number.isFinite)) * 1.1;
          lines.push([rx, C.down, 0.25, peak], [tx, C.up, 0.08, peak, 2.5]);
          const a = S2.fmtRate(n ? n.rx : 0, bits);
          const b = S2.fmtRate(n ? n.tx : 0, bits);
          legends.push([C.down, "", a.value, a.unit, "down"], [C.up, "", b.value, b.unit, "up"]);
          break;
        }
        case "system": {
          const g = s.autoGpu();
          lines.push([series(ctx, "mem", st, W), C.mem, 0, 100, 2.5]);
          if (g) lines.push([series(ctx, "gpu:" + g.id, st, W), gpuAccent(g), 0, 100, 2.5]);
          lines.push([series(ctx, "cpu", st, W), C.cpu, 0.2, 100]);
          legends.push([C.cpu, "CPU", pct(s.cur.cpu && s.cur.cpu.load), "%"], [C.mem, "RAM", pct(s.memPct()), "%"]);
          if (g) legends.push([gpuAccent(g), s.gpuLabel(g), pct(g.util), "%"]);
          break;
        }
        case "sensor": {
          const sn = st.sensor ? s.sensor(st.sensor) : null;
          if (!sn) return sensorCell("value", reg.x, reg.y, ctx, st);
          const col = sn.type === "temp" ? S2.tempColor(sn.v) : SENSOR_COLOR[sn.type] || C.sensor;
          const vals = series(ctx, "sensor:" + sn.id, st, W);
          const isPct = sn.unit === "%";
          const fv = vals.filter(Number.isFinite);
          const max = isPct ? 100 : sn.type === "temp" ? Math.max(100, ...fv) : Math.max(1e-6, ...fv) * 1.15;
          const min = isPct || sn.type === "temp" ? 0 : Math.min(0, ...fv);
          lines.push([vals, col, 0.22, max, 3, min]);
          const v = sensorValue(sn, st);
          legends.push([col, "", v.value, v.unit, SENSOR_ICON[sn.type] || "sensor"]);
          if (reg.w >= 2) legends.push([C.muted, "", fit(st.label || sn.name, 20, 100, true), ""]);
          break;
        }
        default:
          break;
      }
      let out = "";
      const perRow = Math.max(1, reg.w);
      const maxRows = reg.h === 1 && reg.w > 1 ? 1 : 2;
      legends = legends.slice(0, perRow * maxRows);
      const rows = Math.ceil(legends.length / perRow);
      legends.forEach((lg, i) => {
        const col = i % perRow;
        const row = Math.floor(i / perRow);
        out += legend(reg.x + col * PITCH, reg.y + row * 30, ...lg);
      });
      const top = reg.y + 10 + rows * 30 + 6;
      const bottom = reg.y + reg.H - 10;
      const gx = reg.x + 10;
      const gw = reg.W - 20;
      const gh = Math.max(20, bottom - top);
      out += rect(gx, top + gh, gw, 2, C.line);
      out += rect(gx, top + gh / 2, gw, 1, C.grid);
      for (const [vals, color, fo, max, sw, min] of lines) out += spark(gx, top, gw, gh, vals, color, { max, min: min || 0, fillOpacity: fo, sw: sw || 3.5 });
      return out;
    }
    function available(action, role, ctx, st) {
      const s = ctx.store;
      if (action === "cpu") {
        if (role === "temp") return !!s.cpuTemp;
        if (role === "power") return !!s.cpuPower;
        if (role === "clock") return fin(s.cur.cpu && s.cur.cpu.mhz);
      }
      if (action === "gpu") {
        const g = s.gpu(st.gpu);
        if (!g) return role === "load";
        if (role === "temp") return fin(g.temp);
        if (role === "hot") return fin(g.hot);
        if (role === "power") return fin(g.power) || fin(g.powerPct);
        if (role === "fan") return fin(g.fan) || fin(g.fanPct);
        if (role === "clock") return fin(g.clock);
      }
      if (action === "system" && role === "battery") return !!s.cur.bat;
      return true;
    }
    function autoRoles(action, grp, ctx) {
      const def = ACTIONS[action];
      const anchor = grp.cells[0].settings || {};
      const order = def.order.filter((r) => available(action, r, ctx, anchor));
      const { w, h } = grp;
      const roles = /* @__PURE__ */ new Map();
      const set = (c, role) => roles.set(c.context, role);
      if (w === 1 && h === 1) {
        set(grp.cells[0], def.shows[0]);
        return roles;
      }
      if (w === 1 || h === 1) {
        const n = w * h;
        const slots = n >= 5 ? 3 : n >= 3 ? 2 : n;
        const line = [...grp.cells].sort((a, b) => a.dy - b.dy || a.dx - b.dx);
        line.forEach((c, i) => set(c, i < slots && order[i] ? order[i] : "graph"));
        return roles;
      }
      for (const c of grp.cells) {
        if (c.dy === 0) set(c, order[c.dx] || "graph");
        else if (action === "cpu" && h >= 3 && c.dy === h - 1) set(c, "cores");
        else set(c, "graph");
      }
      return roles;
    }
    function assignRoles(action, grp, ctx) {
      const def = ACTIONS[action];
      const auto = autoRoles(action, grp, ctx);
      return grp.cells.map((c) => {
        const want = c.settings && c.settings.show;
        const role = want && def.shows.includes(want) ? want : auto.get(c.context);
        return { ...c, role, x: c.dx * PITCH, y: c.dy * PITCH };
      });
    }
    function spanRegions(cells, role) {
      const g = cells.filter((c) => c.role === role);
      const regions = buildGroups2(g.map((c) => ({ context: c.context, device: "g", col: c.dx, row: c.dy, joinKey: role })));
      const byCtx = new Map(g.map((c) => [c.context, c]));
      return regions.map((rg) => {
        const first = byCtx.get(rg.anchor);
        return { w: rg.w, h: rg.h, x: first.dx * PITCH, y: first.dy * PITCH, settings: first.settings || {}, ...groupSize(rg.w, rg.h) };
      });
    }
    function needSetup(x, y, iconName, ctx) {
      const st = ctx.setup || {};
      if (st.source === "none") return message(x, y, iconName, C.dim, "No sensor", "Built-in only");
      if (!st.hasKey) return message(x, y, iconName, C.sensor, "Add the Setup key");
      return message(x, y, iconName, C.sensor, "Finish the Setup key");
    }
    function setupCell(role, x, y, ctx) {
      const st = ctx.setup || {};
      const colors = { ok: C.good, warn: C.warn, busy: C.cpu, off: C.muted, bad: C.bad };
      const col = colors[st.level] || C.muted;
      let out = header(x, y, "SETUP", "sliders", col);
      const word = st.word || "Starting\u2026";
      const ws = fitSize(word, 24, 112, true, 19);
      const tw = Math.min(112, textWidth(word, ws, true));
      out += circle(x + 72 - tw / 2 - 8, y + 76, 6, col);
      out += text(x + 72 + 7, y + 84, fit(word, ws, 116, true), { size: ws, weight: 700, anchor: "middle" });
      if (st.name) {
        const ns = fitSize(st.name, 22, 132, true, 19);
        out += text(x + 72, y + 110, fit(st.name, ns, 132, true), { size: ns, weight: 700, fill: C.text, anchor: "middle" });
      }
      if (st.detail) out += text(x + 72, y + 134, fit(st.detail, SUB, 134, true), { size: SUB, weight: 600, fill: C.muted, anchor: "middle" });
      return out;
    }
    var CELL = { setup: setupCell, cpu: cpuCell, memory: memCell, gpu: gpuCell, disk: diskCell, network: netCell, system: systemCell, sensor: sensorCell };
    function renderGroup(action, grp, ctx) {
      const def = ACTIONS[action];
      if (!def) return { content: statusKeys(grp.w, grp.h, "error", "Unknown key"), roles: [] };
      const cells = assignRoles(action, grp, ctx);
      let out = "";
      for (const c of cells) {
        if (def.span.includes(c.role)) continue;
        out += CELL[action](c.role, c.x, c.y, ctx, c.settings || {});
      }
      for (const role of def.span) {
        for (const reg of spanRegions(cells, role)) out += role === "cores" ? coresRegion(reg, ctx) : graphRegion(action, reg, ctx);
      }
      return { content: out, roles: cells.map((c) => c.role) };
    }
    module2.exports = { ACTIONS, K, GAP, PITCH, renderGroup, statusKeys, message, assignRoles, resample, appName, shortHw, sensorValue };
  }
});

// src/index.js
var fs = require("fs");
var path = require("path");
var { spawn } = require("child_process");
var WebSocket = require_ws();
var { realPosition, buildGroups } = require_layout();
var { Collector } = require_collector();
var { NvidiaSmi } = require_nvidia();
var { Store } = require_store();
var { Lhm } = require_lhm();
var R = require_render();
var S = require_svg();
var UUID_PREFIX = "com.clarkyau.sysvitals.";
var PLUGIN_DIR = path.resolve(__dirname, "..");
var LOG_FILE = path.join(PLUGIN_DIR, "plugin.log");
function writeLog(level, args) {
  const line = `${(/* @__PURE__ */ new Date()).toISOString()} [${level}] ${args.map((a) => typeof a === "string" ? a : safeJson(a)).join(" ")}
`;
  try {
    const st = fs.statSync(LOG_FILE);
    if (st.size > 1024 * 1024) fs.renameSync(LOG_FILE, LOG_FILE + ".1");
  } catch (_) {
  }
  try {
    fs.appendFileSync(LOG_FILE, line);
  } catch (_) {
  }
  if (process.env.SYSVITALS_STDOUT) process.stdout.write(line);
}
function safeJson(v) {
  try {
    return v instanceof Error ? v.stack || v.message : JSON.stringify(v);
  } catch (_) {
    return String(v);
  }
}
var log = {
  info: (...a) => writeLog("INFO", a),
  warn: (...a) => writeLog("WARN", a),
  error: (...a) => writeLog("ERROR", a)
};
process.on("uncaughtException", (e) => log.error("Uncaught:", e));
process.on("unhandledRejection", (e) => log.error("Unhandled rejection:", e));
function arg(name) {
  const i = process.argv.indexOf("-" + name);
  return i >= 0 ? process.argv[i + 1] : void 0;
}
var port = arg("port");
var pluginUUID = arg("pluginUUID");
var registerEvent = arg("registerEvent") || "registerPlugin";
var hostInfo = {};
try {
  hostInfo = JSON.parse(arg("info") || "{}");
} catch (_) {
}
log.info(`Starting. Plugin folder: ${PLUGIN_DIR}. Host: ${hostInfo.application && hostInfo.application.version || "?"} Node ${process.version}`);
var keys = /* @__PURE__ */ new Map();
var lastImage = /* @__PURE__ */ new Map();
var roleOf = /* @__PURE__ */ new Map();
var piContext = null;
var piAction = null;
var store = new Store();
var collector = new Collector(log, PLUGIN_DIR);
var nvsmi = new NvidiaSmi(log);
store.nvidia = nvsmi;
var lhm = new Lhm(log, PLUGIN_DIR);
var DEFAULT_GLOBAL = { source: "auto", lhmPort: 8085, lhmMode: "web" };
var globalSettings = { ...DEFAULT_GLOBAL };
var gotGlobal = false;
function applyGlobal(s) {
  globalSettings = { ...DEFAULT_GLOBAL, ...s || {} };
  if (!["auto", "lhm", "hwinfo", "none"].includes(globalSettings.source)) globalSettings.source = "auto";
  if (!["web", "log"].includes(globalSettings.lhmMode)) globalSettings.lhmMode = "web";
  gotGlobal = true;
  store.source = globalSettings.source;
  log.info(`Sensor source: ${globalSettings.source}, LibreHardwareMonitor through its ${globalSettings.lhmMode === "log" ? "log file" : "web server (port " + globalSettings.lhmPort + ")"}`);
  updateNeeds();
  scheduleRender(true);
  sendPiState();
}
lhm.on("readings", (list) => {
  store.addLhm(list);
});
lhm.on("status", () => {
  updateNeeds();
  scheduleRender(true);
  sendPiState();
});
collector.on("info", (info) => {
  const first = !store.info;
  store.setInfo(info);
  if (first || info.gpus.length !== (store.lastGpuCount || 0)) {
    log.info(`PC: ${info.cpu.name || "CPU"} (${info.cpu.threads} threads), ${(info.gpus || []).map((g) => g.name).join(", ") || "no GPU listed"}, ${info.os}`);
  }
  store.lastGpuCount = info.gpus.length;
  updateNvidiaFallback();
  sendPiState();
});
collector.on("sample", (s) => {
  store.add(s);
  scheduleRender();
});
collector.on("status", () => scheduleRender(true));
function updateNvidiaFallback() {
  const info = store.info;
  const hasNv = info && info.gpus.some((g) => g.vendor === "nvidia");
  const nvmlOk = info && info.sources && info.sources.nvml === "ok";
  const tried = info && info.sources && info.sources.nvml !== "not tried";
  nvsmi.setWanted(!!(hasNv && tried && !nvmlOk && collector.needs.gpu));
}
var sd = new WebSocket(`ws://127.0.0.1:${port}`);
function send(obj) {
  if (sd.readyState === WebSocket.OPEN) sd.send(JSON.stringify(obj));
}
sd.on("open", () => {
  send({ event: registerEvent, uuid: pluginUUID });
  send({ event: "getGlobalSettings", context: pluginUUID });
  log.info("Registered with Stream Dock");
  collector.start();
});
sd.on("close", () => {
  log.info("Stream Dock closed the connection; exiting");
  shutdown();
});
sd.on("error", (e) => log.error("Stream Dock connection error", e.message));
sd.on("message", (buf) => {
  let msg;
  try {
    msg = JSON.parse(buf.toString());
  } catch (_) {
    return;
  }
  try {
    handle(msg);
  } catch (e) {
    log.error("Event failed", msg.event, e);
  }
});
function shutdown() {
  collector.stop();
  nvsmi.setWanted(false);
  setTimeout(() => process.exit(0), 300);
}
process.on("SIGTERM", shutdown);
process.on("exit", () => {
  try {
    if (collector.proc) collector.proc.kill();
  } catch (_) {
  }
  nvsmi.stop();
});
function actionName(uuid) {
  const u = String(uuid || "");
  return u.startsWith(UUID_PREFIX) ? u.slice(UUID_PREFIX.length) : u.split(".").pop();
}
function handle(msg) {
  const { event, context, payload = {} } = msg;
  switch (event) {
    case "didReceiveGlobalSettings":
      applyGlobal(payload.settings || {});
      break;
    case "willAppear": {
      const pos = realPosition(payload.coordinates);
      keys.set(context, {
        action: actionName(msg.action),
        device: msg.device || "",
        col: pos.col,
        row: pos.row,
        settings: payload.settings || {},
        solo: !!payload.isInMultiAction
      });
      lastImage.delete(context);
      send({ event: "setTitle", context, payload: { title: "", target: 0 } });
      log.info(`Key added: ${actionName(msg.action)} at column ${pos.col + 1}, row ${pos.row + 1} (reported ${JSON.stringify(payload.coordinates)})`);
      scheduleRender(true);
      break;
    }
    case "willDisappear":
      keys.delete(context);
      lastImage.delete(context);
      roleOf.delete(context);
      scheduleRender(true);
      break;
    case "didReceiveSettings":
      if (keys.has(context)) {
        keys.get(context).settings = payload.settings || {};
        log.info(`Key settings (${keys.get(context).action}): ${JSON.stringify(payload.settings || {})}`);
      }
      scheduleRender(true);
      break;
    case "keyUp":
      onPress(context);
      break;
    case "propertyInspectorDidAppear":
      piContext = context;
      piAction = msg.action;
      sendPiState();
      updateNeeds();
      break;
    case "propertyInspectorDidDisappear":
      if (piContext === context) piContext = null;
      updateNeeds();
      break;
    case "sendToPlugin":
      onPiMessage(context, msg.action, payload);
      break;
    case "systemDidWakeUp":
      scheduleRender(true);
      break;
    default:
      break;
  }
}
function onPiMessage(context, action, p) {
  if (!p || typeof p !== "object") return;
  if (p.type === "settings" && keys.has(context)) {
    keys.get(context).settings = p.settings || {};
    scheduleRender(true);
  } else if (p.type === "global" && p.settings) {
    applyGlobal(p.settings);
  } else if (p.type === "lhm-install") {
    lhm.install(false);
  } else if (p.type === "lhm-apply") {
    lhm.install(true);
  } else if (p.type === "lhm-start") {
    lhm.start();
  } else if (p.type === "open" && /^https:\/\//.test(p.url || "")) {
    send({ event: "openUrl", payload: { url: p.url } });
  } else if (p.type === "retry") {
    lhm.poll();
  } else if (p.type === "hello") {
    piContext = context;
    piAction = action;
    updateNeeds();
  }
  sendPiState();
}
function sendPiState() {
  if (!piContext) return;
  const info = store.info || {};
  const gpus = store.gpuList().map((g) => ({
    id: g.id,
    name: g.name,
    vendor: g.vendor,
    integrated: !!g.integrated,
    tempSrc: g.src || "",
    hasTemp: Number.isFinite(g.temp)
  }));
  send({
    event: "sendToPropertyInspector",
    action: piAction,
    context: piContext,
    payload: {
      type: "state",
      ready: store.samples > 0,
      status: collector.status,
      statusText: collector.statusText,
      cpu: info.cpu || null,
      cpuTemp: store.cpuTemp ? { src: store.cpuTemp.src } : null,
      sensorSource: store.sensorSource(),
      gpus,
      autoGpu: (store.autoGpu() || {}).id || "",
      drives: store.drives(),
      systemDrive: store.driveId(""),
      adapters: store.adapters(),
      autoAdapter: (store.autoNet() || {}).id || "",
      sensors: store.sensorList(),
      hasBattery: !!store.cur.bat,
      setup: setupState(),
      global: globalSettings
    }
  });
}
setInterval(() => {
  if (piContext) sendPiState();
}, 3e3);
var DEFAULT_PRESS = { cpu: "taskmgr", memory: "taskmgr", gpu: "taskmgr", disk: "taskmgr", network: "taskmgr", system: "taskmgr", sensor: "none" };
function openTarget(target, args = []) {
  try {
    const p = spawn("cmd.exe", ["/c", "start", "", target, ...args], { detached: true, windowsHide: true, stdio: "ignore" });
    p.on("error", (e) => log.warn("Could not open", target, e.message));
    p.unref();
  } catch (e) {
    log.warn("Could not open", target, e.message);
  }
}
function onPress(context) {
  const k = keys.get(context);
  if (!k) return;
  if (k.action === "setup") return pressSetup();
  const press = k.settings.press || DEFAULT_PRESS[k.action] || "none";
  const role = roleOf.get(context);
  switch (press) {
    case "taskmgr":
      return openTarget("taskmgr.exe");
    case "resmon":
      return openTarget("resmon.exe");
    case "drive": {
      const id = store.driveId(k.settings.drive);
      return openTarget("explorer.exe", [id === "*" ? "shell:MyComputerFolder" : id + "\\"]);
    }
    case "netsettings":
      return openTarget("ms-settings:network-status");
    case "power":
      return openTarget(role === "battery" ? "ms-settings:batterysaver" : "ms-settings:powersleep");
    case "none":
    default:
      return void 0;
  }
}
var renderTimer = null;
var lastRender = 0;
function scheduleRender(soon) {
  if (renderTimer) {
    if (!soon) return;
    clearTimeout(renderTimer);
  }
  const wait = soon ? 30 : Math.max(0, 250 - (Date.now() - lastRender));
  renderTimer = setTimeout(() => {
    renderTimer = null;
    lastRender = Date.now();
    renderAll();
  }, wait);
}
setInterval(() => scheduleRender(), 5e3);
function renderAll() {
  const byAction = /* @__PURE__ */ new Map();
  for (const [context, k] of keys) {
    const list = byAction.get(k.action) || [];
    list.push({ context, device: k.device, col: k.col, row: k.row, joinKey: k.action, solo: k.solo || k.settings.join === false || k.action === "setup" });
    byAction.set(k.action, list);
  }
  const ready = collector.status === "running" || store.samples > 0;
  const stale = store.cur.at && Date.now() - store.cur.at > 15e3;
  const ctx = { store, setup: setupState() };
  for (const [action, list] of byAction) {
    for (const grp of buildGroups(list)) {
      try {
        grp.cells = grp.keys.map((g) => ({ ...g, settings: (keys.get(g.context) || {}).settings || {} }));
        let content;
        if (action !== "setup" && (!ready || stale && collector.status !== "running")) {
          const err = collector.status === "error";
          content = R.statusKeys(grp.w, grp.h, err ? "error" : "starting", err ? collector.statusText || "Not reading" : "Starting\u2026", err ? "See plugin log" : "");
          for (const c of grp.keys) roleOf.delete(c.context);
        } else {
          const res = R.renderGroup(action, grp, ctx);
          content = res.content;
          grp.cells.forEach((c, i) => roleOf.set(c.context, res.roles[i]));
        }
        for (const k of grp.keys) setKey(k.context, S.wrapSvg(content, 144, 144, k.dx * R.PITCH, k.dy * R.PITCH));
      } catch (e) {
        log.error(`Render failed (${action})`, e);
      }
    }
  }
  logLayout();
  updateNeeds();
}
var lastLayout = "";
function logLayout() {
  const obj = {};
  for (const c of keys.keys()) obj[c] = roleOf.get(c) || "";
  const json = JSON.stringify(obj);
  if (json === lastLayout) return;
  lastLayout = json;
  const human = [...keys.entries()].sort((a, b) => a[1].row - b[1].row || a[1].col - b[1].col).map(([c, k]) => `${k.action}@${k.col + 1},${k.row + 1}=${roleOf.get(c) || "-"}`).join(" ");
  log.info(`Layout: ${human}`);
  log.info(`Roles: ${json}`);
}
function updateNeeds() {
  let gpu = false;
  let top = false;
  let sensors = false;
  for (const [context, k] of keys) {
    const role = roleOf.get(context);
    if (k.action === "gpu" || k.action === "system") gpu = true;
    if (role === "top") top = true;
    if (k.action === "cpu" || k.action === "sensor" || k.action === "setup") sensors = true;
  }
  if (piContext && keys.has(piContext)) {
    const a = keys.get(piContext).action;
    if (a === "sensor" || a === "cpu" || a === "setup") sensors = true;
    if (a === "gpu") gpu = true;
  }
  const src = globalSettings.source;
  const useLhm = sensors && (src === "auto" || src === "lhm");
  lhm.configure({ port: globalSettings.lhmPort, mode: globalSettings.lhmMode, wanted: useLhm });
  const hwinfo = src === "auto" || src === "hwinfo";
  const wmi = useLhm && !lhm.connected;
  collector.setNeeds({ gpu, top, sensors, hwinfo, wmi });
  updateNvidiaFallback();
}
var SHORT = { lhm: "LibreHWM", hwinfo: "HWiNFO", ohm: "OpenHWM", amd: "AMD driver", windows: "Windows" };
function setupState() {
  const src = globalSettings.source;
  const apps = store.apps || {};
  const lhmCount = store.countFrom("lhm:");
  const hwiCount = store.countFrom("hwi:");
  const ohmCount = store.countFrom("ohm:");
  const amdCount = store.countFrom("amd:");
  const lhmInstalled = lhm.installed;
  const base = {
    source: src,
    hasKey: [...keys.values()].some((k) => k.action === "setup"),
    lhm: { installed: lhmInstalled, path: lhm.exePath, running: !!apps.lhm, connected: lhm.connected, mode: lhm.mode, config: lhmInstalled ? lhm.config : null, count: lhmCount, port: lhm.port, error: lhm.lastError, installing: lhm.installing },
    hwinfo: { running: !!apps.hwinfo, count: hwiCount },
    ohm: { running: !!apps.ohm, count: ohmCount },
    amd: { count: amdCount },
    cpuTemp: store.cpuTemp ? store.cpuTemp.src : ""
  };
  const st = (level, word, name, detail, active) => ({ ...base, level, word, name, detail, active: active || "" });
  const ins = lhm.installing;
  if (ins && !ins.done) return st("busy", ins.what === "apply" ? "Applying" : "Installing", "LibreHWM", ins.step);
  if (ins && ins.done && ins.error && Date.now() - (lhm.installEndedAt || 0) < 6e4) return st("bad", ins.what === "apply" ? "Not applied" : "Install failed", "LibreHWM", ins.error);
  if (!gotGlobal || !collector.lastSampleAt) return st("busy", "Starting\u2026", "", "");
  const n = (c) => `${c} sensor${c === 1 ? "" : "s"}`;
  const lhmOk = lhm.connected || lhmCount > 0;
  if (src === "none") {
    if (amdCount) return st("ok", "Built-in", SHORT.amd, "No apps used", "amd");
    return st("off", "Built-in", "No apps used", "No CPU temp");
  }
  if (src === "lhm" || src === "auto" && (lhmOk || !hwiCount && !ohmCount)) {
    if (lhmOk) return st("ok", "Connected", SHORT.lhm, lhm.connected ? lhm.mode === "log" ? "via log file" : n(lhmCount) : n(lhmCount) + " (WMI)", "lhm");
    if (src === "auto" && hwiCount) return st("ok", "Connected", SHORT.hwinfo, n(hwiCount), "hwinfo");
    if (apps.lhm) return st("warn", lhm.mode === "log" ? "Not logging" : "No web server", SHORT.lhm, "See settings");
    if (lhmInstalled) return st("warn", "Not running", SHORT.lhm, "Press to start");
    if (src === "auto" && apps.hwinfo) return st("warn", "Not sharing", SHORT.hwinfo, "See settings");
    return st(src === "auto" ? "off" : "warn", "Not set up", src === "auto" ? "No sensor app" : SHORT.lhm, "See settings");
  }
  if (src === "hwinfo" || src === "auto" && hwiCount) {
    if (hwiCount) return st("ok", "Connected", SHORT.hwinfo, n(hwiCount), "hwinfo");
    if (apps.hwinfo) return st("warn", "Not sharing", SHORT.hwinfo, "See settings");
    return st("warn", "Not running", SHORT.hwinfo, "Start HWiNFO");
  }
  if (ohmCount) return st("ok", "Connected", SHORT.ohm, n(ohmCount), "ohm");
  return st("off", "Not set up", "No sensor app", "See settings");
}
function pressSetup() {
  const st = setupState();
  if (st.active === "lhm" && lhm.connected && lhm.mode === "web") return send({ event: "openUrl", payload: { url: `http://127.0.0.1:${lhm.port}/` } });
  if ((st.source === "auto" || st.source === "lhm") && st.lhm.installed && !st.lhm.running) return lhm.start();
  lhm.poll();
  scheduleRender(true);
}
function setKey(context, svg) {
  const url = S.toDataUrl(svg);
  if (lastImage.get(context) === url) return;
  lastImage.set(context, url);
  send({ event: "setImage", context, payload: { image: url, target: 0 } });
}
