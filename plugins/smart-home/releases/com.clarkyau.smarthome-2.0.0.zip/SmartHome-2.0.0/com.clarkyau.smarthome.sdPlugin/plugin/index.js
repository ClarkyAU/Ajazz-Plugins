"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// node_modules/ws/lib/constants.js
var require_constants = __commonJS({
  "node_modules/ws/lib/constants.js"(exports2, module2) {
    "use strict";
    var BINARY_TYPES = ["nodebuffer", "arraybuffer", "fragments"];
    var hasBlob = typeof Blob !== "undefined";
    if (hasBlob) BINARY_TYPES.push("blob");
    module2.exports = {
      BINARY_TYPES,
      EMPTY_BUFFER: Buffer.alloc(0),
      GUID: "258EAFA5-E914-47DA-95CA-C5AB0DC85B11",
      hasBlob,
      kForOnEventAttribute: Symbol("kIsForOnEventAttribute"),
      kListener: Symbol("kListener"),
      kStatusCode: Symbol("status-code"),
      kWebSocket: Symbol("websocket"),
      NOOP: () => {
      }
    };
  }
});

// node_modules/ws/lib/buffer-util.js
var require_buffer_util = __commonJS({
  "node_modules/ws/lib/buffer-util.js"(exports2, module2) {
    "use strict";
    var { EMPTY_BUFFER } = require_constants();
    var FastBuffer = Buffer[Symbol.species];
    function concat(list, totalLength) {
      if (list.length === 0) return EMPTY_BUFFER;
      if (list.length === 1) return list[0];
      const target = Buffer.allocUnsafe(totalLength);
      let offset = 0;
      for (let i = 0; i < list.length; i++) {
        const buf = list[i];
        target.set(buf, offset);
        offset += buf.length;
      }
      if (offset < totalLength) {
        return new FastBuffer(target.buffer, target.byteOffset, offset);
      }
      return target;
    }
    function _mask(source, mask, output, offset, length) {
      for (let i = 0; i < length; i++) {
        output[offset + i] = source[i] ^ mask[i & 3];
      }
    }
    function _unmask(buffer, mask) {
      for (let i = 0; i < buffer.length; i++) {
        buffer[i] ^= mask[i & 3];
      }
    }
    function toArrayBuffer(buf) {
      if (buf.length === buf.buffer.byteLength) {
        return buf.buffer;
      }
      return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.length);
    }
    function toBuffer(data) {
      toBuffer.readOnly = true;
      if (Buffer.isBuffer(data)) return data;
      let buf;
      if (data instanceof ArrayBuffer) {
        buf = new FastBuffer(data);
      } else if (ArrayBuffer.isView(data)) {
        buf = new FastBuffer(data.buffer, data.byteOffset, data.byteLength);
      } else {
        buf = Buffer.from(data);
        toBuffer.readOnly = false;
      }
      return buf;
    }
    module2.exports = {
      concat,
      mask: _mask,
      toArrayBuffer,
      toBuffer,
      unmask: _unmask
    };
    if (!process.env.WS_NO_BUFFER_UTIL) {
      try {
        const bufferUtil = require("bufferutil");
        module2.exports.mask = function(source, mask, output, offset, length) {
          if (length < 48) _mask(source, mask, output, offset, length);
          else bufferUtil.mask(source, mask, output, offset, length);
        };
        module2.exports.unmask = function(buffer, mask) {
          if (buffer.length < 32) _unmask(buffer, mask);
          else bufferUtil.unmask(buffer, mask);
        };
      } catch (e) {
      }
    }
  }
});

// node_modules/ws/lib/limiter.js
var require_limiter = __commonJS({
  "node_modules/ws/lib/limiter.js"(exports2, module2) {
    "use strict";
    var kDone = Symbol("kDone");
    var kRun = Symbol("kRun");
    var Limiter = class {
      /**
       * Creates a new `Limiter`.
       *
       * @param {Number} [concurrency=Infinity] The maximum number of jobs allowed
       *     to run concurrently
       */
      constructor(concurrency) {
        this[kDone] = () => {
          this.pending--;
          this[kRun]();
        };
        this.concurrency = concurrency || Infinity;
        this.jobs = [];
        this.pending = 0;
      }
      /**
       * Adds a job to the queue.
       *
       * @param {Function} job The job to run
       * @public
       */
      add(job) {
        this.jobs.push(job);
        this[kRun]();
      }
      /**
       * Removes a job from the queue and runs it if possible.
       *
       * @private
       */
      [kRun]() {
        if (this.pending === this.concurrency) return;
        if (this.jobs.length) {
          const job = this.jobs.shift();
          this.pending++;
          job(this[kDone]);
        }
      }
    };
    module2.exports = Limiter;
  }
});

// node_modules/ws/lib/permessage-deflate.js
var require_permessage_deflate = __commonJS({
  "node_modules/ws/lib/permessage-deflate.js"(exports2, module2) {
    "use strict";
    var zlib = require("zlib");
    var bufferUtil = require_buffer_util();
    var Limiter = require_limiter();
    var { kStatusCode } = require_constants();
    var FastBuffer = Buffer[Symbol.species];
    var TRAILER = Buffer.from([0, 0, 255, 255]);
    var kPerMessageDeflate = Symbol("permessage-deflate");
    var kTotalLength = Symbol("total-length");
    var kCallback = Symbol("callback");
    var kBuffers = Symbol("buffers");
    var kError = Symbol("error");
    var zlibLimiter;
    var PerMessageDeflate = class {
      /**
       * Creates a PerMessageDeflate instance.
       *
       * @param {Object} [options] Configuration options
       * @param {(Boolean|Number)} [options.clientMaxWindowBits] Advertise support
       *     for, or request, a custom client window size
       * @param {Boolean} [options.clientNoContextTakeover=false] Advertise/
       *     acknowledge disabling of client context takeover
       * @param {Number} [options.concurrencyLimit=10] The number of concurrent
       *     calls to zlib
       * @param {(Boolean|Number)} [options.serverMaxWindowBits] Request/confirm the
       *     use of a custom server window size
       * @param {Boolean} [options.serverNoContextTakeover=false] Request/accept
       *     disabling of server context takeover
       * @param {Number} [options.threshold=1024] Size (in bytes) below which
       *     messages should not be compressed if context takeover is disabled
       * @param {Object} [options.zlibDeflateOptions] Options to pass to zlib on
       *     deflate
       * @param {Object} [options.zlibInflateOptions] Options to pass to zlib on
       *     inflate
       * @param {Boolean} [isServer=false] Create the instance in either server or
       *     client mode
       * @param {Number} [maxPayload=0] The maximum allowed message length
       */
      constructor(options, isServer, maxPayload) {
        this._maxPayload = maxPayload | 0;
        this._options = options || {};
        this._threshold = this._options.threshold !== void 0 ? this._options.threshold : 1024;
        this._isServer = !!isServer;
        this._deflate = null;
        this._inflate = null;
        this.params = null;
        if (!zlibLimiter) {
          const concurrency = this._options.concurrencyLimit !== void 0 ? this._options.concurrencyLimit : 10;
          zlibLimiter = new Limiter(concurrency);
        }
      }
      /**
       * @type {String}
       */
      static get extensionName() {
        return "permessage-deflate";
      }
      /**
       * Create an extension negotiation offer.
       *
       * @return {Object} Extension parameters
       * @public
       */
      offer() {
        const params = {};
        if (this._options.serverNoContextTakeover) {
          params.server_no_context_takeover = true;
        }
        if (this._options.clientNoContextTakeover) {
          params.client_no_context_takeover = true;
        }
        if (this._options.serverMaxWindowBits) {
          params.server_max_window_bits = this._options.serverMaxWindowBits;
        }
        if (this._options.clientMaxWindowBits) {
          params.client_max_window_bits = this._options.clientMaxWindowBits;
        } else if (this._options.clientMaxWindowBits == null) {
          params.client_max_window_bits = true;
        }
        return params;
      }
      /**
       * Accept an extension negotiation offer/response.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Object} Accepted configuration
       * @public
       */
      accept(configurations) {
        configurations = this.normalizeParams(configurations);
        this.params = this._isServer ? this.acceptAsServer(configurations) : this.acceptAsClient(configurations);
        return this.params;
      }
      /**
       * Releases all resources used by the extension.
       *
       * @public
       */
      cleanup() {
        if (this._inflate) {
          this._inflate.close();
          this._inflate = null;
        }
        if (this._deflate) {
          const callback = this._deflate[kCallback];
          this._deflate.close();
          this._deflate = null;
          if (callback) {
            callback(
              new Error(
                "The deflate stream was closed while data was being processed"
              )
            );
          }
        }
      }
      /**
       *  Accept an extension negotiation offer.
       *
       * @param {Array} offers The extension negotiation offers
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsServer(offers) {
        const opts = this._options;
        const accepted = offers.find((params) => {
          if (opts.serverNoContextTakeover === false && params.server_no_context_takeover || params.server_max_window_bits && (opts.serverMaxWindowBits === false || typeof opts.serverMaxWindowBits === "number" && opts.serverMaxWindowBits > params.server_max_window_bits) || typeof opts.clientMaxWindowBits === "number" && !params.client_max_window_bits) {
            return false;
          }
          return true;
        });
        if (!accepted) {
          throw new Error("None of the extension offers can be accepted");
        }
        if (opts.serverNoContextTakeover) {
          accepted.server_no_context_takeover = true;
        }
        if (opts.clientNoContextTakeover) {
          accepted.client_no_context_takeover = true;
        }
        if (typeof opts.serverMaxWindowBits === "number") {
          accepted.server_max_window_bits = opts.serverMaxWindowBits;
        }
        if (typeof opts.clientMaxWindowBits === "number") {
          accepted.client_max_window_bits = opts.clientMaxWindowBits;
        } else if (accepted.client_max_window_bits === true || opts.clientMaxWindowBits === false) {
          delete accepted.client_max_window_bits;
        }
        return accepted;
      }
      /**
       * Accept the extension negotiation response.
       *
       * @param {Array} response The extension negotiation response
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsClient(response) {
        const params = response[0];
        if (this._options.clientNoContextTakeover === false && params.client_no_context_takeover) {
          throw new Error('Unexpected parameter "client_no_context_takeover"');
        }
        if (!params.client_max_window_bits) {
          if (typeof this._options.clientMaxWindowBits === "number") {
            params.client_max_window_bits = this._options.clientMaxWindowBits;
          }
        } else if (this._options.clientMaxWindowBits === false || typeof this._options.clientMaxWindowBits === "number" && params.client_max_window_bits > this._options.clientMaxWindowBits) {
          throw new Error(
            'Unexpected or invalid parameter "client_max_window_bits"'
          );
        }
        return params;
      }
      /**
       * Normalize parameters.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Array} The offers/response with normalized parameters
       * @private
       */
      normalizeParams(configurations) {
        configurations.forEach((params) => {
          Object.keys(params).forEach((key) => {
            let value = params[key];
            if (value.length > 1) {
              throw new Error(`Parameter "${key}" must have only a single value`);
            }
            value = value[0];
            if (key === "client_max_window_bits") {
              if (value !== true) {
                const num = +value;
                if (!Number.isInteger(num) || num < 8 || num > 15) {
                  throw new TypeError(
                    `Invalid value for parameter "${key}": ${value}`
                  );
                }
                value = num;
              } else if (!this._isServer) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
            } else if (key === "server_max_window_bits") {
              const num = +value;
              if (!Number.isInteger(num) || num < 8 || num > 15) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
              value = num;
            } else if (key === "client_no_context_takeover" || key === "server_no_context_takeover") {
              if (value !== true) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
            } else {
              throw new Error(`Unknown parameter "${key}"`);
            }
            params[key] = value;
          });
        });
        return configurations;
      }
      /**
       * Decompress data. Concurrency limited.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      decompress(data, fin, callback) {
        zlibLimiter.add((done) => {
          this._decompress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Compress data. Concurrency limited.
       *
       * @param {(Buffer|String)} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      compress(data, fin, callback) {
        zlibLimiter.add((done) => {
          this._compress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Decompress data.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _decompress(data, fin, callback) {
        const endpoint = this._isServer ? "client" : "server";
        if (!this._inflate) {
          const key = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
          this._inflate = zlib.createInflateRaw({
            ...this._options.zlibInflateOptions,
            windowBits
          });
          this._inflate[kPerMessageDeflate] = this;
          this._inflate[kTotalLength] = 0;
          this._inflate[kBuffers] = [];
          this._inflate.on("error", inflateOnError);
          this._inflate.on("data", inflateOnData);
        }
        this._inflate[kCallback] = callback;
        this._inflate.write(data);
        if (fin) this._inflate.write(TRAILER);
        this._inflate.flush(() => {
          const err = this._inflate[kError];
          if (err) {
            this._inflate.close();
            this._inflate = null;
            callback(err);
            return;
          }
          const data2 = bufferUtil.concat(
            this._inflate[kBuffers],
            this._inflate[kTotalLength]
          );
          if (this._inflate._readableState.endEmitted) {
            this._inflate.close();
            this._inflate = null;
          } else {
            this._inflate[kTotalLength] = 0;
            this._inflate[kBuffers] = [];
            if (fin && this.params[`${endpoint}_no_context_takeover`]) {
              this._inflate.reset();
            }
          }
          callback(null, data2);
        });
      }
      /**
       * Compress data.
       *
       * @param {(Buffer|String)} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _compress(data, fin, callback) {
        const endpoint = this._isServer ? "server" : "client";
        if (!this._deflate) {
          const key = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
          this._deflate = zlib.createDeflateRaw({
            ...this._options.zlibDeflateOptions,
            windowBits
          });
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          this._deflate.on("data", deflateOnData);
        }
        this._deflate[kCallback] = callback;
        this._deflate.write(data);
        this._deflate.flush(zlib.Z_SYNC_FLUSH, () => {
          if (!this._deflate) {
            return;
          }
          let data2 = bufferUtil.concat(
            this._deflate[kBuffers],
            this._deflate[kTotalLength]
          );
          if (fin) {
            data2 = new FastBuffer(data2.buffer, data2.byteOffset, data2.length - 4);
          }
          this._deflate[kCallback] = null;
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          if (fin && this.params[`${endpoint}_no_context_takeover`]) {
            this._deflate.reset();
          }
          callback(null, data2);
        });
      }
    };
    module2.exports = PerMessageDeflate;
    function deflateOnData(chunk) {
      this[kBuffers].push(chunk);
      this[kTotalLength] += chunk.length;
    }
    function inflateOnData(chunk) {
      this[kTotalLength] += chunk.length;
      if (this[kPerMessageDeflate]._maxPayload < 1 || this[kTotalLength] <= this[kPerMessageDeflate]._maxPayload) {
        this[kBuffers].push(chunk);
        return;
      }
      this[kError] = new RangeError("Max payload size exceeded");
      this[kError].code = "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH";
      this[kError][kStatusCode] = 1009;
      this.removeListener("data", inflateOnData);
      this.reset();
    }
    function inflateOnError(err) {
      this[kPerMessageDeflate]._inflate = null;
      err[kStatusCode] = 1007;
      this[kCallback](err);
    }
  }
});

// node_modules/ws/lib/validation.js
var require_validation = __commonJS({
  "node_modules/ws/lib/validation.js"(exports2, module2) {
    "use strict";
    var { isUtf8 } = require("buffer");
    var { hasBlob } = require_constants();
    var tokenChars = [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 0 - 15
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 16 - 31
      0,
      1,
      0,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      1,
      1,
      0,
      1,
      1,
      0,
      // 32 - 47
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      // 48 - 63
      0,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 64 - 79
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      1,
      1,
      // 80 - 95
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 96 - 111
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      1,
      0,
      1,
      0
      // 112 - 127
    ];
    function isValidStatusCode(code) {
      return code >= 1e3 && code <= 1014 && code !== 1004 && code !== 1005 && code !== 1006 || code >= 3e3 && code <= 4999;
    }
    function _isValidUTF8(buf) {
      const len = buf.length;
      let i = 0;
      while (i < len) {
        if ((buf[i] & 128) === 0) {
          i++;
        } else if ((buf[i] & 224) === 192) {
          if (i + 1 === len || (buf[i + 1] & 192) !== 128 || (buf[i] & 254) === 192) {
            return false;
          }
          i += 2;
        } else if ((buf[i] & 240) === 224) {
          if (i + 2 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || buf[i] === 224 && (buf[i + 1] & 224) === 128 || // Overlong
          buf[i] === 237 && (buf[i + 1] & 224) === 160) {
            return false;
          }
          i += 3;
        } else if ((buf[i] & 248) === 240) {
          if (i + 3 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || (buf[i + 3] & 192) !== 128 || buf[i] === 240 && (buf[i + 1] & 240) === 128 || // Overlong
          buf[i] === 244 && buf[i + 1] > 143 || buf[i] > 244) {
            return false;
          }
          i += 4;
        } else {
          return false;
        }
      }
      return true;
    }
    function isBlob(value) {
      return hasBlob && typeof value === "object" && typeof value.arrayBuffer === "function" && typeof value.type === "string" && typeof value.stream === "function" && (value[Symbol.toStringTag] === "Blob" || value[Symbol.toStringTag] === "File");
    }
    module2.exports = {
      isBlob,
      isValidStatusCode,
      isValidUTF8: _isValidUTF8,
      tokenChars
    };
    if (isUtf8) {
      module2.exports.isValidUTF8 = function(buf) {
        return buf.length < 24 ? _isValidUTF8(buf) : isUtf8(buf);
      };
    } else if (!process.env.WS_NO_UTF_8_VALIDATE) {
      try {
        const isValidUTF8 = require("utf-8-validate");
        module2.exports.isValidUTF8 = function(buf) {
          return buf.length < 32 ? _isValidUTF8(buf) : isValidUTF8(buf);
        };
      } catch (e) {
      }
    }
  }
});

// node_modules/ws/lib/receiver.js
var require_receiver = __commonJS({
  "node_modules/ws/lib/receiver.js"(exports2, module2) {
    "use strict";
    var { Writable } = require("stream");
    var PerMessageDeflate = require_permessage_deflate();
    var {
      BINARY_TYPES,
      EMPTY_BUFFER,
      kStatusCode,
      kWebSocket
    } = require_constants();
    var { concat, toArrayBuffer, unmask } = require_buffer_util();
    var { isValidStatusCode, isValidUTF8 } = require_validation();
    var FastBuffer = Buffer[Symbol.species];
    var GET_INFO = 0;
    var GET_PAYLOAD_LENGTH_16 = 1;
    var GET_PAYLOAD_LENGTH_64 = 2;
    var GET_MASK = 3;
    var GET_DATA = 4;
    var INFLATING = 5;
    var DEFER_EVENT = 6;
    var Receiver = class extends Writable {
      /**
       * Creates a Receiver instance.
       *
       * @param {Object} [options] Options object
       * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {String} [options.binaryType=nodebuffer] The type for binary data
       * @param {Object} [options.extensions] An object containing the negotiated
       *     extensions
       * @param {Boolean} [options.isServer=false] Specifies whether to operate in
       *     client or server mode
       * @param {Number} [options.maxPayload=0] The maximum allowed message length
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       */
      constructor(options = {}) {
        super();
        this._allowSynchronousEvents = options.allowSynchronousEvents !== void 0 ? options.allowSynchronousEvents : true;
        this._binaryType = options.binaryType || BINARY_TYPES[0];
        this._extensions = options.extensions || {};
        this._isServer = !!options.isServer;
        this._maxPayload = options.maxPayload | 0;
        this._skipUTF8Validation = !!options.skipUTF8Validation;
        this[kWebSocket] = void 0;
        this._bufferedBytes = 0;
        this._buffers = [];
        this._compressed = false;
        this._payloadLength = 0;
        this._mask = void 0;
        this._fragmented = 0;
        this._masked = false;
        this._fin = false;
        this._opcode = 0;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._fragments = [];
        this._errored = false;
        this._loop = false;
        this._state = GET_INFO;
      }
      /**
       * Implements `Writable.prototype._write()`.
       *
       * @param {Buffer} chunk The chunk of data to write
       * @param {String} encoding The character encoding of `chunk`
       * @param {Function} cb Callback
       * @private
       */
      _write(chunk, encoding, cb) {
        if (this._opcode === 8 && this._state == GET_INFO) return cb();
        this._bufferedBytes += chunk.length;
        this._buffers.push(chunk);
        this.startLoop(cb);
      }
      /**
       * Consumes `n` bytes from the buffered data.
       *
       * @param {Number} n The number of bytes to consume
       * @return {Buffer} The consumed bytes
       * @private
       */
      consume(n) {
        this._bufferedBytes -= n;
        if (n === this._buffers[0].length) return this._buffers.shift();
        if (n < this._buffers[0].length) {
          const buf = this._buffers[0];
          this._buffers[0] = new FastBuffer(
            buf.buffer,
            buf.byteOffset + n,
            buf.length - n
          );
          return new FastBuffer(buf.buffer, buf.byteOffset, n);
        }
        const dst = Buffer.allocUnsafe(n);
        do {
          const buf = this._buffers[0];
          const offset = dst.length - n;
          if (n >= buf.length) {
            dst.set(this._buffers.shift(), offset);
          } else {
            dst.set(new Uint8Array(buf.buffer, buf.byteOffset, n), offset);
            this._buffers[0] = new FastBuffer(
              buf.buffer,
              buf.byteOffset + n,
              buf.length - n
            );
          }
          n -= buf.length;
        } while (n > 0);
        return dst;
      }
      /**
       * Starts the parsing loop.
       *
       * @param {Function} cb Callback
       * @private
       */
      startLoop(cb) {
        this._loop = true;
        do {
          switch (this._state) {
            case GET_INFO:
              this.getInfo(cb);
              break;
            case GET_PAYLOAD_LENGTH_16:
              this.getPayloadLength16(cb);
              break;
            case GET_PAYLOAD_LENGTH_64:
              this.getPayloadLength64(cb);
              break;
            case GET_MASK:
              this.getMask();
              break;
            case GET_DATA:
              this.getData(cb);
              break;
            case INFLATING:
            case DEFER_EVENT:
              this._loop = false;
              return;
          }
        } while (this._loop);
        if (!this._errored) cb();
      }
      /**
       * Reads the first two bytes of a frame.
       *
       * @param {Function} cb Callback
       * @private
       */
      getInfo(cb) {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        const buf = this.consume(2);
        if ((buf[0] & 48) !== 0) {
          const error = this.createError(
            RangeError,
            "RSV2 and RSV3 must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_RSV_2_3"
          );
          cb(error);
          return;
        }
        const compressed = (buf[0] & 64) === 64;
        if (compressed && !this._extensions[PerMessageDeflate.extensionName]) {
          const error = this.createError(
            RangeError,
            "RSV1 must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_RSV_1"
          );
          cb(error);
          return;
        }
        this._fin = (buf[0] & 128) === 128;
        this._opcode = buf[0] & 15;
        this._payloadLength = buf[1] & 127;
        if (this._opcode === 0) {
          if (compressed) {
            const error = this.createError(
              RangeError,
              "RSV1 must be clear",
              true,
              1002,
              "WS_ERR_UNEXPECTED_RSV_1"
            );
            cb(error);
            return;
          }
          if (!this._fragmented) {
            const error = this.createError(
              RangeError,
              "invalid opcode 0",
              true,
              1002,
              "WS_ERR_INVALID_OPCODE"
            );
            cb(error);
            return;
          }
          this._opcode = this._fragmented;
        } else if (this._opcode === 1 || this._opcode === 2) {
          if (this._fragmented) {
            const error = this.createError(
              RangeError,
              `invalid opcode ${this._opcode}`,
              true,
              1002,
              "WS_ERR_INVALID_OPCODE"
            );
            cb(error);
            return;
          }
          this._compressed = compressed;
        } else if (this._opcode > 7 && this._opcode < 11) {
          if (!this._fin) {
            const error = this.createError(
              RangeError,
              "FIN must be set",
              true,
              1002,
              "WS_ERR_EXPECTED_FIN"
            );
            cb(error);
            return;
          }
          if (compressed) {
            const error = this.createError(
              RangeError,
              "RSV1 must be clear",
              true,
              1002,
              "WS_ERR_UNEXPECTED_RSV_1"
            );
            cb(error);
            return;
          }
          if (this._payloadLength > 125 || this._opcode === 8 && this._payloadLength === 1) {
            const error = this.createError(
              RangeError,
              `invalid payload length ${this._payloadLength}`,
              true,
              1002,
              "WS_ERR_INVALID_CONTROL_PAYLOAD_LENGTH"
            );
            cb(error);
            return;
          }
        } else {
          const error = this.createError(
            RangeError,
            `invalid opcode ${this._opcode}`,
            true,
            1002,
            "WS_ERR_INVALID_OPCODE"
          );
          cb(error);
          return;
        }
        if (!this._fin && !this._fragmented) this._fragmented = this._opcode;
        this._masked = (buf[1] & 128) === 128;
        if (this._isServer) {
          if (!this._masked) {
            const error = this.createError(
              RangeError,
              "MASK must be set",
              true,
              1002,
              "WS_ERR_EXPECTED_MASK"
            );
            cb(error);
            return;
          }
        } else if (this._masked) {
          const error = this.createError(
            RangeError,
            "MASK must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_MASK"
          );
          cb(error);
          return;
        }
        if (this._payloadLength === 126) this._state = GET_PAYLOAD_LENGTH_16;
        else if (this._payloadLength === 127) this._state = GET_PAYLOAD_LENGTH_64;
        else this.haveLength(cb);
      }
      /**
       * Gets extended payload length (7+16).
       *
       * @param {Function} cb Callback
       * @private
       */
      getPayloadLength16(cb) {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        this._payloadLength = this.consume(2).readUInt16BE(0);
        this.haveLength(cb);
      }
      /**
       * Gets extended payload length (7+64).
       *
       * @param {Function} cb Callback
       * @private
       */
      getPayloadLength64(cb) {
        if (this._bufferedBytes < 8) {
          this._loop = false;
          return;
        }
        const buf = this.consume(8);
        const num = buf.readUInt32BE(0);
        if (num > Math.pow(2, 53 - 32) - 1) {
          const error = this.createError(
            RangeError,
            "Unsupported WebSocket frame: payload length > 2^53 - 1",
            false,
            1009,
            "WS_ERR_UNSUPPORTED_DATA_PAYLOAD_LENGTH"
          );
          cb(error);
          return;
        }
        this._payloadLength = num * Math.pow(2, 32) + buf.readUInt32BE(4);
        this.haveLength(cb);
      }
      /**
       * Payload length has been read.
       *
       * @param {Function} cb Callback
       * @private
       */
      haveLength(cb) {
        if (this._payloadLength && this._opcode < 8) {
          this._totalPayloadLength += this._payloadLength;
          if (this._totalPayloadLength > this._maxPayload && this._maxPayload > 0) {
            const error = this.createError(
              RangeError,
              "Max payload size exceeded",
              false,
              1009,
              "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
            );
            cb(error);
            return;
          }
        }
        if (this._masked) this._state = GET_MASK;
        else this._state = GET_DATA;
      }
      /**
       * Reads mask bytes.
       *
       * @private
       */
      getMask() {
        if (this._bufferedBytes < 4) {
          this._loop = false;
          return;
        }
        this._mask = this.consume(4);
        this._state = GET_DATA;
      }
      /**
       * Reads data bytes.
       *
       * @param {Function} cb Callback
       * @private
       */
      getData(cb) {
        let data = EMPTY_BUFFER;
        if (this._payloadLength) {
          if (this._bufferedBytes < this._payloadLength) {
            this._loop = false;
            return;
          }
          data = this.consume(this._payloadLength);
          if (this._masked && (this._mask[0] | this._mask[1] | this._mask[2] | this._mask[3]) !== 0) {
            unmask(data, this._mask);
          }
        }
        if (this._opcode > 7) {
          this.controlMessage(data, cb);
          return;
        }
        if (this._compressed) {
          this._state = INFLATING;
          this.decompress(data, cb);
          return;
        }
        if (data.length) {
          this._messageLength = this._totalPayloadLength;
          this._fragments.push(data);
        }
        this.dataMessage(cb);
      }
      /**
       * Decompresses data.
       *
       * @param {Buffer} data Compressed data
       * @param {Function} cb Callback
       * @private
       */
      decompress(data, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate.extensionName];
        perMessageDeflate.decompress(data, this._fin, (err, buf) => {
          if (err) return cb(err);
          if (buf.length) {
            this._messageLength += buf.length;
            if (this._messageLength > this._maxPayload && this._maxPayload > 0) {
              const error = this.createError(
                RangeError,
                "Max payload size exceeded",
                false,
                1009,
                "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
              );
              cb(error);
              return;
            }
            this._fragments.push(buf);
          }
          this.dataMessage(cb);
          if (this._state === GET_INFO) this.startLoop(cb);
        });
      }
      /**
       * Handles a data message.
       *
       * @param {Function} cb Callback
       * @private
       */
      dataMessage(cb) {
        if (!this._fin) {
          this._state = GET_INFO;
          return;
        }
        const messageLength = this._messageLength;
        const fragments = this._fragments;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._fragmented = 0;
        this._fragments = [];
        if (this._opcode === 2) {
          let data;
          if (this._binaryType === "nodebuffer") {
            data = concat(fragments, messageLength);
          } else if (this._binaryType === "arraybuffer") {
            data = toArrayBuffer(concat(fragments, messageLength));
          } else if (this._binaryType === "blob") {
            data = new Blob(fragments);
          } else {
            data = fragments;
          }
          if (this._allowSynchronousEvents) {
            this.emit("message", data, true);
            this._state = GET_INFO;
          } else {
            this._state = DEFER_EVENT;
            setImmediate(() => {
              this.emit("message", data, true);
              this._state = GET_INFO;
              this.startLoop(cb);
            });
          }
        } else {
          const buf = concat(fragments, messageLength);
          if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
            const error = this.createError(
              Error,
              "invalid UTF-8 sequence",
              true,
              1007,
              "WS_ERR_INVALID_UTF8"
            );
            cb(error);
            return;
          }
          if (this._state === INFLATING || this._allowSynchronousEvents) {
            this.emit("message", buf, false);
            this._state = GET_INFO;
          } else {
            this._state = DEFER_EVENT;
            setImmediate(() => {
              this.emit("message", buf, false);
              this._state = GET_INFO;
              this.startLoop(cb);
            });
          }
        }
      }
      /**
       * Handles a control message.
       *
       * @param {Buffer} data Data to handle
       * @return {(Error|RangeError|undefined)} A possible error
       * @private
       */
      controlMessage(data, cb) {
        if (this._opcode === 8) {
          if (data.length === 0) {
            this._loop = false;
            this.emit("conclude", 1005, EMPTY_BUFFER);
            this.end();
          } else {
            const code = data.readUInt16BE(0);
            if (!isValidStatusCode(code)) {
              const error = this.createError(
                RangeError,
                `invalid status code ${code}`,
                true,
                1002,
                "WS_ERR_INVALID_CLOSE_CODE"
              );
              cb(error);
              return;
            }
            const buf = new FastBuffer(
              data.buffer,
              data.byteOffset + 2,
              data.length - 2
            );
            if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
              const error = this.createError(
                Error,
                "invalid UTF-8 sequence",
                true,
                1007,
                "WS_ERR_INVALID_UTF8"
              );
              cb(error);
              return;
            }
            this._loop = false;
            this.emit("conclude", code, buf);
            this.end();
          }
          this._state = GET_INFO;
          return;
        }
        if (this._allowSynchronousEvents) {
          this.emit(this._opcode === 9 ? "ping" : "pong", data);
          this._state = GET_INFO;
        } else {
          this._state = DEFER_EVENT;
          setImmediate(() => {
            this.emit(this._opcode === 9 ? "ping" : "pong", data);
            this._state = GET_INFO;
            this.startLoop(cb);
          });
        }
      }
      /**
       * Builds an error object.
       *
       * @param {function(new:Error|RangeError)} ErrorCtor The error constructor
       * @param {String} message The error message
       * @param {Boolean} prefix Specifies whether or not to add a default prefix to
       *     `message`
       * @param {Number} statusCode The status code
       * @param {String} errorCode The exposed error code
       * @return {(Error|RangeError)} The error
       * @private
       */
      createError(ErrorCtor, message, prefix, statusCode, errorCode) {
        this._loop = false;
        this._errored = true;
        const err = new ErrorCtor(
          prefix ? `Invalid WebSocket frame: ${message}` : message
        );
        Error.captureStackTrace(err, this.createError);
        err.code = errorCode;
        err[kStatusCode] = statusCode;
        return err;
      }
    };
    module2.exports = Receiver;
  }
});

// node_modules/ws/lib/sender.js
var require_sender = __commonJS({
  "node_modules/ws/lib/sender.js"(exports2, module2) {
    "use strict";
    var { Duplex } = require("stream");
    var { randomFillSync } = require("crypto");
    var PerMessageDeflate = require_permessage_deflate();
    var { EMPTY_BUFFER, kWebSocket, NOOP } = require_constants();
    var { isBlob, isValidStatusCode } = require_validation();
    var { mask: applyMask, toBuffer } = require_buffer_util();
    var kByteLength = Symbol("kByteLength");
    var maskBuffer = Buffer.alloc(4);
    var RANDOM_POOL_SIZE = 8 * 1024;
    var randomPool;
    var randomPoolPointer = RANDOM_POOL_SIZE;
    var DEFAULT = 0;
    var DEFLATING = 1;
    var GET_BLOB_DATA = 2;
    var Sender = class _Sender {
      /**
       * Creates a Sender instance.
       *
       * @param {Duplex} socket The connection socket
       * @param {Object} [extensions] An object containing the negotiated extensions
       * @param {Function} [generateMask] The function used to generate the masking
       *     key
       */
      constructor(socket, extensions, generateMask) {
        this._extensions = extensions || {};
        if (generateMask) {
          this._generateMask = generateMask;
          this._maskBuffer = Buffer.alloc(4);
        }
        this._socket = socket;
        this._firstFragment = true;
        this._compress = false;
        this._bufferedBytes = 0;
        this._queue = [];
        this._state = DEFAULT;
        this.onerror = NOOP;
        this[kWebSocket] = void 0;
      }
      /**
       * Frames a piece of data according to the HyBi WebSocket protocol.
       *
       * @param {(Buffer|String)} data The data to frame
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @return {(Buffer|String)[]} The framed data
       * @public
       */
      static frame(data, options) {
        let mask;
        let merge = false;
        let offset = 2;
        let skipMasking = false;
        if (options.mask) {
          mask = options.maskBuffer || maskBuffer;
          if (options.generateMask) {
            options.generateMask(mask);
          } else {
            if (randomPoolPointer === RANDOM_POOL_SIZE) {
              if (randomPool === void 0) {
                randomPool = Buffer.alloc(RANDOM_POOL_SIZE);
              }
              randomFillSync(randomPool, 0, RANDOM_POOL_SIZE);
              randomPoolPointer = 0;
            }
            mask[0] = randomPool[randomPoolPointer++];
            mask[1] = randomPool[randomPoolPointer++];
            mask[2] = randomPool[randomPoolPointer++];
            mask[3] = randomPool[randomPoolPointer++];
          }
          skipMasking = (mask[0] | mask[1] | mask[2] | mask[3]) === 0;
          offset = 6;
        }
        let dataLength;
        if (typeof data === "string") {
          if ((!options.mask || skipMasking) && options[kByteLength] !== void 0) {
            dataLength = options[kByteLength];
          } else {
            data = Buffer.from(data);
            dataLength = data.length;
          }
        } else {
          dataLength = data.length;
          merge = options.mask && options.readOnly && !skipMasking;
        }
        let payloadLength = dataLength;
        if (dataLength >= 65536) {
          offset += 8;
          payloadLength = 127;
        } else if (dataLength > 125) {
          offset += 2;
          payloadLength = 126;
        }
        const target = Buffer.allocUnsafe(merge ? dataLength + offset : offset);
        target[0] = options.fin ? options.opcode | 128 : options.opcode;
        if (options.rsv1) target[0] |= 64;
        target[1] = payloadLength;
        if (payloadLength === 126) {
          target.writeUInt16BE(dataLength, 2);
        } else if (payloadLength === 127) {
          target[2] = target[3] = 0;
          target.writeUIntBE(dataLength, 4, 6);
        }
        if (!options.mask) return [target, data];
        target[1] |= 128;
        target[offset - 4] = mask[0];
        target[offset - 3] = mask[1];
        target[offset - 2] = mask[2];
        target[offset - 1] = mask[3];
        if (skipMasking) return [target, data];
        if (merge) {
          applyMask(data, mask, target, offset, dataLength);
          return [target];
        }
        applyMask(data, mask, data, 0, dataLength);
        return [target, data];
      }
      /**
       * Sends a close message to the other peer.
       *
       * @param {Number} [code] The status code component of the body
       * @param {(String|Buffer)} [data] The message component of the body
       * @param {Boolean} [mask=false] Specifies whether or not to mask the message
       * @param {Function} [cb] Callback
       * @public
       */
      close(code, data, mask, cb) {
        let buf;
        if (code === void 0) {
          buf = EMPTY_BUFFER;
        } else if (typeof code !== "number" || !isValidStatusCode(code)) {
          throw new TypeError("First argument must be a valid error code number");
        } else if (data === void 0 || !data.length) {
          buf = Buffer.allocUnsafe(2);
          buf.writeUInt16BE(code, 0);
        } else {
          const length = Buffer.byteLength(data);
          if (length > 123) {
            throw new RangeError("The message must not be greater than 123 bytes");
          }
          buf = Buffer.allocUnsafe(2 + length);
          buf.writeUInt16BE(code, 0);
          if (typeof data === "string") {
            buf.write(data, 2);
          } else {
            buf.set(data, 2);
          }
        }
        const options = {
          [kByteLength]: buf.length,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 8,
          readOnly: false,
          rsv1: false
        };
        if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, buf, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(buf, options), cb);
        }
      }
      /**
       * Sends a ping message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback
       * @public
       */
      ping(data, mask, cb) {
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (byteLength > 125) {
          throw new RangeError("The data size must not be greater than 125 bytes");
        }
        const options = {
          [kByteLength]: byteLength,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 9,
          readOnly,
          rsv1: false
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, false, options, cb]);
          } else {
            this.getBlobData(data, false, options, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(data, options), cb);
        }
      }
      /**
       * Sends a pong message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback
       * @public
       */
      pong(data, mask, cb) {
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (byteLength > 125) {
          throw new RangeError("The data size must not be greater than 125 bytes");
        }
        const options = {
          [kByteLength]: byteLength,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 10,
          readOnly,
          rsv1: false
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, false, options, cb]);
          } else {
            this.getBlobData(data, false, options, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(data, options), cb);
        }
      }
      /**
       * Sends a data message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Object} options Options object
       * @param {Boolean} [options.binary=false] Specifies whether `data` is binary
       *     or text
       * @param {Boolean} [options.compress=false] Specifies whether or not to
       *     compress `data`
       * @param {Boolean} [options.fin=false] Specifies whether the fragment is the
       *     last one
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Function} [cb] Callback
       * @public
       */
      send(data, options, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate.extensionName];
        let opcode = options.binary ? 2 : 1;
        let rsv1 = options.compress;
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (this._firstFragment) {
          this._firstFragment = false;
          if (rsv1 && perMessageDeflate && perMessageDeflate.params[perMessageDeflate._isServer ? "server_no_context_takeover" : "client_no_context_takeover"]) {
            rsv1 = byteLength >= perMessageDeflate._threshold;
          }
          this._compress = rsv1;
        } else {
          rsv1 = false;
          opcode = 0;
        }
        if (options.fin) this._firstFragment = true;
        const opts = {
          [kByteLength]: byteLength,
          fin: options.fin,
          generateMask: this._generateMask,
          mask: options.mask,
          maskBuffer: this._maskBuffer,
          opcode,
          readOnly,
          rsv1
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, this._compress, opts, cb]);
          } else {
            this.getBlobData(data, this._compress, opts, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, this._compress, opts, cb]);
        } else {
          this.dispatch(data, this._compress, opts, cb);
        }
      }
      /**
       * Gets the contents of a blob as binary data.
       *
       * @param {Blob} blob The blob
       * @param {Boolean} [compress=false] Specifies whether or not to compress
       *     the data
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @param {Function} [cb] Callback
       * @private
       */
      getBlobData(blob, compress, options, cb) {
        this._bufferedBytes += options[kByteLength];
        this._state = GET_BLOB_DATA;
        blob.arrayBuffer().then((arrayBuffer) => {
          if (this._socket.destroyed) {
            const err = new Error(
              "The socket was closed while the blob was being read"
            );
            process.nextTick(callCallbacks, this, err, cb);
            return;
          }
          this._bufferedBytes -= options[kByteLength];
          const data = toBuffer(arrayBuffer);
          if (!compress) {
            this._state = DEFAULT;
            this.sendFrame(_Sender.frame(data, options), cb);
            this.dequeue();
          } else {
            this.dispatch(data, compress, options, cb);
          }
        }).catch((err) => {
          process.nextTick(onError, this, err, cb);
        });
      }
      /**
       * Dispatches a message.
       *
       * @param {(Buffer|String)} data The message to send
       * @param {Boolean} [compress=false] Specifies whether or not to compress
       *     `data`
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @param {Function} [cb] Callback
       * @private
       */
      dispatch(data, compress, options, cb) {
        if (!compress) {
          this.sendFrame(_Sender.frame(data, options), cb);
          return;
        }
        const perMessageDeflate = this._extensions[PerMessageDeflate.extensionName];
        this._bufferedBytes += options[kByteLength];
        this._state = DEFLATING;
        perMessageDeflate.compress(data, options.fin, (_, buf) => {
          if (this._socket.destroyed) {
            const err = new Error(
              "The socket was closed while data was being compressed"
            );
            callCallbacks(this, err, cb);
            return;
          }
          this._bufferedBytes -= options[kByteLength];
          this._state = DEFAULT;
          options.readOnly = false;
          this.sendFrame(_Sender.frame(buf, options), cb);
          this.dequeue();
        });
      }
      /**
       * Executes queued send operations.
       *
       * @private
       */
      dequeue() {
        while (this._state === DEFAULT && this._queue.length) {
          const params = this._queue.shift();
          this._bufferedBytes -= params[3][kByteLength];
          Reflect.apply(params[0], this, params.slice(1));
        }
      }
      /**
       * Enqueues a send operation.
       *
       * @param {Array} params Send operation parameters.
       * @private
       */
      enqueue(params) {
        this._bufferedBytes += params[3][kByteLength];
        this._queue.push(params);
      }
      /**
       * Sends a frame.
       *
       * @param {Buffer[]} list The frame to send
       * @param {Function} [cb] Callback
       * @private
       */
      sendFrame(list, cb) {
        if (list.length === 2) {
          this._socket.cork();
          this._socket.write(list[0]);
          this._socket.write(list[1], cb);
          this._socket.uncork();
        } else {
          this._socket.write(list[0], cb);
        }
      }
    };
    module2.exports = Sender;
    function callCallbacks(sender, err, cb) {
      if (typeof cb === "function") cb(err);
      for (let i = 0; i < sender._queue.length; i++) {
        const params = sender._queue[i];
        const callback = params[params.length - 1];
        if (typeof callback === "function") callback(err);
      }
    }
    function onError(sender, err, cb) {
      callCallbacks(sender, err, cb);
      sender.onerror(err);
    }
  }
});

// node_modules/ws/lib/event-target.js
var require_event_target = __commonJS({
  "node_modules/ws/lib/event-target.js"(exports2, module2) {
    "use strict";
    var { kForOnEventAttribute, kListener } = require_constants();
    var kCode = Symbol("kCode");
    var kData = Symbol("kData");
    var kError = Symbol("kError");
    var kMessage = Symbol("kMessage");
    var kReason = Symbol("kReason");
    var kTarget = Symbol("kTarget");
    var kType = Symbol("kType");
    var kWasClean = Symbol("kWasClean");
    var Event = class {
      /**
       * Create a new `Event`.
       *
       * @param {String} type The name of the event
       * @throws {TypeError} If the `type` argument is not specified
       */
      constructor(type) {
        this[kTarget] = null;
        this[kType] = type;
      }
      /**
       * @type {*}
       */
      get target() {
        return this[kTarget];
      }
      /**
       * @type {String}
       */
      get type() {
        return this[kType];
      }
    };
    Object.defineProperty(Event.prototype, "target", { enumerable: true });
    Object.defineProperty(Event.prototype, "type", { enumerable: true });
    var CloseEvent = class extends Event {
      /**
       * Create a new `CloseEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {Number} [options.code=0] The status code explaining why the
       *     connection was closed
       * @param {String} [options.reason=''] A human-readable string explaining why
       *     the connection was closed
       * @param {Boolean} [options.wasClean=false] Indicates whether or not the
       *     connection was cleanly closed
       */
      constructor(type, options = {}) {
        super(type);
        this[kCode] = options.code === void 0 ? 0 : options.code;
        this[kReason] = options.reason === void 0 ? "" : options.reason;
        this[kWasClean] = options.wasClean === void 0 ? false : options.wasClean;
      }
      /**
       * @type {Number}
       */
      get code() {
        return this[kCode];
      }
      /**
       * @type {String}
       */
      get reason() {
        return this[kReason];
      }
      /**
       * @type {Boolean}
       */
      get wasClean() {
        return this[kWasClean];
      }
    };
    Object.defineProperty(CloseEvent.prototype, "code", { enumerable: true });
    Object.defineProperty(CloseEvent.prototype, "reason", { enumerable: true });
    Object.defineProperty(CloseEvent.prototype, "wasClean", { enumerable: true });
    var ErrorEvent = class extends Event {
      /**
       * Create a new `ErrorEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {*} [options.error=null] The error that generated this event
       * @param {String} [options.message=''] The error message
       */
      constructor(type, options = {}) {
        super(type);
        this[kError] = options.error === void 0 ? null : options.error;
        this[kMessage] = options.message === void 0 ? "" : options.message;
      }
      /**
       * @type {*}
       */
      get error() {
        return this[kError];
      }
      /**
       * @type {String}
       */
      get message() {
        return this[kMessage];
      }
    };
    Object.defineProperty(ErrorEvent.prototype, "error", { enumerable: true });
    Object.defineProperty(ErrorEvent.prototype, "message", { enumerable: true });
    var MessageEvent = class extends Event {
      /**
       * Create a new `MessageEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {*} [options.data=null] The message content
       */
      constructor(type, options = {}) {
        super(type);
        this[kData] = options.data === void 0 ? null : options.data;
      }
      /**
       * @type {*}
       */
      get data() {
        return this[kData];
      }
    };
    Object.defineProperty(MessageEvent.prototype, "data", { enumerable: true });
    var EventTarget = {
      /**
       * Register an event listener.
       *
       * @param {String} type A string representing the event type to listen for
       * @param {(Function|Object)} handler The listener to add
       * @param {Object} [options] An options object specifies characteristics about
       *     the event listener
       * @param {Boolean} [options.once=false] A `Boolean` indicating that the
       *     listener should be invoked at most once after being added. If `true`,
       *     the listener would be automatically removed when invoked.
       * @public
       */
      addEventListener(type, handler, options = {}) {
        for (const listener of this.listeners(type)) {
          if (!options[kForOnEventAttribute] && listener[kListener] === handler && !listener[kForOnEventAttribute]) {
            return;
          }
        }
        let wrapper;
        if (type === "message") {
          wrapper = function onMessage(data, isBinary) {
            const event = new MessageEvent("message", {
              data: isBinary ? data : data.toString()
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "close") {
          wrapper = function onClose(code, message) {
            const event = new CloseEvent("close", {
              code,
              reason: message.toString(),
              wasClean: this._closeFrameReceived && this._closeFrameSent
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "error") {
          wrapper = function onError(error) {
            const event = new ErrorEvent("error", {
              error,
              message: error.message
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "open") {
          wrapper = function onOpen() {
            const event = new Event("open");
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else {
          return;
        }
        wrapper[kForOnEventAttribute] = !!options[kForOnEventAttribute];
        wrapper[kListener] = handler;
        if (options.once) {
          this.once(type, wrapper);
        } else {
          this.on(type, wrapper);
        }
      },
      /**
       * Remove an event listener.
       *
       * @param {String} type A string representing the event type to remove
       * @param {(Function|Object)} handler The listener to remove
       * @public
       */
      removeEventListener(type, handler) {
        for (const listener of this.listeners(type)) {
          if (listener[kListener] === handler && !listener[kForOnEventAttribute]) {
            this.removeListener(type, listener);
            break;
          }
        }
      }
    };
    module2.exports = {
      CloseEvent,
      ErrorEvent,
      Event,
      EventTarget,
      MessageEvent
    };
    function callListener(listener, thisArg, event) {
      if (typeof listener === "object" && listener.handleEvent) {
        listener.handleEvent.call(listener, event);
      } else {
        listener.call(thisArg, event);
      }
    }
  }
});

// node_modules/ws/lib/extension.js
var require_extension = __commonJS({
  "node_modules/ws/lib/extension.js"(exports2, module2) {
    "use strict";
    var { tokenChars } = require_validation();
    function push(dest, name, elem) {
      if (dest[name] === void 0) dest[name] = [elem];
      else dest[name].push(elem);
    }
    function parse(header) {
      const offers = /* @__PURE__ */ Object.create(null);
      let params = /* @__PURE__ */ Object.create(null);
      let mustUnescape = false;
      let isEscaping = false;
      let inQuotes = false;
      let extensionName;
      let paramName;
      let start = -1;
      let code = -1;
      let end = -1;
      let i = 0;
      for (; i < header.length; i++) {
        code = header.charCodeAt(i);
        if (extensionName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (i !== 0 && (code === 32 || code === 9)) {
            if (end === -1 && start !== -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            const name = header.slice(start, end);
            if (code === 44) {
              push(offers, name, params);
              params = /* @__PURE__ */ Object.create(null);
            } else {
              extensionName = name;
            }
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else if (paramName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (code === 32 || code === 9) {
            if (end === -1 && start !== -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            push(params, header.slice(start, end), true);
            if (code === 44) {
              push(offers, extensionName, params);
              params = /* @__PURE__ */ Object.create(null);
              extensionName = void 0;
            }
            start = end = -1;
          } else if (code === 61 && start !== -1 && end === -1) {
            paramName = header.slice(start, i);
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else {
          if (isEscaping) {
            if (tokenChars[code] !== 1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (start === -1) start = i;
            else if (!mustUnescape) mustUnescape = true;
            isEscaping = false;
          } else if (inQuotes) {
            if (tokenChars[code] === 1) {
              if (start === -1) start = i;
            } else if (code === 34 && start !== -1) {
              inQuotes = false;
              end = i;
            } else if (code === 92) {
              isEscaping = true;
            } else {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
          } else if (code === 34 && header.charCodeAt(i - 1) === 61) {
            inQuotes = true;
          } else if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (start !== -1 && (code === 32 || code === 9)) {
            if (end === -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            let value = header.slice(start, end);
            if (mustUnescape) {
              value = value.replace(/\\/g, "");
              mustUnescape = false;
            }
            push(params, paramName, value);
            if (code === 44) {
              push(offers, extensionName, params);
              params = /* @__PURE__ */ Object.create(null);
              extensionName = void 0;
            }
            paramName = void 0;
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        }
      }
      if (start === -1 || inQuotes || code === 32 || code === 9) {
        throw new SyntaxError("Unexpected end of input");
      }
      if (end === -1) end = i;
      const token = header.slice(start, end);
      if (extensionName === void 0) {
        push(offers, token, params);
      } else {
        if (paramName === void 0) {
          push(params, token, true);
        } else if (mustUnescape) {
          push(params, paramName, token.replace(/\\/g, ""));
        } else {
          push(params, paramName, token);
        }
        push(offers, extensionName, params);
      }
      return offers;
    }
    function format(extensions) {
      return Object.keys(extensions).map((extension) => {
        let configurations = extensions[extension];
        if (!Array.isArray(configurations)) configurations = [configurations];
        return configurations.map((params) => {
          return [extension].concat(
            Object.keys(params).map((k) => {
              let values = params[k];
              if (!Array.isArray(values)) values = [values];
              return values.map((v) => v === true ? k : `${k}=${v}`).join("; ");
            })
          ).join("; ");
        }).join(", ");
      }).join(", ");
    }
    module2.exports = { format, parse };
  }
});

// node_modules/ws/lib/websocket.js
var require_websocket = __commonJS({
  "node_modules/ws/lib/websocket.js"(exports2, module2) {
    "use strict";
    var EventEmitter = require("events");
    var https = require("https");
    var http = require("http");
    var net = require("net");
    var tls = require("tls");
    var { randomBytes, createHash } = require("crypto");
    var { Duplex, Readable } = require("stream");
    var { URL: URL2 } = require("url");
    var PerMessageDeflate = require_permessage_deflate();
    var Receiver = require_receiver();
    var Sender = require_sender();
    var { isBlob } = require_validation();
    var {
      BINARY_TYPES,
      EMPTY_BUFFER,
      GUID,
      kForOnEventAttribute,
      kListener,
      kStatusCode,
      kWebSocket,
      NOOP
    } = require_constants();
    var {
      EventTarget: { addEventListener, removeEventListener }
    } = require_event_target();
    var { format, parse } = require_extension();
    var { toBuffer } = require_buffer_util();
    var closeTimeout = 30 * 1e3;
    var kAborted = Symbol("kAborted");
    var protocolVersions = [8, 13];
    var readyStates = ["CONNECTING", "OPEN", "CLOSING", "CLOSED"];
    var subprotocolRegex = /^[!#$%&'*+\-.0-9A-Z^_`|a-z~]+$/;
    var WebSocket2 = class _WebSocket extends EventEmitter {
      /**
       * Create a new `WebSocket`.
       *
       * @param {(String|URL)} address The URL to which to connect
       * @param {(String|String[])} [protocols] The subprotocols
       * @param {Object} [options] Connection options
       */
      constructor(address, protocols, options) {
        super();
        this._binaryType = BINARY_TYPES[0];
        this._closeCode = 1006;
        this._closeFrameReceived = false;
        this._closeFrameSent = false;
        this._closeMessage = EMPTY_BUFFER;
        this._closeTimer = null;
        this._errorEmitted = false;
        this._extensions = {};
        this._paused = false;
        this._protocol = "";
        this._readyState = _WebSocket.CONNECTING;
        this._receiver = null;
        this._sender = null;
        this._socket = null;
        if (address !== null) {
          this._bufferedAmount = 0;
          this._isServer = false;
          this._redirects = 0;
          if (protocols === void 0) {
            protocols = [];
          } else if (!Array.isArray(protocols)) {
            if (typeof protocols === "object" && protocols !== null) {
              options = protocols;
              protocols = [];
            } else {
              protocols = [protocols];
            }
          }
          initAsClient(this, address, protocols, options);
        } else {
          this._autoPong = options.autoPong;
          this._isServer = true;
        }
      }
      /**
       * For historical reasons, the custom "nodebuffer" type is used by the default
       * instead of "blob".
       *
       * @type {String}
       */
      get binaryType() {
        return this._binaryType;
      }
      set binaryType(type) {
        if (!BINARY_TYPES.includes(type)) return;
        this._binaryType = type;
        if (this._receiver) this._receiver._binaryType = type;
      }
      /**
       * @type {Number}
       */
      get bufferedAmount() {
        if (!this._socket) return this._bufferedAmount;
        return this._socket._writableState.length + this._sender._bufferedBytes;
      }
      /**
       * @type {String}
       */
      get extensions() {
        return Object.keys(this._extensions).join();
      }
      /**
       * @type {Boolean}
       */
      get isPaused() {
        return this._paused;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onclose() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onerror() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onopen() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onmessage() {
        return null;
      }
      /**
       * @type {String}
       */
      get protocol() {
        return this._protocol;
      }
      /**
       * @type {Number}
       */
      get readyState() {
        return this._readyState;
      }
      /**
       * @type {String}
       */
      get url() {
        return this._url;
      }
      /**
       * Set up the socket and the internal resources.
       *
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Object} options Options object
       * @param {Boolean} [options.allowSynchronousEvents=false] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Number} [options.maxPayload=0] The maximum allowed message size
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       * @private
       */
      setSocket(socket, head, options) {
        const receiver = new Receiver({
          allowSynchronousEvents: options.allowSynchronousEvents,
          binaryType: this.binaryType,
          extensions: this._extensions,
          isServer: this._isServer,
          maxPayload: options.maxPayload,
          skipUTF8Validation: options.skipUTF8Validation
        });
        const sender = new Sender(socket, this._extensions, options.generateMask);
        this._receiver = receiver;
        this._sender = sender;
        this._socket = socket;
        receiver[kWebSocket] = this;
        sender[kWebSocket] = this;
        socket[kWebSocket] = this;
        receiver.on("conclude", receiverOnConclude);
        receiver.on("drain", receiverOnDrain);
        receiver.on("error", receiverOnError);
        receiver.on("message", receiverOnMessage);
        receiver.on("ping", receiverOnPing);
        receiver.on("pong", receiverOnPong);
        sender.onerror = senderOnError;
        if (socket.setTimeout) socket.setTimeout(0);
        if (socket.setNoDelay) socket.setNoDelay();
        if (head.length > 0) socket.unshift(head);
        socket.on("close", socketOnClose);
        socket.on("data", socketOnData);
        socket.on("end", socketOnEnd);
        socket.on("error", socketOnError);
        this._readyState = _WebSocket.OPEN;
        this.emit("open");
      }
      /**
       * Emit the `'close'` event.
       *
       * @private
       */
      emitClose() {
        if (!this._socket) {
          this._readyState = _WebSocket.CLOSED;
          this.emit("close", this._closeCode, this._closeMessage);
          return;
        }
        if (this._extensions[PerMessageDeflate.extensionName]) {
          this._extensions[PerMessageDeflate.extensionName].cleanup();
        }
        this._receiver.removeAllListeners();
        this._readyState = _WebSocket.CLOSED;
        this.emit("close", this._closeCode, this._closeMessage);
      }
      /**
       * Start a closing handshake.
       *
       *          +----------+   +-----------+   +----------+
       *     - - -|ws.close()|-->|close frame|-->|ws.close()|- - -
       *    |     +----------+   +-----------+   +----------+     |
       *          +----------+   +-----------+         |
       * CLOSING  |ws.close()|<--|close frame|<--+-----+       CLOSING
       *          +----------+   +-----------+   |
       *    |           |                        |   +---+        |
       *                +------------------------+-->|fin| - - - -
       *    |         +---+                      |   +---+
       *     - - - - -|fin|<---------------------+
       *              +---+
       *
       * @param {Number} [code] Status code explaining why the connection is closing
       * @param {(String|Buffer)} [data] The reason why the connection is
       *     closing
       * @public
       */
      close(code, data) {
        if (this.readyState === _WebSocket.CLOSED) return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          abortHandshake(this, this._req, msg);
          return;
        }
        if (this.readyState === _WebSocket.CLOSING) {
          if (this._closeFrameSent && (this._closeFrameReceived || this._receiver._writableState.errorEmitted)) {
            this._socket.end();
          }
          return;
        }
        this._readyState = _WebSocket.CLOSING;
        this._sender.close(code, data, !this._isServer, (err) => {
          if (err) return;
          this._closeFrameSent = true;
          if (this._closeFrameReceived || this._receiver._writableState.errorEmitted) {
            this._socket.end();
          }
        });
        setCloseTimer(this);
      }
      /**
       * Pause the socket.
       *
       * @public
       */
      pause() {
        if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
          return;
        }
        this._paused = true;
        this._socket.pause();
      }
      /**
       * Send a ping.
       *
       * @param {*} [data] The data to send
       * @param {Boolean} [mask] Indicates whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when the ping is sent
       * @public
       */
      ping(data, mask, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        if (mask === void 0) mask = !this._isServer;
        this._sender.ping(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Send a pong.
       *
       * @param {*} [data] The data to send
       * @param {Boolean} [mask] Indicates whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when the pong is sent
       * @public
       */
      pong(data, mask, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        if (mask === void 0) mask = !this._isServer;
        this._sender.pong(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Resume the socket.
       *
       * @public
       */
      resume() {
        if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
          return;
        }
        this._paused = false;
        if (!this._receiver._writableState.needDrain) this._socket.resume();
      }
      /**
       * Send a data message.
       *
       * @param {*} data The message to send
       * @param {Object} [options] Options object
       * @param {Boolean} [options.binary] Specifies whether `data` is binary or
       *     text
       * @param {Boolean} [options.compress] Specifies whether or not to compress
       *     `data`
       * @param {Boolean} [options.fin=true] Specifies whether the fragment is the
       *     last one
       * @param {Boolean} [options.mask] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when data is written out
       * @public
       */
      send(data, options, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof options === "function") {
          cb = options;
          options = {};
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        const opts = {
          binary: typeof data !== "string",
          mask: !this._isServer,
          compress: true,
          fin: true,
          ...options
        };
        if (!this._extensions[PerMessageDeflate.extensionName]) {
          opts.compress = false;
        }
        this._sender.send(data || EMPTY_BUFFER, opts, cb);
      }
      /**
       * Forcibly close the connection.
       *
       * @public
       */
      terminate() {
        if (this.readyState === _WebSocket.CLOSED) return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          abortHandshake(this, this._req, msg);
          return;
        }
        if (this._socket) {
          this._readyState = _WebSocket.CLOSING;
          this._socket.destroy();
        }
      }
    };
    Object.defineProperty(WebSocket2, "CONNECTING", {
      enumerable: true,
      value: readyStates.indexOf("CONNECTING")
    });
    Object.defineProperty(WebSocket2.prototype, "CONNECTING", {
      enumerable: true,
      value: readyStates.indexOf("CONNECTING")
    });
    Object.defineProperty(WebSocket2, "OPEN", {
      enumerable: true,
      value: readyStates.indexOf("OPEN")
    });
    Object.defineProperty(WebSocket2.prototype, "OPEN", {
      enumerable: true,
      value: readyStates.indexOf("OPEN")
    });
    Object.defineProperty(WebSocket2, "CLOSING", {
      enumerable: true,
      value: readyStates.indexOf("CLOSING")
    });
    Object.defineProperty(WebSocket2.prototype, "CLOSING", {
      enumerable: true,
      value: readyStates.indexOf("CLOSING")
    });
    Object.defineProperty(WebSocket2, "CLOSED", {
      enumerable: true,
      value: readyStates.indexOf("CLOSED")
    });
    Object.defineProperty(WebSocket2.prototype, "CLOSED", {
      enumerable: true,
      value: readyStates.indexOf("CLOSED")
    });
    [
      "binaryType",
      "bufferedAmount",
      "extensions",
      "isPaused",
      "protocol",
      "readyState",
      "url"
    ].forEach((property) => {
      Object.defineProperty(WebSocket2.prototype, property, { enumerable: true });
    });
    ["open", "error", "close", "message"].forEach((method) => {
      Object.defineProperty(WebSocket2.prototype, `on${method}`, {
        enumerable: true,
        get() {
          for (const listener of this.listeners(method)) {
            if (listener[kForOnEventAttribute]) return listener[kListener];
          }
          return null;
        },
        set(handler) {
          for (const listener of this.listeners(method)) {
            if (listener[kForOnEventAttribute]) {
              this.removeListener(method, listener);
              break;
            }
          }
          if (typeof handler !== "function") return;
          this.addEventListener(method, handler, {
            [kForOnEventAttribute]: true
          });
        }
      });
    });
    WebSocket2.prototype.addEventListener = addEventListener;
    WebSocket2.prototype.removeEventListener = removeEventListener;
    module2.exports = WebSocket2;
    function initAsClient(websocket, address, protocols, options) {
      const opts = {
        allowSynchronousEvents: true,
        autoPong: true,
        protocolVersion: protocolVersions[1],
        maxPayload: 100 * 1024 * 1024,
        skipUTF8Validation: false,
        perMessageDeflate: true,
        followRedirects: false,
        maxRedirects: 10,
        ...options,
        socketPath: void 0,
        hostname: void 0,
        protocol: void 0,
        timeout: void 0,
        method: "GET",
        host: void 0,
        path: void 0,
        port: void 0
      };
      websocket._autoPong = opts.autoPong;
      if (!protocolVersions.includes(opts.protocolVersion)) {
        throw new RangeError(
          `Unsupported protocol version: ${opts.protocolVersion} (supported versions: ${protocolVersions.join(", ")})`
        );
      }
      let parsedUrl;
      if (address instanceof URL2) {
        parsedUrl = address;
      } else {
        try {
          parsedUrl = new URL2(address);
        } catch (e) {
          throw new SyntaxError(`Invalid URL: ${address}`);
        }
      }
      if (parsedUrl.protocol === "http:") {
        parsedUrl.protocol = "ws:";
      } else if (parsedUrl.protocol === "https:") {
        parsedUrl.protocol = "wss:";
      }
      websocket._url = parsedUrl.href;
      const isSecure = parsedUrl.protocol === "wss:";
      const isIpcUrl = parsedUrl.protocol === "ws+unix:";
      let invalidUrlMessage;
      if (parsedUrl.protocol !== "ws:" && !isSecure && !isIpcUrl) {
        invalidUrlMessage = `The URL's protocol must be one of "ws:", "wss:", "http:", "https", or "ws+unix:"`;
      } else if (isIpcUrl && !parsedUrl.pathname) {
        invalidUrlMessage = "The URL's pathname is empty";
      } else if (parsedUrl.hash) {
        invalidUrlMessage = "The URL contains a fragment identifier";
      }
      if (invalidUrlMessage) {
        const err = new SyntaxError(invalidUrlMessage);
        if (websocket._redirects === 0) {
          throw err;
        } else {
          emitErrorAndClose(websocket, err);
          return;
        }
      }
      const defaultPort = isSecure ? 443 : 80;
      const key = randomBytes(16).toString("base64");
      const request = isSecure ? https.request : http.request;
      const protocolSet = /* @__PURE__ */ new Set();
      let perMessageDeflate;
      opts.createConnection = opts.createConnection || (isSecure ? tlsConnect : netConnect);
      opts.defaultPort = opts.defaultPort || defaultPort;
      opts.port = parsedUrl.port || defaultPort;
      opts.host = parsedUrl.hostname.startsWith("[") ? parsedUrl.hostname.slice(1, -1) : parsedUrl.hostname;
      opts.headers = {
        ...opts.headers,
        "Sec-WebSocket-Version": opts.protocolVersion,
        "Sec-WebSocket-Key": key,
        Connection: "Upgrade",
        Upgrade: "websocket"
      };
      opts.path = parsedUrl.pathname + parsedUrl.search;
      opts.timeout = opts.handshakeTimeout;
      if (opts.perMessageDeflate) {
        perMessageDeflate = new PerMessageDeflate(
          opts.perMessageDeflate !== true ? opts.perMessageDeflate : {},
          false,
          opts.maxPayload
        );
        opts.headers["Sec-WebSocket-Extensions"] = format({
          [PerMessageDeflate.extensionName]: perMessageDeflate.offer()
        });
      }
      if (protocols.length) {
        for (const protocol of protocols) {
          if (typeof protocol !== "string" || !subprotocolRegex.test(protocol) || protocolSet.has(protocol)) {
            throw new SyntaxError(
              "An invalid or duplicated subprotocol was specified"
            );
          }
          protocolSet.add(protocol);
        }
        opts.headers["Sec-WebSocket-Protocol"] = protocols.join(",");
      }
      if (opts.origin) {
        if (opts.protocolVersion < 13) {
          opts.headers["Sec-WebSocket-Origin"] = opts.origin;
        } else {
          opts.headers.Origin = opts.origin;
        }
      }
      if (parsedUrl.username || parsedUrl.password) {
        opts.auth = `${parsedUrl.username}:${parsedUrl.password}`;
      }
      if (isIpcUrl) {
        const parts = opts.path.split(":");
        opts.socketPath = parts[0];
        opts.path = parts[1];
      }
      let req;
      if (opts.followRedirects) {
        if (websocket._redirects === 0) {
          websocket._originalIpc = isIpcUrl;
          websocket._originalSecure = isSecure;
          websocket._originalHostOrSocketPath = isIpcUrl ? opts.socketPath : parsedUrl.host;
          const headers = options && options.headers;
          options = { ...options, headers: {} };
          if (headers) {
            for (const [key2, value] of Object.entries(headers)) {
              options.headers[key2.toLowerCase()] = value;
            }
          }
        } else if (websocket.listenerCount("redirect") === 0) {
          const isSameHost = isIpcUrl ? websocket._originalIpc ? opts.socketPath === websocket._originalHostOrSocketPath : false : websocket._originalIpc ? false : parsedUrl.host === websocket._originalHostOrSocketPath;
          if (!isSameHost || websocket._originalSecure && !isSecure) {
            delete opts.headers.authorization;
            delete opts.headers.cookie;
            if (!isSameHost) delete opts.headers.host;
            opts.auth = void 0;
          }
        }
        if (opts.auth && !options.headers.authorization) {
          options.headers.authorization = "Basic " + Buffer.from(opts.auth).toString("base64");
        }
        req = websocket._req = request(opts);
        if (websocket._redirects) {
          websocket.emit("redirect", websocket.url, req);
        }
      } else {
        req = websocket._req = request(opts);
      }
      if (opts.timeout) {
        req.on("timeout", () => {
          abortHandshake(websocket, req, "Opening handshake has timed out");
        });
      }
      req.on("error", (err) => {
        if (req === null || req[kAborted]) return;
        req = websocket._req = null;
        emitErrorAndClose(websocket, err);
      });
      req.on("response", (res) => {
        const location = res.headers.location;
        const statusCode = res.statusCode;
        if (location && opts.followRedirects && statusCode >= 300 && statusCode < 400) {
          if (++websocket._redirects > opts.maxRedirects) {
            abortHandshake(websocket, req, "Maximum redirects exceeded");
            return;
          }
          req.abort();
          let addr;
          try {
            addr = new URL2(location, address);
          } catch (e) {
            const err = new SyntaxError(`Invalid URL: ${location}`);
            emitErrorAndClose(websocket, err);
            return;
          }
          initAsClient(websocket, addr, protocols, options);
        } else if (!websocket.emit("unexpected-response", req, res)) {
          abortHandshake(
            websocket,
            req,
            `Unexpected server response: ${res.statusCode}`
          );
        }
      });
      req.on("upgrade", (res, socket, head) => {
        websocket.emit("upgrade", res);
        if (websocket.readyState !== WebSocket2.CONNECTING) return;
        req = websocket._req = null;
        const upgrade = res.headers.upgrade;
        if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
          abortHandshake(websocket, socket, "Invalid Upgrade header");
          return;
        }
        const digest = createHash("sha1").update(key + GUID).digest("base64");
        if (res.headers["sec-websocket-accept"] !== digest) {
          abortHandshake(websocket, socket, "Invalid Sec-WebSocket-Accept header");
          return;
        }
        const serverProt = res.headers["sec-websocket-protocol"];
        let protError;
        if (serverProt !== void 0) {
          if (!protocolSet.size) {
            protError = "Server sent a subprotocol but none was requested";
          } else if (!protocolSet.has(serverProt)) {
            protError = "Server sent an invalid subprotocol";
          }
        } else if (protocolSet.size) {
          protError = "Server sent no subprotocol";
        }
        if (protError) {
          abortHandshake(websocket, socket, protError);
          return;
        }
        if (serverProt) websocket._protocol = serverProt;
        const secWebSocketExtensions = res.headers["sec-websocket-extensions"];
        if (secWebSocketExtensions !== void 0) {
          if (!perMessageDeflate) {
            const message = "Server sent a Sec-WebSocket-Extensions header but no extension was requested";
            abortHandshake(websocket, socket, message);
            return;
          }
          let extensions;
          try {
            extensions = parse(secWebSocketExtensions);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Extensions header";
            abortHandshake(websocket, socket, message);
            return;
          }
          const extensionNames = Object.keys(extensions);
          if (extensionNames.length !== 1 || extensionNames[0] !== PerMessageDeflate.extensionName) {
            const message = "Server indicated an extension that was not requested";
            abortHandshake(websocket, socket, message);
            return;
          }
          try {
            perMessageDeflate.accept(extensions[PerMessageDeflate.extensionName]);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Extensions header";
            abortHandshake(websocket, socket, message);
            return;
          }
          websocket._extensions[PerMessageDeflate.extensionName] = perMessageDeflate;
        }
        websocket.setSocket(socket, head, {
          allowSynchronousEvents: opts.allowSynchronousEvents,
          generateMask: opts.generateMask,
          maxPayload: opts.maxPayload,
          skipUTF8Validation: opts.skipUTF8Validation
        });
      });
      if (opts.finishRequest) {
        opts.finishRequest(req, websocket);
      } else {
        req.end();
      }
    }
    function emitErrorAndClose(websocket, err) {
      websocket._readyState = WebSocket2.CLOSING;
      websocket._errorEmitted = true;
      websocket.emit("error", err);
      websocket.emitClose();
    }
    function netConnect(options) {
      options.path = options.socketPath;
      return net.connect(options);
    }
    function tlsConnect(options) {
      options.path = void 0;
      if (!options.servername && options.servername !== "") {
        options.servername = net.isIP(options.host) ? "" : options.host;
      }
      return tls.connect(options);
    }
    function abortHandshake(websocket, stream, message) {
      websocket._readyState = WebSocket2.CLOSING;
      const err = new Error(message);
      Error.captureStackTrace(err, abortHandshake);
      if (stream.setHeader) {
        stream[kAborted] = true;
        stream.abort();
        if (stream.socket && !stream.socket.destroyed) {
          stream.socket.destroy();
        }
        process.nextTick(emitErrorAndClose, websocket, err);
      } else {
        stream.destroy(err);
        stream.once("error", websocket.emit.bind(websocket, "error"));
        stream.once("close", websocket.emitClose.bind(websocket));
      }
    }
    function sendAfterClose(websocket, data, cb) {
      if (data) {
        const length = isBlob(data) ? data.size : toBuffer(data).length;
        if (websocket._socket) websocket._sender._bufferedBytes += length;
        else websocket._bufferedAmount += length;
      }
      if (cb) {
        const err = new Error(
          `WebSocket is not open: readyState ${websocket.readyState} (${readyStates[websocket.readyState]})`
        );
        process.nextTick(cb, err);
      }
    }
    function receiverOnConclude(code, reason) {
      const websocket = this[kWebSocket];
      websocket._closeFrameReceived = true;
      websocket._closeMessage = reason;
      websocket._closeCode = code;
      if (websocket._socket[kWebSocket] === void 0) return;
      websocket._socket.removeListener("data", socketOnData);
      process.nextTick(resume, websocket._socket);
      if (code === 1005) websocket.close();
      else websocket.close(code, reason);
    }
    function receiverOnDrain() {
      const websocket = this[kWebSocket];
      if (!websocket.isPaused) websocket._socket.resume();
    }
    function receiverOnError(err) {
      const websocket = this[kWebSocket];
      if (websocket._socket[kWebSocket] !== void 0) {
        websocket._socket.removeListener("data", socketOnData);
        process.nextTick(resume, websocket._socket);
        websocket.close(err[kStatusCode]);
      }
      if (!websocket._errorEmitted) {
        websocket._errorEmitted = true;
        websocket.emit("error", err);
      }
    }
    function receiverOnFinish() {
      this[kWebSocket].emitClose();
    }
    function receiverOnMessage(data, isBinary) {
      this[kWebSocket].emit("message", data, isBinary);
    }
    function receiverOnPing(data) {
      const websocket = this[kWebSocket];
      if (websocket._autoPong) websocket.pong(data, !this._isServer, NOOP);
      websocket.emit("ping", data);
    }
    function receiverOnPong(data) {
      this[kWebSocket].emit("pong", data);
    }
    function resume(stream) {
      stream.resume();
    }
    function senderOnError(err) {
      const websocket = this[kWebSocket];
      if (websocket.readyState === WebSocket2.CLOSED) return;
      if (websocket.readyState === WebSocket2.OPEN) {
        websocket._readyState = WebSocket2.CLOSING;
        setCloseTimer(websocket);
      }
      this._socket.end();
      if (!websocket._errorEmitted) {
        websocket._errorEmitted = true;
        websocket.emit("error", err);
      }
    }
    function setCloseTimer(websocket) {
      websocket._closeTimer = setTimeout(
        websocket._socket.destroy.bind(websocket._socket),
        closeTimeout
      );
    }
    function socketOnClose() {
      const websocket = this[kWebSocket];
      this.removeListener("close", socketOnClose);
      this.removeListener("data", socketOnData);
      this.removeListener("end", socketOnEnd);
      websocket._readyState = WebSocket2.CLOSING;
      let chunk;
      if (!this._readableState.endEmitted && !websocket._closeFrameReceived && !websocket._receiver._writableState.errorEmitted && (chunk = websocket._socket.read()) !== null) {
        websocket._receiver.write(chunk);
      }
      websocket._receiver.end();
      this[kWebSocket] = void 0;
      clearTimeout(websocket._closeTimer);
      if (websocket._receiver._writableState.finished || websocket._receiver._writableState.errorEmitted) {
        websocket.emitClose();
      } else {
        websocket._receiver.on("error", receiverOnFinish);
        websocket._receiver.on("finish", receiverOnFinish);
      }
    }
    function socketOnData(chunk) {
      if (!this[kWebSocket]._receiver.write(chunk)) {
        this.pause();
      }
    }
    function socketOnEnd() {
      const websocket = this[kWebSocket];
      websocket._readyState = WebSocket2.CLOSING;
      websocket._receiver.end();
      this.end();
    }
    function socketOnError() {
      const websocket = this[kWebSocket];
      this.removeListener("error", socketOnError);
      this.on("error", NOOP);
      if (websocket) {
        websocket._readyState = WebSocket2.CLOSING;
        this.destroy();
      }
    }
  }
});

// node_modules/ws/lib/stream.js
var require_stream = __commonJS({
  "node_modules/ws/lib/stream.js"(exports2, module2) {
    "use strict";
    var { Duplex } = require("stream");
    function emitClose(stream) {
      stream.emit("close");
    }
    function duplexOnEnd() {
      if (!this.destroyed && this._writableState.finished) {
        this.destroy();
      }
    }
    function duplexOnError(err) {
      this.removeListener("error", duplexOnError);
      this.destroy();
      if (this.listenerCount("error") === 0) {
        this.emit("error", err);
      }
    }
    function createWebSocketStream(ws2, options) {
      let terminateOnDestroy = true;
      const duplex = new Duplex({
        ...options,
        autoDestroy: false,
        emitClose: false,
        objectMode: false,
        writableObjectMode: false
      });
      ws2.on("message", function message(msg, isBinary) {
        const data = !isBinary && duplex._readableState.objectMode ? msg.toString() : msg;
        if (!duplex.push(data)) ws2.pause();
      });
      ws2.once("error", function error(err) {
        if (duplex.destroyed) return;
        terminateOnDestroy = false;
        duplex.destroy(err);
      });
      ws2.once("close", function close() {
        if (duplex.destroyed) return;
        duplex.push(null);
      });
      duplex._destroy = function(err, callback) {
        if (ws2.readyState === ws2.CLOSED) {
          callback(err);
          process.nextTick(emitClose, duplex);
          return;
        }
        let called = false;
        ws2.once("error", function error(err2) {
          called = true;
          callback(err2);
        });
        ws2.once("close", function close() {
          if (!called) callback(err);
          process.nextTick(emitClose, duplex);
        });
        if (terminateOnDestroy) ws2.terminate();
      };
      duplex._final = function(callback) {
        if (ws2.readyState === ws2.CONNECTING) {
          ws2.once("open", function open() {
            duplex._final(callback);
          });
          return;
        }
        if (ws2._socket === null) return;
        if (ws2._socket._writableState.finished) {
          callback();
          if (duplex._readableState.endEmitted) duplex.destroy();
        } else {
          ws2._socket.once("finish", function finish() {
            callback();
          });
          ws2.close();
        }
      };
      duplex._read = function() {
        if (ws2.isPaused) ws2.resume();
      };
      duplex._write = function(chunk, encoding, callback) {
        if (ws2.readyState === ws2.CONNECTING) {
          ws2.once("open", function open() {
            duplex._write(chunk, encoding, callback);
          });
          return;
        }
        ws2.send(chunk, callback);
      };
      duplex.on("end", duplexOnEnd);
      duplex.on("error", duplexOnError);
      return duplex;
    }
    module2.exports = createWebSocketStream;
  }
});

// node_modules/ws/lib/subprotocol.js
var require_subprotocol = __commonJS({
  "node_modules/ws/lib/subprotocol.js"(exports2, module2) {
    "use strict";
    var { tokenChars } = require_validation();
    function parse(header) {
      const protocols = /* @__PURE__ */ new Set();
      let start = -1;
      let end = -1;
      let i = 0;
      for (i; i < header.length; i++) {
        const code = header.charCodeAt(i);
        if (end === -1 && tokenChars[code] === 1) {
          if (start === -1) start = i;
        } else if (i !== 0 && (code === 32 || code === 9)) {
          if (end === -1 && start !== -1) end = i;
        } else if (code === 44) {
          if (start === -1) {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
          if (end === -1) end = i;
          const protocol2 = header.slice(start, end);
          if (protocols.has(protocol2)) {
            throw new SyntaxError(`The "${protocol2}" subprotocol is duplicated`);
          }
          protocols.add(protocol2);
          start = end = -1;
        } else {
          throw new SyntaxError(`Unexpected character at index ${i}`);
        }
      }
      if (start === -1 || end !== -1) {
        throw new SyntaxError("Unexpected end of input");
      }
      const protocol = header.slice(start, i);
      if (protocols.has(protocol)) {
        throw new SyntaxError(`The "${protocol}" subprotocol is duplicated`);
      }
      protocols.add(protocol);
      return protocols;
    }
    module2.exports = { parse };
  }
});

// node_modules/ws/lib/websocket-server.js
var require_websocket_server = __commonJS({
  "node_modules/ws/lib/websocket-server.js"(exports2, module2) {
    "use strict";
    var EventEmitter = require("events");
    var http = require("http");
    var { Duplex } = require("stream");
    var { createHash } = require("crypto");
    var extension = require_extension();
    var PerMessageDeflate = require_permessage_deflate();
    var subprotocol = require_subprotocol();
    var WebSocket2 = require_websocket();
    var { GUID, kWebSocket } = require_constants();
    var keyRegex = /^[+/0-9A-Za-z]{22}==$/;
    var RUNNING = 0;
    var CLOSING = 1;
    var CLOSED = 2;
    var WebSocketServer = class extends EventEmitter {
      /**
       * Create a `WebSocketServer` instance.
       *
       * @param {Object} options Configuration options
       * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {Boolean} [options.autoPong=true] Specifies whether or not to
       *     automatically send a pong in response to a ping
       * @param {Number} [options.backlog=511] The maximum length of the queue of
       *     pending connections
       * @param {Boolean} [options.clientTracking=true] Specifies whether or not to
       *     track clients
       * @param {Function} [options.handleProtocols] A hook to handle protocols
       * @param {String} [options.host] The hostname where to bind the server
       * @param {Number} [options.maxPayload=104857600] The maximum allowed message
       *     size
       * @param {Boolean} [options.noServer=false] Enable no server mode
       * @param {String} [options.path] Accept only connections matching this path
       * @param {(Boolean|Object)} [options.perMessageDeflate=false] Enable/disable
       *     permessage-deflate
       * @param {Number} [options.port] The port where to bind the server
       * @param {(http.Server|https.Server)} [options.server] A pre-created HTTP/S
       *     server to use
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       * @param {Function} [options.verifyClient] A hook to reject connections
       * @param {Function} [options.WebSocket=WebSocket] Specifies the `WebSocket`
       *     class to use. It must be the `WebSocket` class or class that extends it
       * @param {Function} [callback] A listener for the `listening` event
       */
      constructor(options, callback) {
        super();
        options = {
          allowSynchronousEvents: true,
          autoPong: true,
          maxPayload: 100 * 1024 * 1024,
          skipUTF8Validation: false,
          perMessageDeflate: false,
          handleProtocols: null,
          clientTracking: true,
          verifyClient: null,
          noServer: false,
          backlog: null,
          // use default (511 as implemented in net.js)
          server: null,
          host: null,
          path: null,
          port: null,
          WebSocket: WebSocket2,
          ...options
        };
        if (options.port == null && !options.server && !options.noServer || options.port != null && (options.server || options.noServer) || options.server && options.noServer) {
          throw new TypeError(
            'One and only one of the "port", "server", or "noServer" options must be specified'
          );
        }
        if (options.port != null) {
          this._server = http.createServer((req, res) => {
            const body = http.STATUS_CODES[426];
            res.writeHead(426, {
              "Content-Length": body.length,
              "Content-Type": "text/plain"
            });
            res.end(body);
          });
          this._server.listen(
            options.port,
            options.host,
            options.backlog,
            callback
          );
        } else if (options.server) {
          this._server = options.server;
        }
        if (this._server) {
          const emitConnection = this.emit.bind(this, "connection");
          this._removeListeners = addListeners(this._server, {
            listening: this.emit.bind(this, "listening"),
            error: this.emit.bind(this, "error"),
            upgrade: (req, socket, head) => {
              this.handleUpgrade(req, socket, head, emitConnection);
            }
          });
        }
        if (options.perMessageDeflate === true) options.perMessageDeflate = {};
        if (options.clientTracking) {
          this.clients = /* @__PURE__ */ new Set();
          this._shouldEmitClose = false;
        }
        this.options = options;
        this._state = RUNNING;
      }
      /**
       * Returns the bound address, the address family name, and port of the server
       * as reported by the operating system if listening on an IP socket.
       * If the server is listening on a pipe or UNIX domain socket, the name is
       * returned as a string.
       *
       * @return {(Object|String|null)} The address of the server
       * @public
       */
      address() {
        if (this.options.noServer) {
          throw new Error('The server is operating in "noServer" mode');
        }
        if (!this._server) return null;
        return this._server.address();
      }
      /**
       * Stop the server from accepting new connections and emit the `'close'` event
       * when all existing connections are closed.
       *
       * @param {Function} [cb] A one-time listener for the `'close'` event
       * @public
       */
      close(cb) {
        if (this._state === CLOSED) {
          if (cb) {
            this.once("close", () => {
              cb(new Error("The server is not running"));
            });
          }
          process.nextTick(emitClose, this);
          return;
        }
        if (cb) this.once("close", cb);
        if (this._state === CLOSING) return;
        this._state = CLOSING;
        if (this.options.noServer || this.options.server) {
          if (this._server) {
            this._removeListeners();
            this._removeListeners = this._server = null;
          }
          if (this.clients) {
            if (!this.clients.size) {
              process.nextTick(emitClose, this);
            } else {
              this._shouldEmitClose = true;
            }
          } else {
            process.nextTick(emitClose, this);
          }
        } else {
          const server = this._server;
          this._removeListeners();
          this._removeListeners = this._server = null;
          server.close(() => {
            emitClose(this);
          });
        }
      }
      /**
       * See if a given request should be handled by this server instance.
       *
       * @param {http.IncomingMessage} req Request object to inspect
       * @return {Boolean} `true` if the request is valid, else `false`
       * @public
       */
      shouldHandle(req) {
        if (this.options.path) {
          const index = req.url.indexOf("?");
          const pathname = index !== -1 ? req.url.slice(0, index) : req.url;
          if (pathname !== this.options.path) return false;
        }
        return true;
      }
      /**
       * Handle a HTTP Upgrade request.
       *
       * @param {http.IncomingMessage} req The request object
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @public
       */
      handleUpgrade(req, socket, head, cb) {
        socket.on("error", socketOnError);
        const key = req.headers["sec-websocket-key"];
        const upgrade = req.headers.upgrade;
        const version = +req.headers["sec-websocket-version"];
        if (req.method !== "GET") {
          const message = "Invalid HTTP method";
          abortHandshakeOrEmitwsClientError(this, req, socket, 405, message);
          return;
        }
        if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
          const message = "Invalid Upgrade header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (key === void 0 || !keyRegex.test(key)) {
          const message = "Missing or invalid Sec-WebSocket-Key header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (version !== 8 && version !== 13) {
          const message = "Missing or invalid Sec-WebSocket-Version header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (!this.shouldHandle(req)) {
          abortHandshake(socket, 400);
          return;
        }
        const secWebSocketProtocol = req.headers["sec-websocket-protocol"];
        let protocols = /* @__PURE__ */ new Set();
        if (secWebSocketProtocol !== void 0) {
          try {
            protocols = subprotocol.parse(secWebSocketProtocol);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Protocol header";
            abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
            return;
          }
        }
        const secWebSocketExtensions = req.headers["sec-websocket-extensions"];
        const extensions = {};
        if (this.options.perMessageDeflate && secWebSocketExtensions !== void 0) {
          const perMessageDeflate = new PerMessageDeflate(
            this.options.perMessageDeflate,
            true,
            this.options.maxPayload
          );
          try {
            const offers = extension.parse(secWebSocketExtensions);
            if (offers[PerMessageDeflate.extensionName]) {
              perMessageDeflate.accept(offers[PerMessageDeflate.extensionName]);
              extensions[PerMessageDeflate.extensionName] = perMessageDeflate;
            }
          } catch (err) {
            const message = "Invalid or unacceptable Sec-WebSocket-Extensions header";
            abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
            return;
          }
        }
        if (this.options.verifyClient) {
          const info = {
            origin: req.headers[`${version === 8 ? "sec-websocket-origin" : "origin"}`],
            secure: !!(req.socket.authorized || req.socket.encrypted),
            req
          };
          if (this.options.verifyClient.length === 2) {
            this.options.verifyClient(info, (verified, code, message, headers) => {
              if (!verified) {
                return abortHandshake(socket, code || 401, message, headers);
              }
              this.completeUpgrade(
                extensions,
                key,
                protocols,
                req,
                socket,
                head,
                cb
              );
            });
            return;
          }
          if (!this.options.verifyClient(info)) return abortHandshake(socket, 401);
        }
        this.completeUpgrade(extensions, key, protocols, req, socket, head, cb);
      }
      /**
       * Upgrade the connection to WebSocket.
       *
       * @param {Object} extensions The accepted extensions
       * @param {String} key The value of the `Sec-WebSocket-Key` header
       * @param {Set} protocols The subprotocols
       * @param {http.IncomingMessage} req The request object
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @throws {Error} If called more than once with the same socket
       * @private
       */
      completeUpgrade(extensions, key, protocols, req, socket, head, cb) {
        if (!socket.readable || !socket.writable) return socket.destroy();
        if (socket[kWebSocket]) {
          throw new Error(
            "server.handleUpgrade() was called more than once with the same socket, possibly due to a misconfiguration"
          );
        }
        if (this._state > RUNNING) return abortHandshake(socket, 503);
        const digest = createHash("sha1").update(key + GUID).digest("base64");
        const headers = [
          "HTTP/1.1 101 Switching Protocols",
          "Upgrade: websocket",
          "Connection: Upgrade",
          `Sec-WebSocket-Accept: ${digest}`
        ];
        const ws2 = new this.options.WebSocket(null, void 0, this.options);
        if (protocols.size) {
          const protocol = this.options.handleProtocols ? this.options.handleProtocols(protocols, req) : protocols.values().next().value;
          if (protocol) {
            headers.push(`Sec-WebSocket-Protocol: ${protocol}`);
            ws2._protocol = protocol;
          }
        }
        if (extensions[PerMessageDeflate.extensionName]) {
          const params = extensions[PerMessageDeflate.extensionName].params;
          const value = extension.format({
            [PerMessageDeflate.extensionName]: [params]
          });
          headers.push(`Sec-WebSocket-Extensions: ${value}`);
          ws2._extensions = extensions;
        }
        this.emit("headers", headers, req);
        socket.write(headers.concat("\r\n").join("\r\n"));
        socket.removeListener("error", socketOnError);
        ws2.setSocket(socket, head, {
          allowSynchronousEvents: this.options.allowSynchronousEvents,
          maxPayload: this.options.maxPayload,
          skipUTF8Validation: this.options.skipUTF8Validation
        });
        if (this.clients) {
          this.clients.add(ws2);
          ws2.on("close", () => {
            this.clients.delete(ws2);
            if (this._shouldEmitClose && !this.clients.size) {
              process.nextTick(emitClose, this);
            }
          });
        }
        cb(ws2, req);
      }
    };
    module2.exports = WebSocketServer;
    function addListeners(server, map) {
      for (const event of Object.keys(map)) server.on(event, map[event]);
      return function removeListeners() {
        for (const event of Object.keys(map)) {
          server.removeListener(event, map[event]);
        }
      };
    }
    function emitClose(server) {
      server._state = CLOSED;
      server.emit("close");
    }
    function socketOnError() {
      this.destroy();
    }
    function abortHandshake(socket, code, message, headers) {
      message = message || http.STATUS_CODES[code];
      headers = {
        Connection: "close",
        "Content-Type": "text/html",
        "Content-Length": Buffer.byteLength(message),
        ...headers
      };
      socket.once("finish", socket.destroy);
      socket.end(
        `HTTP/1.1 ${code} ${http.STATUS_CODES[code]}\r
` + Object.keys(headers).map((h) => `${h}: ${headers[h]}`).join("\r\n") + "\r\n\r\n" + message
      );
    }
    function abortHandshakeOrEmitwsClientError(server, req, socket, code, message) {
      if (server.listenerCount("wsClientError")) {
        const err = new Error(message);
        Error.captureStackTrace(err, abortHandshakeOrEmitwsClientError);
        server.emit("wsClientError", err, socket, req);
      } else {
        abortHandshake(socket, code, message);
      }
    }
  }
});

// node_modules/ws/index.js
var require_ws = __commonJS({
  "node_modules/ws/index.js"(exports2, module2) {
    "use strict";
    var WebSocket2 = require_websocket();
    WebSocket2.createWebSocketStream = require_stream();
    WebSocket2.Server = require_websocket_server();
    WebSocket2.Receiver = require_receiver();
    WebSocket2.Sender = require_sender();
    WebSocket2.WebSocket = WebSocket2;
    WebSocket2.WebSocketServer = WebSocket2.Server;
    module2.exports = WebSocket2;
  }
});

// node_modules/@resvg/resvg-wasm/index.js
var require_resvg_wasm = __commonJS({
  "node_modules/@resvg/resvg-wasm/index.js"(exports2, module2) {
    "use strict";
    var __defProp = Object.defineProperty;
    var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
    var __getOwnPropNames2 = Object.getOwnPropertyNames;
    var __hasOwnProp = Object.prototype.hasOwnProperty;
    var __export = (target, all) => {
      for (var name in all)
        __defProp(target, name, { get: all[name], enumerable: true });
    };
    var __copyProps = (to, from, except, desc) => {
      if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames2(from))
          if (!__hasOwnProp.call(to, key) && key !== except)
            __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
      }
      return to;
    };
    var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
    var wasm_binding_exports = {};
    __export(wasm_binding_exports, {
      Resvg: () => Resvg2,
      initWasm: () => initWasm
    });
    module2.exports = __toCommonJS(wasm_binding_exports);
    var wasm;
    var heap = new Array(128).fill(void 0);
    heap.push(void 0, null, true, false);
    var heap_next = heap.length;
    function addHeapObject(obj) {
      if (heap_next === heap.length)
        heap.push(heap.length + 1);
      const idx = heap_next;
      heap_next = heap[idx];
      heap[idx] = obj;
      return idx;
    }
    function getObject(idx) {
      return heap[idx];
    }
    function dropObject(idx) {
      if (idx < 132)
        return;
      heap[idx] = heap_next;
      heap_next = idx;
    }
    function takeObject(idx) {
      const ret = getObject(idx);
      dropObject(idx);
      return ret;
    }
    var WASM_VECTOR_LEN = 0;
    var cachedUint8Memory0 = null;
    function getUint8Memory0() {
      if (cachedUint8Memory0 === null || cachedUint8Memory0.byteLength === 0) {
        cachedUint8Memory0 = new Uint8Array(wasm.memory.buffer);
      }
      return cachedUint8Memory0;
    }
    var cachedTextEncoder = typeof TextEncoder !== "undefined" ? new TextEncoder("utf-8") : { encode: () => {
      throw Error("TextEncoder not available");
    } };
    var encodeString = typeof cachedTextEncoder.encodeInto === "function" ? function(arg, view) {
      return cachedTextEncoder.encodeInto(arg, view);
    } : function(arg, view) {
      const buf = cachedTextEncoder.encode(arg);
      view.set(buf);
      return {
        read: arg.length,
        written: buf.length
      };
    };
    function passStringToWasm0(arg, malloc, realloc) {
      if (realloc === void 0) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr2 = malloc(buf.length, 1) >>> 0;
        getUint8Memory0().subarray(ptr2, ptr2 + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr2;
      }
      let len = arg.length;
      let ptr = malloc(len, 1) >>> 0;
      const mem = getUint8Memory0();
      let offset = 0;
      for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 127)
          break;
        mem[ptr + offset] = code;
      }
      if (offset !== len) {
        if (offset !== 0) {
          arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8Memory0().subarray(ptr + offset, ptr + len);
        const ret = encodeString(arg, view);
        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
      }
      WASM_VECTOR_LEN = offset;
      return ptr;
    }
    function isLikeNone(x) {
      return x === void 0 || x === null;
    }
    var cachedInt32Memory0 = null;
    function getInt32Memory0() {
      if (cachedInt32Memory0 === null || cachedInt32Memory0.byteLength === 0) {
        cachedInt32Memory0 = new Int32Array(wasm.memory.buffer);
      }
      return cachedInt32Memory0;
    }
    var cachedTextDecoder = typeof TextDecoder !== "undefined" ? new TextDecoder("utf-8", { ignoreBOM: true, fatal: true }) : { decode: () => {
      throw Error("TextDecoder not available");
    } };
    if (typeof TextDecoder !== "undefined") {
      cachedTextDecoder.decode();
    }
    function getStringFromWasm0(ptr, len) {
      ptr = ptr >>> 0;
      return cachedTextDecoder.decode(getUint8Memory0().subarray(ptr, ptr + len));
    }
    function _assertClass(instance, klass) {
      if (!(instance instanceof klass)) {
        throw new Error(`expected instance of ${klass.name}`);
      }
      return instance.ptr;
    }
    function handleError(f, args2) {
      try {
        return f.apply(this, args2);
      } catch (e) {
        wasm.__wbindgen_exn_store(addHeapObject(e));
      }
    }
    var BBoxFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
    }, unregister: () => {
    } } : new FinalizationRegistry((ptr) => wasm.__wbg_bbox_free(ptr >>> 0));
    var BBox = class _BBox {
      static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(_BBox.prototype);
        obj.__wbg_ptr = ptr;
        BBoxFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
      }
      __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        BBoxFinalization.unregister(this);
        return ptr;
      }
      free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_bbox_free(ptr);
      }
      /**
      * @returns {number}
      */
      get x() {
        const ret = wasm.__wbg_get_bbox_x(this.__wbg_ptr);
        return ret;
      }
      /**
      * @param {number} arg0
      */
      set x(arg0) {
        wasm.__wbg_set_bbox_x(this.__wbg_ptr, arg0);
      }
      /**
      * @returns {number}
      */
      get y() {
        const ret = wasm.__wbg_get_bbox_y(this.__wbg_ptr);
        return ret;
      }
      /**
      * @param {number} arg0
      */
      set y(arg0) {
        wasm.__wbg_set_bbox_y(this.__wbg_ptr, arg0);
      }
      /**
      * @returns {number}
      */
      get width() {
        const ret = wasm.__wbg_get_bbox_width(this.__wbg_ptr);
        return ret;
      }
      /**
      * @param {number} arg0
      */
      set width(arg0) {
        wasm.__wbg_set_bbox_width(this.__wbg_ptr, arg0);
      }
      /**
      * @returns {number}
      */
      get height() {
        const ret = wasm.__wbg_get_bbox_height(this.__wbg_ptr);
        return ret;
      }
      /**
      * @param {number} arg0
      */
      set height(arg0) {
        wasm.__wbg_set_bbox_height(this.__wbg_ptr, arg0);
      }
    };
    var RenderedImageFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
    }, unregister: () => {
    } } : new FinalizationRegistry((ptr) => wasm.__wbg_renderedimage_free(ptr >>> 0));
    var RenderedImage = class _RenderedImage {
      static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(_RenderedImage.prototype);
        obj.__wbg_ptr = ptr;
        RenderedImageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
      }
      __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        RenderedImageFinalization.unregister(this);
        return ptr;
      }
      free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_renderedimage_free(ptr);
      }
      /**
      * Get the PNG width
      * @returns {number}
      */
      get width() {
        const ret = wasm.renderedimage_width(this.__wbg_ptr);
        return ret >>> 0;
      }
      /**
      * Get the PNG height
      * @returns {number}
      */
      get height() {
        const ret = wasm.renderedimage_height(this.__wbg_ptr);
        return ret >>> 0;
      }
      /**
      * Write the image data to Uint8Array
      * @returns {Uint8Array}
      */
      asPng() {
        try {
          const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
          wasm.renderedimage_asPng(retptr, this.__wbg_ptr);
          var r0 = getInt32Memory0()[retptr / 4 + 0];
          var r1 = getInt32Memory0()[retptr / 4 + 1];
          var r2 = getInt32Memory0()[retptr / 4 + 2];
          if (r2) {
            throw takeObject(r1);
          }
          return takeObject(r0);
        } finally {
          wasm.__wbindgen_add_to_stack_pointer(16);
        }
      }
      /**
      * Get the RGBA pixels of the image
      * @returns {Uint8Array}
      */
      get pixels() {
        const ret = wasm.renderedimage_pixels(this.__wbg_ptr);
        return takeObject(ret);
      }
    };
    var ResvgFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
    }, unregister: () => {
    } } : new FinalizationRegistry((ptr) => wasm.__wbg_resvg_free(ptr >>> 0));
    var Resvg = class {
      __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ResvgFinalization.unregister(this);
        return ptr;
      }
      free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_resvg_free(ptr);
      }
      /**
      * @param {Uint8Array | string} svg
      * @param {string | undefined} [options]
      * @param {Array<any> | undefined} [custom_font_buffers]
      */
      constructor(svg, options, custom_font_buffers) {
        try {
          const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
          var ptr0 = isLikeNone(options) ? 0 : passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
          var len0 = WASM_VECTOR_LEN;
          wasm.resvg_new(retptr, addHeapObject(svg), ptr0, len0, isLikeNone(custom_font_buffers) ? 0 : addHeapObject(custom_font_buffers));
          var r0 = getInt32Memory0()[retptr / 4 + 0];
          var r1 = getInt32Memory0()[retptr / 4 + 1];
          var r2 = getInt32Memory0()[retptr / 4 + 2];
          if (r2) {
            throw takeObject(r1);
          }
          this.__wbg_ptr = r0 >>> 0;
          return this;
        } finally {
          wasm.__wbindgen_add_to_stack_pointer(16);
        }
      }
      /**
      * Get the SVG width
      * @returns {number}
      */
      get width() {
        const ret = wasm.resvg_width(this.__wbg_ptr);
        return ret;
      }
      /**
      * Get the SVG height
      * @returns {number}
      */
      get height() {
        const ret = wasm.resvg_height(this.__wbg_ptr);
        return ret;
      }
      /**
      * Renders an SVG in Wasm
      * @returns {RenderedImage}
      */
      render() {
        try {
          const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
          wasm.resvg_render(retptr, this.__wbg_ptr);
          var r0 = getInt32Memory0()[retptr / 4 + 0];
          var r1 = getInt32Memory0()[retptr / 4 + 1];
          var r2 = getInt32Memory0()[retptr / 4 + 2];
          if (r2) {
            throw takeObject(r1);
          }
          return RenderedImage.__wrap(r0);
        } finally {
          wasm.__wbindgen_add_to_stack_pointer(16);
        }
      }
      /**
      * Output usvg-simplified SVG string
      * @returns {string}
      */
      toString() {
        let deferred1_0;
        let deferred1_1;
        try {
          const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
          wasm.resvg_toString(retptr, this.__wbg_ptr);
          var r0 = getInt32Memory0()[retptr / 4 + 0];
          var r1 = getInt32Memory0()[retptr / 4 + 1];
          deferred1_0 = r0;
          deferred1_1 = r1;
          return getStringFromWasm0(r0, r1);
        } finally {
          wasm.__wbindgen_add_to_stack_pointer(16);
          wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
      }
      /**
      * Calculate a maximum bounding box of all visible elements in this SVG.
      *
      * Note: path bounding box are approx values.
      * @returns {BBox | undefined}
      */
      innerBBox() {
        const ret = wasm.resvg_innerBBox(this.__wbg_ptr);
        return ret === 0 ? void 0 : BBox.__wrap(ret);
      }
      /**
      * Calculate a maximum bounding box of all visible elements in this SVG.
      * This will first apply transform.
      * Similar to `SVGGraphicsElement.getBBox()` DOM API.
      * @returns {BBox | undefined}
      */
      getBBox() {
        const ret = wasm.resvg_getBBox(this.__wbg_ptr);
        return ret === 0 ? void 0 : BBox.__wrap(ret);
      }
      /**
      * Use a given `BBox` to crop the svg. Currently this method simply changes
      * the viewbox/size of the svg and do not move the elements for simplicity
      * @param {BBox} bbox
      */
      cropByBBox(bbox) {
        _assertClass(bbox, BBox);
        wasm.resvg_cropByBBox(this.__wbg_ptr, bbox.__wbg_ptr);
      }
      /**
      * @returns {Array<any>}
      */
      imagesToResolve() {
        try {
          const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
          wasm.resvg_imagesToResolve(retptr, this.__wbg_ptr);
          var r0 = getInt32Memory0()[retptr / 4 + 0];
          var r1 = getInt32Memory0()[retptr / 4 + 1];
          var r2 = getInt32Memory0()[retptr / 4 + 2];
          if (r2) {
            throw takeObject(r1);
          }
          return takeObject(r0);
        } finally {
          wasm.__wbindgen_add_to_stack_pointer(16);
        }
      }
      /**
      * @param {string} href
      * @param {Uint8Array} buffer
      */
      resolveImage(href, buffer) {
        try {
          const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
          const ptr0 = passStringToWasm0(href, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
          const len0 = WASM_VECTOR_LEN;
          wasm.resvg_resolveImage(retptr, this.__wbg_ptr, ptr0, len0, addHeapObject(buffer));
          var r0 = getInt32Memory0()[retptr / 4 + 0];
          var r1 = getInt32Memory0()[retptr / 4 + 1];
          if (r1) {
            throw takeObject(r0);
          }
        } finally {
          wasm.__wbindgen_add_to_stack_pointer(16);
        }
      }
    };
    async function __wbg_load(module22, imports) {
      if (typeof Response === "function" && module22 instanceof Response) {
        if (typeof WebAssembly.instantiateStreaming === "function") {
          try {
            return await WebAssembly.instantiateStreaming(module22, imports);
          } catch (e) {
            if (module22.headers.get("Content-Type") != "application/wasm") {
              console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);
            } else {
              throw e;
            }
          }
        }
        const bytes = await module22.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);
      } else {
        const instance = await WebAssembly.instantiate(module22, imports);
        if (instance instanceof WebAssembly.Instance) {
          return { instance, module: module22 };
        } else {
          return instance;
        }
      }
    }
    function __wbg_get_imports() {
      const imports = {};
      imports.wbg = {};
      imports.wbg.__wbg_new_28c511d9baebfa89 = function(arg0, arg1) {
        const ret = new Error(getStringFromWasm0(arg0, arg1));
        return addHeapObject(ret);
      };
      imports.wbg.__wbindgen_memory = function() {
        const ret = wasm.memory;
        return addHeapObject(ret);
      };
      imports.wbg.__wbg_buffer_12d079cc21e14bdb = function(arg0) {
        const ret = getObject(arg0).buffer;
        return addHeapObject(ret);
      };
      imports.wbg.__wbg_newwithbyteoffsetandlength_aa4a17c33a06e5cb = function(arg0, arg1, arg2) {
        const ret = new Uint8Array(getObject(arg0), arg1 >>> 0, arg2 >>> 0);
        return addHeapObject(ret);
      };
      imports.wbg.__wbindgen_object_drop_ref = function(arg0) {
        takeObject(arg0);
      };
      imports.wbg.__wbg_new_63b92bc8671ed464 = function(arg0) {
        const ret = new Uint8Array(getObject(arg0));
        return addHeapObject(ret);
      };
      imports.wbg.__wbg_values_839f3396d5aac002 = function(arg0) {
        const ret = getObject(arg0).values();
        return addHeapObject(ret);
      };
      imports.wbg.__wbg_next_196c84450b364254 = function() {
        return handleError(function(arg0) {
          const ret = getObject(arg0).next();
          return addHeapObject(ret);
        }, arguments);
      };
      imports.wbg.__wbg_done_298b57d23c0fc80c = function(arg0) {
        const ret = getObject(arg0).done;
        return ret;
      };
      imports.wbg.__wbg_value_d93c65011f51a456 = function(arg0) {
        const ret = getObject(arg0).value;
        return addHeapObject(ret);
      };
      imports.wbg.__wbg_instanceof_Uint8Array_2b3bbecd033d19f6 = function(arg0) {
        let result;
        try {
          result = getObject(arg0) instanceof Uint8Array;
        } catch (_) {
          result = false;
        }
        const ret = result;
        return ret;
      };
      imports.wbg.__wbindgen_string_get = function(arg0, arg1) {
        const obj = getObject(arg1);
        const ret = typeof obj === "string" ? obj : void 0;
        var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        getInt32Memory0()[arg0 / 4 + 1] = len1;
        getInt32Memory0()[arg0 / 4 + 0] = ptr1;
      };
      imports.wbg.__wbg_new_16b304a2cfa7ff4a = function() {
        const ret = new Array();
        return addHeapObject(ret);
      };
      imports.wbg.__wbindgen_string_new = function(arg0, arg1) {
        const ret = getStringFromWasm0(arg0, arg1);
        return addHeapObject(ret);
      };
      imports.wbg.__wbg_push_a5b05aedc7234f9f = function(arg0, arg1) {
        const ret = getObject(arg0).push(getObject(arg1));
        return ret;
      };
      imports.wbg.__wbg_length_c20a40f15020d68a = function(arg0) {
        const ret = getObject(arg0).length;
        return ret;
      };
      imports.wbg.__wbg_set_a47bac70306a19a7 = function(arg0, arg1, arg2) {
        getObject(arg0).set(getObject(arg1), arg2 >>> 0);
      };
      imports.wbg.__wbindgen_throw = function(arg0, arg1) {
        throw new Error(getStringFromWasm0(arg0, arg1));
      };
      return imports;
    }
    function __wbg_init_memory(imports, maybe_memory) {
    }
    function __wbg_finalize_init(instance, module22) {
      wasm = instance.exports;
      __wbg_init.__wbindgen_wasm_module = module22;
      cachedInt32Memory0 = null;
      cachedUint8Memory0 = null;
      return wasm;
    }
    async function __wbg_init(input) {
      if (wasm !== void 0)
        return wasm;
      if (typeof input === "undefined") {
        input = new URL("index_bg.wasm", void 0);
      }
      const imports = __wbg_get_imports();
      if (typeof input === "string" || typeof Request === "function" && input instanceof Request || typeof URL === "function" && input instanceof URL) {
        input = fetch(input);
      }
      __wbg_init_memory(imports);
      const { instance, module: module22 } = await __wbg_load(await input, imports);
      return __wbg_finalize_init(instance, module22);
    }
    var dist_default = __wbg_init;
    var initialized = false;
    var initWasm = async (module_or_path) => {
      if (initialized) {
        throw new Error("Already initialized. The `initWasm()` function can be used only once.");
      }
      await dist_default(await module_or_path);
      initialized = true;
    };
    var Resvg2 = class extends Resvg {
      /**
       * @param {Uint8Array | string} svg
       * @param {ResvgRenderOptions | undefined} options
       */
      constructor(svg, options) {
        if (!initialized)
          throw new Error("Wasm has not been initialized. Call `initWasm()` function.");
        const font = options?.font;
        if (!!font && isCustomFontsOptions(font)) {
          const serializableOptions = {
            ...options,
            font: {
              ...font,
              fontBuffers: void 0
            }
          };
          super(svg, JSON.stringify(serializableOptions), font.fontBuffers);
        } else {
          super(svg, JSON.stringify(options));
        }
      }
    };
    function isCustomFontsOptions(value) {
      return Object.prototype.hasOwnProperty.call(value, "fontBuffers");
    }
  }
});

// src/raster.js
var require_raster = __commonJS({
  "src/raster.js"(exports2, module2) {
    "use strict";
    var fs2 = require("fs");
    var path2 = require("path");
    var { initWasm, Resvg } = require_resvg_wasm();
    var FONT = "Barlow Semi Condensed";
    var ready2 = null;
    var fonts = [];
    function init(assetDir) {
      if (!ready2) {
        fonts = fs2.readdirSync(assetDir).filter((f) => f.endsWith(".ttf")).map((f) => new Uint8Array(fs2.readFileSync(path2.join(assetDir, f))));
        ready2 = initWasm(fs2.readFileSync(path2.join(assetDir, "resvg.wasm")));
      }
      return ready2;
    }
    var opts = (width) => ({
      fitTo: { mode: "width", value: width },
      font: { fontBuffers: fonts, loadSystemFonts: false, defaultFontFamily: FONT },
      shapeRendering: 2,
      textRendering: 1
    });
    function toPng(svg, width = 144) {
      const r = new Resvg(svg, opts(width));
      const img = r.render();
      const png = Buffer.from(img.asPng());
      if (img.free) img.free();
      if (r.free) r.free();
      return png;
    }
    var toDataUrl = (svg, width = 144) => `data:image/png;base64,${toPng(svg, width).toString("base64")}`;
    var widthCache = /* @__PURE__ */ new Map();
    function textWidth(text, size, weight = 600) {
      const k = `${weight}|${size}|${text}`;
      if (widthCache.has(k)) return widthCache.get(k);
      let w = 0;
      if (String(text).trim()) {
        const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="4000" height="200"><text x="0" y="150" font-family="${FONT}" font-size="${size}" font-weight="${weight}">${esc(text)}</text></svg>`;
        try {
          const r = new Resvg(svg, opts(4e3));
          const box = r.getBBox();
          w = box ? box.width : 0;
          if (box && box.free) box.free();
          if (r.free) r.free();
        } catch (_) {
          w = String(text).length * size * 0.5;
        }
      } else {
        w = String(text).length * size * 0.22;
      }
      if (widthCache.size > 4e3) widthCache.clear();
      widthCache.set(k, w);
      return w;
    }
    function esc(s) {
      return String(s).replace(/[\u0000-\u001f\u007f]/g, " ").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    }
    module2.exports = { init, toPng, toDataUrl, textWidth, esc, FONT };
  }
});

// src/render.js
var require_render = __commonJS({
  "src/render.js"(exports2, module2) {
    "use strict";
    var { textWidth, esc, FONT } = require_raster();
    var S2 = 144;
    var GAP = 28;
    var MIN_TEXT = 19;
    var BG = [14, 14, 18];
    var TEXT = [238, 238, 242];
    var MUTED = [150, 150, 162];
    var DIM = [96, 96, 108];
    var RED = [255, 104, 104];
    var GREEN = [95, 211, 141];
    var AMBER = [255, 180, 72];
    var rgb = (c) => `rgb(${c.map((v) => Math.round(v)).join(",")})`;
    var mix = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
    var f1 = (n) => Number(n).toFixed(1);
    var gradId = 0;
    function svgDoc(body, x0 = 0, defs = "") {
      return `<svg xmlns="http://www.w3.org/2000/svg" width="${S2}" height="${S2}" viewBox="${f1(x0)} 0 ${S2} ${S2}">` + (defs ? `<defs>${defs}</defs>` : "") + body + "</svg>";
    }
    function text(x, y, str, size, color, { weight = 600, anchor = "middle" } = {}) {
      return `<text x="${f1(x)}" y="${f1(y)}" font-family="${FONT}" font-size="${Math.max(MIN_TEXT, size)}" font-weight="${weight}" text-anchor="${anchor}" fill="${rgb(color)}">${esc(str)}</text>`;
    }
    function fitText(str, maxW, sizes = [22, 21, 20, 19], weight = 600, allowTwo = true) {
      str = String(str || "").trim();
      sizes = sizes.filter((s) => s >= MIN_TEXT);
      for (const size2 of sizes) if (textWidth(str, size2, weight) <= maxW) return { lines: [str], size: size2 };
      const words = str.split(/\s+/);
      if (allowTwo && words.length > 1) {
        for (const size2 of sizes) {
          let best = null;
          for (let i = 1; i < words.length; i++) {
            const a = words.slice(0, i).join(" ");
            const b = words.slice(i).join(" ");
            const w = Math.max(textWidth(a, size2, weight), textWidth(b, size2, weight));
            if (w <= maxW && (!best || w < best.w)) best = { lines: [a, b], w };
          }
          if (best) return { lines: best.lines, size: size2 };
        }
      }
      const size = sizes[sizes.length - 1];
      let cut = str;
      while (cut.length > 1 && textWidth(cut + "\u2026", size, weight) > maxW) cut = cut.slice(0, -1);
      return { lines: [cut.trimEnd() + "\u2026"], size };
    }
    function spreadWords(str, n, sizes = [44, 40, 36, 32, 28, 26, 24, 22], maxW = 124, weight = 600) {
      const words = String(str || "").trim().split(/\s+/).filter(Boolean);
      if (!words.length) return { size: sizes[0], keys: Array.from({ length: n }, () => []) };
      for (const perKey of [1, 2]) {
        for (const size2 of sizes) {
          if (perKey === 2 && size2 > 30) continue;
          const lines = [];
          let cur = "";
          let fail = false;
          for (const w of words) {
            if (textWidth(w, size2, weight) > maxW) {
              fail = true;
              break;
            }
            const tryLine = cur ? `${cur} ${w}` : w;
            if (textWidth(tryLine, size2, weight) <= maxW) cur = tryLine;
            else {
              lines.push(cur);
              cur = w;
            }
          }
          if (fail) continue;
          if (cur) lines.push(cur);
          if (lines.length > n * perKey) continue;
          const used = Math.ceil(lines.length / perKey);
          const offset = Math.floor((n - used) / 2);
          const keys3 = Array.from({ length: n }, () => []);
          lines.forEach((ln, i2) => keys3[offset + Math.floor(i2 / perKey)].push(ln));
          return { size: size2, keys: keys3 };
        }
      }
      const size = 22;
      const keys2 = Array.from({ length: n }, () => []);
      let i = 0;
      for (let k = 0; k < n && i < words.length; k++) {
        for (let line = 0; line < 2 && i < words.length; line++) {
          let cur = "";
          while (i < words.length) {
            const next = cur ? `${cur} ${words[i]}` : words[i];
            if (textWidth(next, size, weight) > maxW && cur) break;
            cur = next;
            i++;
          }
          keys2[k].push(cur);
        }
      }
      const last = keys2[n - 1];
      if (i < words.length || last.some((l) => textWidth(l, size, weight) > maxW)) {
        let s = last[last.length - 1] || "";
        while (s.length > 1 && textWidth(s + "\u2026", size, weight) > maxW) s = s.slice(0, -1);
        last[last.length - 1] = s + "\u2026";
        for (const k of keys2) for (let j = 0; j < k.length; j++) {
          while (k[j].length > 1 && textWidth(k[j], size, weight) > maxW) k[j] = k[j].slice(0, -2) + "\u2026";
        }
      }
      return { size, keys: keys2 };
    }
    function backdrop(W, { color, glow = 0, cx = W / 2, cy = 62, r = 80, style = "glow" } = {}) {
      let s = `<rect x="0" y="0" width="${f1(W)}" height="${S2}" fill="${rgb(BG)}"/>`;
      let defs = "";
      if (color && glow > 0 && style !== "flat") {
        const id = `g${++gradId}`;
        defs += `<radialGradient id="${id}" cx="${f1(cx)}" cy="${f1(cy)}" r="${f1(r)}" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="${rgb(color)}" stop-opacity="${(0.4 * glow).toFixed(3)}"/><stop offset="0.55" stop-color="${rgb(color)}" stop-opacity="${(0.13 * glow).toFixed(3)}"/><stop offset="1" stop-color="${rgb(color)}" stop-opacity="0"/></radialGradient>`;
        s += `<rect x="0" y="0" width="${f1(W)}" height="${S2}" fill="${rgb(color)}" fill-opacity="${(0.05 * glow).toFixed(3)}"/>`;
        s += `<circle cx="${f1(cx)}" cy="${f1(cy)}" r="${f1(r)}" fill="url(#${id})"/>`;
      } else if (color && glow > 0) {
        s += `<rect x="0" y="0" width="${f1(W)}" height="${S2}" fill="${rgb(color)}" fill-opacity="${(0.13 * glow).toFixed(3)}"/>`;
      }
      return { body: s, defs };
    }
    function ring(color, strong = true) {
      return `<rect x="6" y="6" width="132" height="132" rx="24" fill="none" stroke="${rgb(color)}" stroke-opacity="${strong ? 0.9 : 0.35}" stroke-width="${strong ? 3.5 : 2}"/>`;
    }
    function overlay(k) {
      if (k.failed) return ring(RED);
      if (k.pressed) return ring(k.color || AMBER);
      return "";
    }
    var SW = 0.16;
    function iconPower(cx, cy, r, col) {
      const p = (a) => [cx + r * Math.sin(a * Math.PI / 180), cy - r * Math.cos(a * Math.PI / 180)];
      const [x1, y1] = p(38), [x2, y2] = p(322);
      return `<path d="M${f1(x1)} ${f1(y1)} A${f1(r)} ${f1(r)} 0 1 1 ${f1(x2)} ${f1(y2)}" fill="none" stroke="${rgb(col)}" stroke-width="${f1(r * SW * 1.2)}" stroke-linecap="round"/><line x1="${f1(cx)}" y1="${f1(cy - r * 1.1)}" x2="${f1(cx)}" y2="${f1(cy - r * 0.2)}" stroke="${rgb(col)}" stroke-width="${f1(r * SW * 1.2)}" stroke-linecap="round"/>`;
    }
    function iconPlug(cx, cy, r, col, on) {
      let s = `<rect x="${f1(cx - r)}" y="${f1(cy - r)}" width="${f1(2 * r)}" height="${f1(2 * r)}" rx="${f1(r * 0.38)}" fill="${rgb(col)}" fill-opacity="${on ? 0.16 : 0}" stroke="${rgb(col)}" stroke-width="${f1(r * SW)}"/>`;
      const slot = (x1, y1, x2, y2) => `<line x1="${f1(x1)}" y1="${f1(y1)}" x2="${f1(x2)}" y2="${f1(y2)}" stroke="${rgb(col)}" stroke-width="${f1(r * 0.17)}" stroke-linecap="round"/>`;
      s += slot(cx - r * 0.24, cy - r * 0.46, cx - r * 0.5, cy - r * 0.02);
      s += slot(cx + r * 0.24, cy - r * 0.46, cx + r * 0.5, cy - r * 0.02);
      s += slot(cx, cy + r * 0.22, cx, cy + r * 0.56);
      return s;
    }
    function iconBulb(cx, cy, r, col, on, level = 1) {
      const sw = r * SW;
      const by = cy - r * 0.22;
      const br = r * 0.66;
      const nx = r * 0.32;
      const ny = cy + r * 0.42;
      const a = Math.asin(nx / br);
      const sx = cx - br * Math.sin(a), sy = by + br * Math.cos(a);
      const ex = cx + br * Math.sin(a);
      const d = `M${f1(sx)} ${f1(sy)} L${f1(cx - nx)} ${f1(ny)} L${f1(cx + nx)} ${f1(ny)} L${f1(ex)} ${f1(sy)} A${f1(br)} ${f1(br)} 0 1 0 ${f1(sx)} ${f1(sy)} Z`;
      let s = `<path d="${d}" fill="${rgb(col)}" fill-opacity="${on ? (0.25 + 0.45 * level).toFixed(2) : 0}" stroke="${rgb(col)}" stroke-width="${f1(sw)}" stroke-linejoin="round"/>`;
      s += `<line x1="${f1(cx - nx * 0.95)}" y1="${f1(ny + r * 0.26)}" x2="${f1(cx + nx * 0.95)}" y2="${f1(ny + r * 0.26)}" stroke="${rgb(col)}" stroke-width="${f1(sw)}" stroke-linecap="round"/>`;
      s += `<line x1="${f1(cx - nx * 0.6)}" y1="${f1(ny + r * 0.52)}" x2="${f1(cx + nx * 0.6)}" y2="${f1(ny + r * 0.52)}" stroke="${rgb(col)}" stroke-width="${f1(sw)}" stroke-linecap="round"/>`;
      return s;
    }
    function iconSwitch(cx, cy, r, col, on) {
      const sw = r * SW;
      let s = `<rect x="${f1(cx - r * 0.72)}" y="${f1(cy - r)}" width="${f1(r * 1.44)}" height="${f1(2 * r)}" rx="${f1(r * 0.28)}" fill="${rgb(col)}" fill-opacity="${on ? 0.12 : 0}" stroke="${rgb(col)}" stroke-width="${f1(sw)}"/>`;
      const w = r * 0.62, h = r * 1.2;
      s += `<rect x="${f1(cx - w / 2)}" y="${f1(cy - h / 2)}" width="${f1(w)}" height="${f1(h)}" rx="${f1(r * 0.14)}" fill="none" stroke="${rgb(col)}" stroke-width="${f1(sw * 0.8)}"/>`;
      const fy = on ? cy - h / 2 : cy;
      s += `<rect x="${f1(cx - w / 2)}" y="${f1(fy)}" width="${f1(w)}" height="${f1(h / 2)}" rx="${f1(r * 0.14)}" fill="${rgb(col)}"/>`;
      return s;
    }
    function iconFan(cx, cy, r, col, on) {
      let s = "";
      for (let i = 0; i < 3; i++) {
        s += `<ellipse cx="${f1(cx)}" cy="${f1(cy - r * 0.52)}" rx="${f1(r * 0.3)}" ry="${f1(r * 0.5)}" transform="rotate(${i * 120} ${f1(cx)} ${f1(cy)})" fill="${rgb(col)}" fill-opacity="${on ? 0.22 : 0}" stroke="${rgb(col)}" stroke-width="${f1(r * SW * 0.85)}"/>`;
      }
      s += `<circle cx="${f1(cx)}" cy="${f1(cy)}" r="${f1(r * 0.16)}" fill="${rgb(col)}"/>`;
      return s;
    }
    function iconBolt(cx, cy, r, col) {
      const p = [[0.12, -1], [-0.55, 0.12], [-0.02, 0.12], [-0.14, 1], [0.55, -0.16], [0.02, -0.16]];
      return `<polygon points="${p.map(([x, y]) => `${f1(cx + x * r)},${f1(cy + y * r)}`).join(" ")}" fill="${rgb(col)}" fill-opacity="0.18" stroke="${rgb(col)}" stroke-width="${f1(r * SW * 0.9)}" stroke-linejoin="round"/>`;
    }
    function iconHome(cx, cy, r, col) {
      const sw = r * SW;
      const pts = [[-0.95, -0.05], [0, -0.92], [0.95, -0.05]];
      let s = `<polyline points="${pts.map(([x, y]) => `${f1(cx + x * r)},${f1(cy + y * r)}`).join(" ")}" fill="none" stroke="${rgb(col)}" stroke-width="${f1(sw)}" stroke-linecap="round" stroke-linejoin="round"/>`;
      s += `<path d="M${f1(cx - r * 0.72)} ${f1(cy - r * 0.2)} L${f1(cx - r * 0.72)} ${f1(cy + r * 0.92)} L${f1(cx + r * 0.72)} ${f1(cy + r * 0.92)} L${f1(cx + r * 0.72)} ${f1(cy - r * 0.2)}" fill="none" stroke="${rgb(col)}" stroke-width="${f1(sw)}" stroke-linejoin="round"/>`;
      const wy = cy + r * 0.62;
      for (const k of [0.22, 0.48]) {
        const rr = r * k;
        s += `<path d="M${f1(cx - rr * 0.8)} ${f1(wy - rr * 0.6)} A${f1(rr)} ${f1(rr)} 0 0 1 ${f1(cx + rr * 0.8)} ${f1(wy - rr * 0.6)}" fill="none" stroke="${rgb(col)}" stroke-width="${f1(sw * 0.8)}" stroke-linecap="round"/>`;
      }
      s += `<circle cx="${f1(cx)}" cy="${f1(wy)}" r="${f1(r * 0.08)}" fill="${rgb(col)}"/>`;
      return s;
    }
    function icon(name, cx, cy, r, col, on, level) {
      switch (name) {
        case "plug":
          return iconPlug(cx, cy, r, col, on);
        case "bulb":
          return iconBulb(cx, cy, r, col, on, level);
        case "switch":
          return iconSwitch(cx, cy, r, col, on);
        case "fan":
          return iconFan(cx, cy, r, col, on);
        case "bolt":
          return iconBolt(cx, cy, r, col);
        case "home":
          return iconHome(cx, cy, r, col);
        default:
          return iconPower(cx, cy, r, col);
      }
    }
    function statusText(status) {
      switch (status) {
        case "offline":
          return { text: "Offline", color: RED };
        case "searching":
          return { text: "Looking\u2026", color: MUTED };
        case "connecting":
          return { text: "Connecting", color: MUTED };
        case "nokey":
          return { text: "No key", color: RED };
        default:
          return null;
      }
    }
    function formatWatts(w) {
      if (w === null || w === void 0 || !Number.isFinite(w)) return "\u2013";
      if (w >= 1e3) return (w / 1e3).toFixed(w >= 1e4 ? 1 : 2) + "k";
      if (w >= 100) return String(Math.round(w));
      return w.toFixed(1).replace(/\.0$/, "");
    }
    function labelLines(fit, bottom, color, weight = 600) {
      const lh = fit.size * 1.05;
      return fit.lines.map((ln, i) => text(72, bottom - (fit.lines.length - 1 - i) * lh, ln, fit.size, color, { weight })).join("");
    }
    function valueLayout({ label, value, sub, valueColor, labelColor = MUTED, subColor = MUTED, bar }) {
      let s = "";
      if (label) s += labelLines(fitText(label, 128, [22, 21, 20, 19], 600, false), 34, labelColor);
      const vf = fitText(value, 128, [54, 52, 50, 46, 42, 38], 700, false);
      s += text(72, label ? 94 : 84, vf.lines[0], vf.size, valueColor, { weight: 700 });
      if (bar) s += bar;
      else if (sub) s += labelLines(fitText(sub, 128, [22, 21, 20, 19], 600, false), label ? 128 : 120, subColor);
      return s;
    }
    function miniBar(pct, color) {
      const x = 22, w = 100, y = 112, h = 12;
      let s = `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${h / 2}" fill="rgb(46,46,56)"/>`;
      if (pct > 0) s += `<rect x="${x}" y="${y}" width="${f1(Math.max(h, w * pct / 100))}" height="${h}" rx="${h / 2}" fill="${rgb(color)}"/>`;
      return s;
    }
    function drawKey(k) {
      const col = k.color || AMBER;
      const st = statusText(k.status);
      const on = !!k.on && !st;
      const level = k.pct ? k.pct / 100 : 1;
      const iconCol = on ? col : st ? DIM : [140, 140, 152];
      let body = "";
      let defs = "";
      const bg = (glow, cy = 62) => {
        const b = backdrop(S2, { color: col, glow, cy, style: k.style });
        body += b.body;
        defs += b.defs;
      };
      switch (k.show) {
        case "button": {
          bg(on ? 0.45 + 0.55 * level : 0, 54);
          const label = st ? st.text : k.name || "";
          const fit = fitText(label, 128);
          const two = fit.lines.length > 1;
          body += icon(k.icon, 72, two ? 44 : 54, two ? 24 : 28, iconCol, on, level);
          body += labelLines(fit, 128, st ? st.color : on ? TEXT : MUTED);
          break;
        }
        case "icon": {
          bg(on ? 0.45 + 0.55 * level : 0, st ? 56 : 72);
          if (st) {
            body += icon(k.icon, 72, 54, 28, iconCol, on, level);
            body += labelLines(fitText(st.text, 128), 128, st.color);
          } else {
            body += icon(k.icon, 72, 72, 38, iconCol, on, level);
          }
          break;
        }
        case "state": {
          bg(on ? 0.6 : 0, 80);
          body += valueLayout({
            label: k.name,
            value: st ? "\u2013" : on ? "ON" : "OFF",
            valueColor: st ? DIM : on ? mix(col, TEXT, 0.25) : MUTED,
            sub: st ? st.text : null,
            subColor: st ? st.color : MUTED
          });
          break;
        }
        case "watts": {
          const active = !st && k.watts !== null && k.watts !== void 0 && k.watts > 0.5;
          bg(active ? 0.55 : 0, 80);
          body += valueLayout({
            label: k.name,
            value: st ? "\u2013" : formatWatts(k.watts),
            valueColor: active ? TEXT : MUTED,
            sub: st ? st.text : "watts",
            subColor: st ? st.color : active ? mix(col, TEXT, 0.4) : MUTED
          });
          break;
        }
        case "level": {
          const pct = on ? Math.round(k.pct || 0) : 0;
          bg(on ? 0.25 + 0.6 * level : 0, 80);
          body += valueLayout({
            label: k.name,
            value: st ? "\u2013" : on ? `${pct}%` : "Off",
            valueColor: on ? TEXT : MUTED,
            sub: st ? st.text : null,
            subColor: st ? st.color : MUTED,
            bar: st ? null : miniBar(pct, col)
          });
          break;
        }
        case "status": {
          const c = k.statusColor || MUTED;
          const b = backdrop(S2, { color: c, glow: k.statusGlow ? 0.5 : 0, cy: 50, style: k.style });
          body += b.body;
          defs += b.defs;
          body += icon("home", 72, 48, 26, c, true);
          const l1 = fitText(k.line1 || "", 128, [22, 21, 20, 19], 700, false);
          body += text(72, 106, l1.lines[0], l1.size, k.line1Color || TEXT, { weight: 700 });
          if (k.line2) {
            const l2 = fitText(k.line2, 128, [20, 19], 600, false);
            body += text(72, 130, l2.lines[0], l2.size, MUTED, { weight: 600 });
          }
          break;
        }
        case "devices": {
          bg(0);
          body += valueLayout({ label: "Devices", value: String(k.count ?? 0), valueColor: TEXT, sub: k.sub || "" });
          break;
        }
        case "message":
        default: {
          bg(0);
          body += icon("home", 72, 46, 24, DIM, false);
          const lines = (k.lines || []).slice(0, 2);
          if (lines[0]) body += labelLines(fitText(lines[0], 128, [22, 21, 20, 19], 700, false), 104, TEXT, 700);
          if (lines[1]) body += labelLines(fitText(lines[1], 128, [20, 19], 600, false), 128, MUTED);
          break;
        }
      }
      body += overlay({ ...k, color: k.show === "status" ? k.statusColor || MUTED : col });
      return svgDoc(body, 0, defs);
    }
    function drawNames(n, d) {
      const col = d.color || AMBER;
      const st = statusText(d.status);
      const on = !!d.on && !st;
      const spread = spreadWords(d.name || "", n);
      return spread.keys.map((lines, i) => {
        const b = backdrop(S2, { color: col, glow: on ? 0.35 : 0, cy: 72, r: 96, style: d.style });
        let body = b.body;
        const lh = spread.size * 1.05;
        let y = 72 + spread.size * 0.36 - (lines.length - 1) * lh / 2;
        for (const ln of lines) {
          body += text(72, y, ln, spread.size, on ? TEXT : st ? DIM : MUTED, { weight: 600 });
          y += lh;
        }
        body += overlay({ ...d.keys ? d.keys[i] : d, color: col });
        return svgDoc(body, 0, b.defs);
      });
    }
    function spanWidth(m) {
      return m * S2 + (m - 1) * GAP;
    }
    function drawSlider(m, d) {
      const col = d.color || AMBER;
      const st = statusText(d.status);
      const on = !!d.on && !st;
      const pct = on ? Math.max(0, Math.min(100, d.pct || 0)) : 0;
      const W = spanWidth(m);
      const b = backdrop(W, { color: col, glow: on ? 0.25 + 0.55 * (pct / 100) : 0, cx: W / 2, cy: 60, r: Math.max(100, W * 0.45), style: d.style });
      let shared = b.body;
      const x0 = 18, x1 = W - 18, y = 48, h = 26;
      shared += `<rect x="${x0}" y="${y}" width="${f1(x1 - x0)}" height="${h}" rx="${h / 2}" fill="rgb(46,46,56)"/>`;
      if (pct > 0) {
        const w = Math.max(h, (x1 - x0) * pct / 100);
        shared += `<rect x="${x0}" y="${y}" width="${f1(w)}" height="${h}" rx="${h / 2}" fill="${rgb(col)}"/>`;
        shared += `<rect x="${x0}" y="${y}" width="${f1(w)}" height="${h / 2}" rx="${h / 4}" fill="rgb(255,255,255)" fill-opacity="0.12"/>`;
      }
      const out = [];
      for (let i = 0; i < m; i++) {
        const kx = i * (S2 + GAP);
        const target = Math.round((i + 1) / m * 100);
        const active = on && Math.abs(pct - target) < 100 / m / 2 + 0.5;
        let own = "";
        const label = st ? i === 0 ? st.text : "" : `${target}%`;
        if (label) {
          const fit = fitText(label, 128, [26, 24, 22, 20], 700, false);
          own += text(kx + 72, 118, fit.lines[0], fit.size, st ? st.color : active ? mix(col, TEXT, 0.45) : MUTED, { weight: active ? 700 : 600 });
        }
        const k = d.keys && d.keys[i] || {};
        if (k.failed) own += `<g transform="translate(${kx} 0)">${ring(RED)}</g>`;
        else if (k.pressed) own += `<g transform="translate(${kx} 0)">${ring(col)}</g>`;
        out.push(svgDoc(shared + own, kx, b.defs));
      }
      return out;
    }
    function drawGraph(m, d) {
      const col = d.color || AMBER;
      const st = statusText(d.status);
      const W = spanWidth(m);
      const b = backdrop(W, { style: d.style });
      let shared = b.body;
      const gx0 = 12, gx1 = W - 12, gy0 = 44, gy1 = 126;
      const hist = (d.history || []).filter((p) => Number.isFinite(p.w));
      const now = d.now || Date.now();
      const span = 15e4 * m;
      const pts = hist.filter((p) => p.t >= now - span);
      const peak = Math.max(0, ...pts.map((p) => p.w));
      const max = Math.max(10, peak) * 1.12;
      shared += `<line x1="${gx0}" y1="${gy1}" x2="${f1(gx1)}" y2="${gy1}" stroke="rgb(52,52,62)" stroke-width="2"/>`;
      if (pts.length >= 2) {
        const X = (t) => gx0 + (t - (now - span)) / span * (gx1 - gx0);
        const Y = (v) => gy1 - v / max * (gy1 - gy0);
        const line = pts.map((p, i) => `${i ? "L" : "M"}${f1(X(p.t))} ${f1(Y(p.w))}`).join(" ");
        const area = `${line} L${f1(X(pts[pts.length - 1].t))} ${gy1} L${f1(X(pts[0].t))} ${gy1} Z`;
        shared += `<path d="${area}" fill="${rgb(col)}" fill-opacity="0.2"/>`;
        shared += `<path d="${line}" fill="none" stroke="${rgb(col)}" stroke-width="3.5" stroke-linejoin="round" stroke-linecap="round"/>`;
        const last = pts[pts.length - 1];
        shared += `<circle cx="${f1(X(last.t))}" cy="${f1(Y(last.w))}" r="5" fill="${rgb(col)}"/>`;
      }
      const out = [];
      for (let i = 0; i < m; i++) {
        const kx = i * (S2 + GAP);
        let own = "";
        if (i === 0) {
          const label = st ? st.text : pts.length >= 2 ? `Peak ${formatWatts(peak)} W` : "Graph starting";
          const fit = fitText(label, 124, [22, 21, 20, 19], 600, false);
          own += text(kx + 72, 30, fit.lines[0], fit.size, st ? st.color : MUTED);
        }
        const k = d.keys && d.keys[i] || {};
        if (k.failed) own += `<g transform="translate(${kx} 0)">${ring(RED)}</g>`;
        else if (k.pressed) own += `<g transform="translate(${kx} 0)">${ring(col)}</g>`;
        out.push(svgDoc(shared + own, kx, b.defs));
      }
      return out;
    }
    function actionIcon(kind) {
      const col = AMBER;
      const b = backdrop(S2, { color: col, glow: 0.8, cy: 72 });
      let body = b.body;
      if (kind === "switch") body += iconPower(72, 76, 34, col);
      else if (kind === "light") body += iconBulb(72, 74, 42, [255, 196, 110], true, 0.8);
      else if (kind === "brightness") {
        body += `<rect x="20" y="58" width="104" height="22" rx="11" fill="rgb(46,46,56)"/><rect x="20" y="58" width="68" height="22" rx="11" fill="${rgb(col)}"/>`;
        body += text(72, 118, "60%", 30, TEXT, { weight: 700 });
      } else if (kind === "power") {
        body += iconBolt(72, 62, 34, col);
        body += text(72, 126, "W", 30, TEXT, { weight: 700 });
      } else if (kind === "setup") {
        body += iconHome(72, 70, 40, col);
      } else {
        body += iconPlug(72, 72, 40, col, true);
      }
      return svgDoc(body, 0, b.defs);
    }
    module2.exports = {
      drawKey,
      drawNames,
      drawSlider,
      drawGraph,
      actionIcon,
      spreadWords,
      fitText,
      formatWatts,
      S: S2,
      GAP,
      MIN_TEXT,
      AMBER,
      GREEN,
      RED,
      MUTED,
      TEXT
    };
  }
});

// src/tuya/model.js
var require_model = __commonJS({
  "src/tuya/model.js"(exports2, module2) {
    "use strict";
    var LIGHT_CATS = /* @__PURE__ */ new Set(["dj", "dd", "fwd", "xdd", "dc", "tyndj", "gyd", "fsd", "sxd", "tgq", "tgkg"]);
    var PLUG_CATS = /* @__PURE__ */ new Set(["cz", "pc", "wkcz"]);
    var SWITCH_CATS = /* @__PURE__ */ new Set(["kg", "tdq", "qjdcz", "dlq", "cjkg", "ckmkzq", "kgq"]);
    var FAN_CATS = /* @__PURE__ */ new Set(["fs", "fsd", "fskg"]);
    var SWITCH_CODE = /^(switch|switch_\d+|switch_led|switch_led_\d+|led_switch|switch_usb\d*)$/;
    function num(v, d) {
      const n = Number(v);
      return Number.isFinite(n) ? n : d;
    }
    function describe(raw, spec) {
      const category = raw.category || "";
      const s = spec && Object.keys(spec).length ? spec : guessSpec(category, raw);
      const byCode = {};
      for (const [dp, item] of Object.entries(s)) if (item && item.code) byCode[item.code] = { dp, ...item };
      const switches = [];
      for (const [dp, item] of Object.entries(s)) {
        if (!item || !SWITCH_CODE.test(item.code || "")) continue;
        if (String(item.type).toLowerCase() !== "boolean" && item.type) continue;
        switches.push({ dp, code: item.code, label: switchLabel(item.code) });
      }
      switches.sort((a, b) => order(a.code) - order(b.code) || Number(a.dp) - Number(b.dp));
      let light = null;
      const bright = byCode.bright_value_v2 || byCode.bright_value || byCode.bright_value_1;
      const colour = byCode.colour_data_v2 || byCode.colour_data;
      if (LIGHT_CATS.has(category) || bright || colour) {
        const sw = byCode.switch_led || byCode.switch_led_1 || byCode.switch_1 || byCode.switch || switches[0];
        const temp = byCode.temp_value_v2 || byCode.temp_value;
        const v2 = !!(byCode.bright_value_v2 || byCode.colour_data_v2);
        if (sw || bright) {
          light = {
            switchDp: sw ? sw.dp : null,
            modeDp: byCode.work_mode ? byCode.work_mode.dp : null,
            brightDp: bright ? bright.dp : null,
            brightMin: bright ? num(bright.values && bright.values.min, v2 ? 10 : 25) : 0,
            brightMax: bright ? num(bright.values && bright.values.max, v2 ? 1e3 : 255) : 0,
            tempDp: temp ? temp.dp : null,
            tempMin: temp ? num(temp.values && temp.values.min, 0) : 0,
            tempMax: temp ? num(temp.values && temp.values.max, v2 ? 1e3 : 255) : 0,
            colourDp: colour ? colour.dp : null,
            colourV2: colour ? colour.code === "colour_data_v2" : v2
          };
        }
      }
      let power = null;
      const p = byCode.cur_power || byCode.power || byCode.cur_power_1;
      if (p && /value|integer/i.test(p.type || "value")) {
        power = { dp: p.dp, scale: num(p.values && p.values.scale, 1), unit: p.values && p.values.unit || "W" };
      }
      let kind = "switch";
      if (light) kind = "light";
      else if (FAN_CATS.has(category)) kind = "fan";
      else if (PLUG_CATS.has(category)) kind = "plug";
      else if (SWITCH_CATS.has(category)) kind = "switch";
      else if (power) kind = "plug";
      return {
        id: raw.id,
        name: (raw.name || raw.product_name || "Device").trim(),
        key: raw.local_key || "",
        category,
        product: raw.product_name || "",
        model: raw.model || "",
        kind,
        switches: light && light.switchDp && !switches.some((x) => x.dp === light.switchDp) ? [{ dp: light.switchDp, code: "switch_led", label: "Light" }, ...switches] : switches.length ? switches : [{ dp: "1", code: "switch_1", label: "Power" }],
        light,
        power,
        cloudCodes: Object.fromEntries(Object.entries(s).map(([dp, it]) => [dp, it && it.code]).filter(([, c]) => c)),
        sub: !!raw.sub
      };
    }
    function order(code) {
      if (code === "switch_led" || code === "switch" || code === "switch_1") return 0;
      const m = /(\d+)$/.exec(code);
      if (/usb/.test(code)) return 100 + (m ? Number(m[1]) : 0);
      return m ? Number(m[1]) : 50;
    }
    function switchLabel(code) {
      if (code === "switch_led" || code === "led_switch") return "Light";
      if (code === "switch") return "Power";
      let m = /^switch_usb(\d*)$/.exec(code);
      if (m) return m[1] ? `USB ${m[1]}` : "USB";
      m = /^switch(?:_led)?_(\d+)$/.exec(code);
      if (m) return `Outlet ${m[1]}`;
      return code;
    }
    function guessSpec(category, raw) {
      if (LIGHT_CATS.has(category)) {
        return {
          20: { code: "switch_led", type: "Boolean" },
          21: { code: "work_mode", type: "Enum" },
          22: { code: "bright_value_v2", type: "Integer", values: { min: 10, max: 1e3 } },
          23: { code: "temp_value_v2", type: "Integer", values: { min: 0, max: 1e3 } },
          24: { code: "colour_data_v2", type: "Json" }
        };
      }
      const s = { 1: { code: "switch_1", type: "Boolean" } };
      if (PLUG_CATS.has(category)) s[19] = { code: "cur_power", type: "Integer", values: { scale: 1, unit: "W" } };
      for (const st of raw && raw.status || []) {
        const m = /^switch_(\d+)$/.exec(st.code || "");
        if (m && Number(m[1]) > 1 && Number(m[1]) < 10) s[m[1]] = { code: st.code, type: "Boolean" };
      }
      return s;
    }
    function hsvToRgb(h, s, v) {
      h = (h % 360 + 360) % 360;
      const c = v * s;
      const x = c * (1 - Math.abs(h / 60 % 2 - 1));
      const m = v - c;
      let r = 0, g = 0, b = 0;
      if (h < 60) [r, g, b] = [c, x, 0];
      else if (h < 120) [r, g, b] = [x, c, 0];
      else if (h < 180) [r, g, b] = [0, c, x];
      else if (h < 240) [r, g, b] = [0, x, c];
      else if (h < 300) [r, g, b] = [x, 0, c];
      else [r, g, b] = [c, 0, x];
      return [r + m, g + m, b + m].map((n) => Math.round(n * 255));
    }
    function parseColour(value, v2) {
      if (value === void 0 || value === null || value === "") return null;
      if (typeof value === "object") return { h: num(value.h, 0), s: num(value.s, 0) / (v2 ? 1e3 : 255), v: num(value.v, 0) / (v2 ? 1e3 : 255) };
      const str = String(value).trim();
      if (str[0] === "{") {
        try {
          return parseColour(JSON.parse(str), v2);
        } catch (_) {
          return null;
        }
      }
      if (/^[0-9a-f]{12}$/i.test(str)) {
        return { h: parseInt(str.slice(0, 4), 16), s: parseInt(str.slice(4, 8), 16) / 1e3, v: parseInt(str.slice(8, 12), 16) / 1e3 };
      }
      if (/^[0-9a-f]{14}$/i.test(str)) {
        return { h: parseInt(str.slice(7, 10), 16), s: parseInt(str.slice(10, 12), 16) / 255, v: parseInt(str.slice(12, 14), 16) / 255 };
      }
      return null;
    }
    function formatColour(hsv, v2) {
      const h = Math.round(Math.max(0, Math.min(360, hsv.h)));
      if (v2) {
        const s = Math.round(Math.max(0, Math.min(1, hsv.s)) * 1e3);
        const v = Math.round(Math.max(0, Math.min(1, hsv.v)) * 1e3);
        return [h, s, v].map((n) => n.toString(16).padStart(4, "0")).join("");
      }
      const rgb = hsvToRgb(h, hsv.s, hsv.v);
      return rgb.map((n) => n.toString(16).padStart(2, "0")).join("") + "0" + h.toString(16).padStart(3, "0") + Math.round(hsv.s * 255).toString(16).padStart(2, "0") + Math.round(hsv.v * 255).toString(16).padStart(2, "0");
    }
    var WARM = [255, 168, 82];
    var COOL = [214, 230, 255];
    function lightState(dev, dps) {
      const L = dev.light;
      if (!L) return null;
      const on = L.switchDp ? dps[L.switchDp] === true : true;
      const mode = L.modeDp ? String(dps[L.modeDp] || "white") : "white";
      let pct = null;
      let rgb = WARM;
      const colour = L.colourDp ? parseColour(dps[L.colourDp], L.colourV2) : null;
      if (mode === "colour" && colour) {
        pct = Math.round(colour.v * 100);
        rgb = hsvToRgb(colour.h, Math.max(0.35, colour.s), 1);
      } else {
        if (L.brightDp && dps[L.brightDp] !== void 0) {
          pct = Math.round((num(dps[L.brightDp], L.brightMax) - L.brightMin) / Math.max(1, L.brightMax - L.brightMin) * 99 + 1);
        }
        if (L.tempDp && dps[L.tempDp] !== void 0) {
          const t = Math.max(0, Math.min(1, (num(dps[L.tempDp], 0) - L.tempMin) / Math.max(1, L.tempMax - L.tempMin)));
          rgb = WARM.map((w, i) => Math.round(w + (COOL[i] - w) * t));
        }
      }
      if (pct !== null) pct = Math.max(1, Math.min(100, pct));
      return { on, pct, rgb, mode };
    }
    function brightnessDps(dev, dps, pct) {
      const L = dev.light;
      const out = {};
      if (!L) return out;
      pct = Math.max(1, Math.min(100, Math.round(pct)));
      const mode = L.modeDp ? String(dps[L.modeDp] || "white") : "white";
      const colour = L.colourDp ? parseColour(dps[L.colourDp], L.colourV2) : null;
      if (mode === "colour" && colour) {
        out[L.colourDp] = formatColour({ ...colour, v: pct / 100 }, L.colourV2);
      } else if (L.brightDp) {
        out[L.brightDp] = Math.round(L.brightMin + (pct - 1) / 99 * (L.brightMax - L.brightMin));
      }
      if (L.switchDp && dps[L.switchDp] !== true) out[L.switchDp] = true;
      return out;
    }
    function powerWatts(dev, dps) {
      if (!dev.power) return null;
      const v = dps[dev.power.dp];
      if (v === void 0 || v === null) return null;
      return num(v, 0) / Math.pow(10, dev.power.scale || 0);
    }
    function cloudStatusToDps(dev, list) {
      const codeToDp = {};
      for (const [dp, code] of Object.entries(dev.cloudCodes || {})) codeToDp[code] = dp;
      const out = {};
      for (const { code, value } of list || []) {
        const dp = codeToDp[code];
        if (!dp) continue;
        let v = value;
        if (dev.light && dp === dev.light.colourDp && typeof v === "string" && v.trim()[0] === "{") {
          const c = parseColour(v, true);
          if (c) v = formatColour(c, dev.light.colourV2);
        }
        out[dp] = v;
      }
      return out;
    }
    function dpsToCloudCommands(dev, dps) {
      const cmds = [];
      for (const [dp, value] of Object.entries(dps)) {
        const code = (dev.cloudCodes || {})[dp];
        if (!code) continue;
        let v = value;
        if (dev.light && dp === dev.light.colourDp) {
          const c = parseColour(v, dev.light.colourV2);
          if (c) v = { h: Math.round(c.h), s: Math.round(c.s * 1e3), v: Math.round(c.v * 1e3) };
        }
        cmds.push({ code, value: v });
      }
      return cmds;
    }
    module2.exports = {
      describe,
      lightState,
      brightnessDps,
      powerWatts,
      parseColour,
      formatColour,
      hsvToRgb,
      cloudStatusToDps,
      dpsToCloudCommands
    };
  }
});

// src/tuya/protocol.js
var require_protocol = __commonJS({
  "src/tuya/protocol.js"(exports2, module2) {
    "use strict";
    var crypto = require("crypto");
    var CMD = {
      SESS_KEY_NEG_START: 3,
      SESS_KEY_NEG_RESP: 4,
      SESS_KEY_NEG_FINISH: 5,
      CONTROL: 7,
      STATUS: 8,
      HEART_BEAT: 9,
      DP_QUERY: 10,
      CONTROL_NEW: 13,
      DP_QUERY_NEW: 16,
      UPDATEDPS: 18,
      BOARDCAST_LPV34: 35,
      REQ_DEVINFO: 37,
      LAN_EXT_STREAM: 64
    };
    var NO_HEADER = /* @__PURE__ */ new Set([
      CMD.DP_QUERY,
      CMD.DP_QUERY_NEW,
      CMD.UPDATEDPS,
      CMD.HEART_BEAT,
      CMD.SESS_KEY_NEG_START,
      CMD.SESS_KEY_NEG_RESP,
      CMD.SESS_KEY_NEG_FINISH,
      CMD.LAN_EXT_STREAM
    ]);
    var PREFIX_55AA = 21930;
    var SUFFIX_55AA = 43605;
    var PREFIX_6699 = 26265;
    var SUFFIX_6699 = 39270;
    var UDP_KEY = crypto.createHash("md5").update("yGAdlopoPVldABfn").digest();
    var versionHeader = (version) => Buffer.concat([Buffer.from(String(version)), Buffer.alloc(12)]);
    function ecbEncrypt(key, data, pad = true) {
      const c = crypto.createCipheriv("aes-128-ecb", key, null);
      c.setAutoPadding(pad);
      return Buffer.concat([c.update(data), c.final()]);
    }
    function ecbDecrypt(key, data) {
      const d = crypto.createDecipheriv("aes-128-ecb", key, null);
      d.setAutoPadding(false);
      const raw = Buffer.concat([d.update(data), d.final()]);
      const n = raw.length ? raw[raw.length - 1] : 0;
      return n >= 1 && n <= 16 && n <= raw.length ? raw.subarray(0, raw.length - n) : raw;
    }
    function gcmEncrypt(key, iv, plain, aad) {
      const c = crypto.createCipheriv("aes-128-gcm", key, iv);
      if (aad) c.setAAD(aad);
      const enc = Buffer.concat([c.update(plain), c.final()]);
      return { enc, tag: c.getAuthTag() };
    }
    function gcmDecrypt(key, iv, enc, aad, tag) {
      const d = crypto.createDecipheriv("aes-128-gcm", key, iv);
      if (aad) d.setAAD(aad);
      if (tag) {
        d.setAuthTag(tag);
        return Buffer.concat([d.update(enc), d.final()]);
      }
      return d.update(enc);
    }
    var hmacSha256 = (key, data) => crypto.createHmac("sha256", key).update(data).digest();
    var CRC_TABLE = (() => {
      const t = new Uint32Array(256);
      for (let n = 0; n < 256; n++) {
        let c = n;
        for (let k = 0; k < 8; k++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
        t[n] = c >>> 0;
      }
      return t;
    })();
    function crc32(buf) {
      let c = 4294967295;
      for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 255] ^ c >>> 8;
      return (c ^ 4294967295) >>> 0;
    }
    function packFrame(seq, cmd, payload, opts = {}) {
      if (opts.gcmKey) {
        const iv = opts.iv || crypto.randomBytes(12);
        const header2 = Buffer.alloc(18);
        header2.writeUInt32BE(PREFIX_6699, 0);
        header2.writeUInt16BE(0, 4);
        header2.writeUInt32BE(seq >>> 0, 6);
        header2.writeUInt32BE(cmd, 10);
        header2.writeUInt32BE(12 + payload.length + 16, 14);
        const { enc, tag } = gcmEncrypt(opts.gcmKey, iv, payload, header2.subarray(4));
        const tail2 = Buffer.alloc(4);
        tail2.writeUInt32BE(SUFFIX_6699, 0);
        return Buffer.concat([header2, iv, enc, tag, tail2]);
      }
      const endLen = opts.hmacKey ? 36 : 8;
      const header = Buffer.alloc(16);
      header.writeUInt32BE(PREFIX_55AA, 0);
      header.writeUInt32BE(seq >>> 0, 4);
      header.writeUInt32BE(cmd, 8);
      header.writeUInt32BE(payload.length + endLen, 12);
      const body = Buffer.concat([header, payload]);
      let check;
      if (opts.hmacKey) {
        check = hmacSha256(opts.hmacKey, body);
      } else {
        check = Buffer.alloc(4);
        check.writeUInt32BE(crc32(body), 0);
      }
      const tail = Buffer.alloc(4);
      tail.writeUInt32BE(SUFFIX_55AA, 0);
      return Buffer.concat([body, check, tail]);
    }
    function splitFrames(buf) {
      const frames = [];
      let off = 0;
      for (; ; ) {
        let p = -1;
        for (let i = off; i + 4 <= buf.length; i++) {
          const v = buf.readUInt32BE(i);
          if (v === PREFIX_55AA || v === PREFIX_6699) {
            p = i;
            break;
          }
        }
        if (p < 0) {
          return { frames, rest: buf.subarray(Math.max(off, buf.length - 3)) };
        }
        off = p;
        const prefix = buf.readUInt32BE(off);
        const headerLen = prefix === PREFIX_6699 ? 18 : 16;
        if (buf.length - off < headerLen) return { frames, rest: buf.subarray(off) };
        const len = buf.readUInt32BE(off + headerLen - 4);
        if (len > 1048576) {
          off += 4;
          continue;
        }
        const total = prefix === PREFIX_6699 ? headerLen + len + 4 : headerLen + len;
        if (buf.length - off < total) return { frames, rest: buf.subarray(off) };
        const raw = buf.subarray(off, off + total);
        const seq = prefix === PREFIX_6699 ? raw.readUInt32BE(6) : raw.readUInt32BE(4);
        const cmd = prefix === PREFIX_6699 ? raw.readUInt32BE(10) : raw.readUInt32BE(8);
        frames.push({ prefix, seq, cmd, raw: Buffer.from(raw) });
        off += total;
      }
    }
    function unpackFrame(frame, { key, hmac = false, withRetcode = true } = {}) {
      const raw = frame.raw;
      if (frame.prefix === PREFIX_6699) {
        const header = raw.subarray(0, 18);
        const iv = raw.subarray(18, 30);
        const tag = raw.subarray(raw.length - 20, raw.length - 4);
        const enc = raw.subarray(30, raw.length - 20);
        let plain;
        let ok2 = true;
        try {
          plain = gcmDecrypt(key, iv, enc, header.subarray(4), tag);
        } catch (_) {
          ok2 = false;
          plain = Buffer.alloc(0);
        }
        let retcode2 = null;
        if (withRetcode && plain.length >= 4 && (plain.readUInt32BE(0) & 4294967040) === 0) {
          retcode2 = plain.readUInt32BE(0);
          plain = plain.subarray(4);
        }
        return { seq: frame.seq, cmd: frame.cmd, retcode: retcode2, payload: plain, ok: ok2 };
      }
      const endLen = hmac ? 36 : 8;
      const body = raw.subarray(0, raw.length - endLen);
      const check = raw.subarray(raw.length - endLen, raw.length - 4);
      let ok;
      if (hmac) ok = key ? hmacSha256(key, body).equals(check) : false;
      else ok = crc32(body) === check.readUInt32BE(0);
      let payload = raw.subarray(16, raw.length - endLen);
      let retcode = null;
      if (withRetcode && payload.length >= 4 && (payload.readUInt32BE(0) & 4294967040) === 0) {
        retcode = payload.readUInt32BE(0);
        payload = payload.subarray(4);
      }
      return { seq: frame.seq, cmd: frame.cmd, retcode, payload: Buffer.from(payload), ok };
    }
    function decodeBroadcast(msg) {
      let text = null;
      try {
        if (msg.length >= 4 && (msg.readUInt32BE(0) === PREFIX_55AA || msg.readUInt32BE(0) === PREFIX_6699)) {
          const { frames } = splitFrames(msg);
          if (!frames.length) return null;
          const f = frames[0];
          if (f.prefix === PREFIX_6699) {
            text = unpackFrame(f, { key: UDP_KEY, withRetcode: true }).payload.toString("utf8");
          } else {
            const p = unpackFrame(f, { withRetcode: true }).payload;
            if (p[0] === 123) text = p.toString("utf8");
            else text = ecbDecrypt(UDP_KEY, p.subarray(0, p.length - p.length % 16)).toString("utf8");
          }
        } else {
          text = ecbDecrypt(UDP_KEY, msg.subarray(0, msg.length - msg.length % 16)).toString("utf8");
        }
      } catch (_) {
        return null;
      }
      const a = text.indexOf("{");
      const b = text.lastIndexOf("}");
      if (a < 0 || b < a) return null;
      try {
        return JSON.parse(text.slice(a, b + 1));
      } catch (_) {
        return null;
      }
    }
    function discoveryRequest(localIp) {
      const body = Buffer.from(JSON.stringify({ from: "app", ip: localIp }));
      return packFrame(0, CMD.REQ_DEVINFO, body, { gcmKey: UDP_KEY });
    }
    module2.exports = {
      CMD,
      NO_HEADER,
      PREFIX_55AA,
      PREFIX_6699,
      UDP_KEY,
      versionHeader,
      ecbEncrypt,
      ecbDecrypt,
      gcmEncrypt,
      gcmDecrypt,
      hmacSha256,
      crc32,
      packFrame,
      splitFrames,
      unpackFrame,
      decodeBroadcast,
      discoveryRequest
    };
  }
});

// src/tuya/device.js
var require_device = __commonJS({
  "src/tuya/device.js"(exports2, module2) {
    "use strict";
    var net = require("net");
    var crypto = require("crypto");
    var { EventEmitter } = require("events");
    var P = require_protocol();
    var PORT2 = 6668;
    var HEARTBEAT_MS = 1e4;
    var DEAD_MS = 32e3;
    var VERSIONS = ["3.3", "3.4", "3.5"];
    var TuyaDevice = class extends EventEmitter {
      /**
       * @param {object} o
       *   id, key (local key, 16 chars), ip, version ('3.3'|'3.4'|'3.5'|'' for auto)
       *   log(fn), port
       */
      constructor(o) {
        super();
        this.id = o.id;
        this.localKey = Buffer.from(String(o.key || ""), "latin1");
        this.ip = o.ip || "";
        this.port = o.port || PORT2;
        this.version = VERSIONS.includes(String(o.version)) ? String(o.version) : "";
        this.tryIndex = 0;
        this.log = o.log || (() => {
        });
        this.devType = String(o.id || "").length === 22 ? "device22" : "default";
        this.dps = {};
        this.state = "idle";
        this.wanted = false;
        this.socket = null;
        this.buffer = Buffer.alloc(0);
        this.seq = 1;
        this.sessionKey = null;
        this.timers = {};
        this.backoff = 2e3;
        this.failures = 0;
        this.pending = [];
        this.negotiation = null;
      }
      get usableVersion() {
        return this.version || VERSIONS[this.tryIndex % VERSIONS.length];
      }
      /** Change IP / version / key (e.g. after discovery or a cloud refresh). */
      update({ ip, version, key }) {
        let changed = false;
        if (ip && ip !== this.ip) {
          this.ip = ip;
          changed = true;
        }
        if (version && VERSIONS.includes(String(version)) && String(version) !== this.version) {
          this.version = String(version);
          changed = true;
        }
        if (key && key !== this.localKey.toString("latin1")) {
          this.localKey = Buffer.from(String(key), "latin1");
          changed = true;
        }
        if (changed && this.wanted) this.restart("details changed");
      }
      start() {
        this.wanted = true;
        if (this.state === "idle") this.connect();
      }
      stop() {
        this.wanted = false;
        this.teardown();
        this.setState("idle");
      }
      restart(why) {
        this.log(`[${this.id}] reconnecting (${why})`);
        this.teardown();
        this.setState("idle");
        if (this.wanted) this.connect();
      }
      setState(s) {
        if (this.state === s) return;
        this.state = s;
        this.emit("state", s);
      }
      // ------------------------------------------------------------ connection
      connect() {
        if (!this.ip || this.localKey.length !== 16) {
          this.setState("waiting");
          return;
        }
        this.teardown();
        this.setState("connecting");
        const version = this.usableVersion;
        this.sessionKey = null;
        this.buffer = Buffer.alloc(0);
        this.seq = 1;
        const sock = net.connect({ host: this.ip, port: this.port });
        this.socket = sock;
        sock.setNoDelay(true);
        sock.setTimeout(8e3);
        sock.on("connect", () => {
          sock.setTimeout(0);
          this.lastHeard = Date.now();
          if (version !== "3.3") this.negotiate();
          else if (this.version) this.onReady();
          else this.probe33();
        });
        sock.on("data", (chunk) => this.onData(chunk));
        sock.on("timeout", () => {
          this.log(`[${this.id}] connect timeout ${this.ip}`);
          sock.destroy();
        });
        sock.on("error", (e) => this.log(`[${this.id}] socket error: ${e.code || e.message}`));
        sock.on("close", () => {
          if (this.socket !== sock) return;
          this.socket = null;
          this.onLost();
        });
      }
      onLost() {
        const wasConnected = this.state === "connected";
        this.clearTimers();
        this.failPending();
        this.setState("idle");
        if (!this.wanted) return;
        if (wasConnected) {
          this.failures = 0;
          this.backoff = 1e3;
        } else {
          this.failures++;
          if (!this.version) this.tryIndex++;
          this.backoff = Math.min(this.backoff * 2, 3e4);
        }
        this.timers.retry = setTimeout(() => {
          if (this.wanted) this.connect();
        }, this.backoff);
      }
      teardown() {
        this.clearTimers();
        this.failPending();
        if (this.socket) {
          const s = this.socket;
          this.socket = null;
          try {
            s.destroy();
          } catch (_) {
          }
        }
      }
      clearTimers() {
        for (const t of Object.values(this.timers)) {
          clearTimeout(t);
          clearInterval(t);
        }
        this.timers = {};
      }
      failPending() {
        const list = this.pending;
        this.pending = [];
        for (const p of list) {
          clearTimeout(p.timer);
          p.resolve(false);
        }
      }
      // Version unknown and trying 3.3: a TCP connection proves nothing, so only
      // accept 3.3 once the device answers a status query we can decrypt.
      probe33() {
        this.probing = true;
        this.query();
        this.timers.probe = setTimeout(() => {
          this.log(`[${this.id}] no 3.3 reply, trying another version`);
          if (this.socket) this.socket.destroy();
        }, 4e3);
      }
      onReady() {
        this.probing = false;
        clearTimeout(this.timers.probe);
        this.failures = 0;
        this.backoff = 2e3;
        if (!this.version) {
          this.version = this.usableVersion;
          this.emit("version", this.version);
        }
        this.setState("connected");
        this.query();
        this.timers.heartbeat = setInterval(() => {
          if (Date.now() - this.lastHeard > DEAD_MS) {
            this.restart("no reply from device");
            return;
          }
          this.sendCommand(P.CMD.HEART_BEAT, { gwId: this.id, devId: this.id });
        }, HEARTBEAT_MS);
      }
      // ------------------------------------------------------------ session key (3.4 / 3.5)
      negotiate() {
        const nonce = crypto.randomBytes(16);
        this.negotiation = { nonce };
        this.writeRaw(P.CMD.SESS_KEY_NEG_START, nonce, this.localKey);
        this.timers.negotiate = setTimeout(() => {
          this.log(`[${this.id}] no answer to key negotiation (v${this.usableVersion})`);
          if (this.version) this.emit("authError", "no answer (wrong key?)");
          if (this.socket) this.socket.destroy();
        }, 5e3);
      }
      onNegotiationReply(frame) {
        const v = this.usableVersion;
        const { nonce } = this.negotiation;
        let body;
        if (v === "3.5") {
          const u = P.unpackFrame(frame, { key: this.localKey, withRetcode: false });
          if (!u.ok) return this.negotiationFailed("reply did not decrypt");
          body = u.payload;
        } else {
          const u = P.unpackFrame(frame, { key: this.localKey, hmac: true, withRetcode: false });
          if (!u.ok) return this.negotiationFailed("reply failed its check");
          const enc = u.payload.length % 16 === 4 ? u.payload.subarray(4) : u.payload;
          try {
            body = P.ecbDecrypt(this.localKey, enc);
          } catch (_) {
            return this.negotiationFailed("reply did not decrypt");
          }
        }
        const expect = P.hmacSha256(this.localKey, nonce);
        let remote = null;
        for (const off of [0, 4]) {
          if (body.length >= off + 48 && body.subarray(off + 16, off + 48).equals(expect)) {
            remote = body.subarray(off, off + 16);
            break;
          }
        }
        if (!remote) return this.negotiationFailed("wrong key or version");
        clearTimeout(this.timers.negotiate);
        const answer = P.hmacSha256(this.localKey, remote);
        this.writeRaw(P.CMD.SESS_KEY_NEG_FINISH, answer, this.localKey);
        const mixed = Buffer.alloc(16);
        for (let i = 0; i < 16; i++) mixed[i] = nonce[i] ^ remote[i];
        if (v === "3.5") this.sessionKey = P.gcmEncrypt(this.localKey, nonce.subarray(0, 12), mixed).enc;
        else this.sessionKey = P.ecbEncrypt(this.localKey, mixed, false);
        this.negotiation = null;
        this.onReady();
      }
      negotiationFailed(why) {
        this.log(`[${this.id}] key negotiation failed (v${this.usableVersion}): ${why}`);
        this.emit("authError", why);
        if (this.socket) this.socket.destroy();
      }
      // ------------------------------------------------------------ sending
      /** Encrypt + frame a message for the current protocol version. */
      writeRaw(cmd, payload, key) {
        if (!this.socket) return false;
        const v = this.usableVersion;
        let frame;
        if (v === "3.5") {
          frame = P.packFrame(this.seq++, cmd, payload, { gcmKey: key });
        } else if (v === "3.4") {
          frame = P.packFrame(this.seq++, cmd, P.ecbEncrypt(key, payload), { hmacKey: key });
        } else {
          frame = P.packFrame(this.seq++, cmd, payload);
        }
        try {
          this.socket.write(frame);
          return true;
        } catch (_) {
          return false;
        }
      }
      /** Send a JSON command, adding the version header and encryption. */
      sendCommand(cmd, json) {
        const v = this.usableVersion;
        let payload = Buffer.from(JSON.stringify(json), "utf8");
        if (v === "3.3") {
          payload = P.ecbEncrypt(this.localKey, payload);
          if (!P.NO_HEADER.has(cmd)) payload = Buffer.concat([P.versionHeader(v), payload]);
          return this.writeRaw(cmd, payload);
        }
        if (!this.sessionKey) return false;
        if (!P.NO_HEADER.has(cmd)) payload = Buffer.concat([P.versionHeader(v), payload]);
        return this.writeRaw(cmd, payload, this.sessionKey);
      }
      query() {
        const v = this.usableVersion;
        const t = Math.floor(Date.now() / 1e3);
        if (v !== "3.3") return this.sendCommand(P.CMD.DP_QUERY_NEW, {});
        if (this.devType === "device22") {
          const dps = {};
          for (const k of Object.keys(this.dps).length ? Object.keys(this.dps) : ["1"]) dps[k] = null;
          return this.sendCommand(P.CMD.CONTROL_NEW, { devId: this.id, uid: this.id, t: String(t), dps });
        }
        return this.sendCommand(P.CMD.DP_QUERY, { gwId: this.id, devId: this.id, uid: this.id, t: String(t) });
      }
      /** Ask the device to report fresh values (e.g. power readings 18,19,20). */
      requestDps(dpIds) {
        if (this.state !== "connected" || !dpIds || !dpIds.length) return false;
        return this.sendCommand(P.CMD.UPDATEDPS, { dpId: dpIds.map(Number) });
      }
      /** Change data points, e.g. { "1": true }. Resolves true when the device accepts it. */
      set(dps) {
        return new Promise((resolve) => {
          if (this.state !== "connected") return resolve(false);
          const v = this.usableVersion;
          const t = Math.floor(Date.now() / 1e3);
          const ok = v === "3.3" ? this.sendCommand(P.CMD.CONTROL, { devId: this.id, uid: this.id, t: String(t), dps }) : this.sendCommand(P.CMD.CONTROL_NEW, { protocol: 5, t, data: { dps } });
          if (!ok) return resolve(false);
          const entry = { resolve, timer: null };
          entry.timer = setTimeout(() => {
            this.pending = this.pending.filter((p) => p !== entry);
            resolve(false);
          }, 4e3);
          this.pending.push(entry);
        });
      }
      settlePending(ok) {
        const p = this.pending.shift();
        if (p) {
          clearTimeout(p.timer);
          p.resolve(ok);
        }
      }
      // ------------------------------------------------------------ receiving
      onData(chunk) {
        this.lastHeard = Date.now();
        this.buffer = Buffer.concat([this.buffer, chunk]);
        const { frames, rest } = P.splitFrames(this.buffer);
        this.buffer = rest;
        for (const f of frames) {
          try {
            this.onFrame(f);
          } catch (e) {
            this.log(`[${this.id}] bad frame: ${e.stack || e}`);
          }
        }
      }
      onFrame(frame) {
        if (this.negotiation) {
          if (frame.cmd === P.CMD.SESS_KEY_NEG_RESP) this.onNegotiationReply(frame);
          return;
        }
        const v = this.usableVersion;
        let msg;
        if (v === "3.5") msg = P.unpackFrame(frame, { key: this.sessionKey });
        else if (v === "3.4") msg = P.unpackFrame(frame, { key: this.sessionKey, hmac: true });
        else msg = P.unpackFrame(frame, {});
        if (!msg.ok) {
          this.log(`[${this.id}] dropped a frame that failed its check (cmd ${frame.cmd})`);
          return;
        }
        if (frame.cmd === P.CMD.HEART_BEAT) return;
        const json = this.decodePayload(msg.payload);
        if (this.probing) {
          if (json && !json.__text) this.onReady();
          else return;
        }
        if (frame.cmd === P.CMD.CONTROL || frame.cmd === P.CMD.CONTROL_NEW) {
          this.settlePending(msg.retcode === 0 || msg.retcode === null);
        }
        if (!json) return;
        if (json.__text) {
          if (/data unvalid/i.test(json.__text) && v === "3.3" && this.devType !== "device22") {
            this.log(`[${this.id}] switching to device22 mode`);
            this.devType = "device22";
            this.query();
          }
          return;
        }
        const dps = json.dps || json.data && json.data.dps;
        if (dps && typeof dps === "object") {
          const changed = {};
          for (const [k, val] of Object.entries(dps)) {
            if (this.dps[k] !== val) changed[k] = val;
            this.dps[k] = val;
          }
          if (frame.cmd === P.CMD.STATUS) this.settlePending(true);
          this.emit("dps", changed, this.dps);
        }
      }
      decodePayload(payload) {
        if (!payload || !payload.length) return null;
        const v = this.usableVersion;
        let data = payload;
        if (v === "3.4") {
          try {
            data = P.ecbDecrypt(this.sessionKey, data.subarray(0, data.length - data.length % 16));
          } catch (_) {
            return null;
          }
        }
        const vb = Buffer.from(v);
        if (data.length >= 15 && data.subarray(0, 3).equals(vb)) data = data.subarray(15);
        if (v === "3.3" && data[0] !== 123) {
          const printable = /^[\x20-\x7e]+$/.test(data.toString("latin1"));
          if (data.length % 16 === 0 || !printable) {
            try {
              data = P.ecbDecrypt(this.localKey, data.subarray(0, data.length - data.length % 16));
            } catch (_) {
              return null;
            }
          }
        }
        const text = data.toString("utf8");
        const a = text.indexOf("{");
        const b = text.lastIndexOf("}");
        if (a >= 0 && b > a) {
          try {
            return JSON.parse(text.slice(a, b + 1));
          } catch (_) {
          }
        }
        return { __text: text.replace(/[^\x20-\x7e]/g, "") };
      }
    };
    module2.exports = { TuyaDevice, VERSIONS };
  }
});

// src/tuya/cloud.js
var require_cloud = __commonJS({
  "src/tuya/cloud.js"(exports2, module2) {
    "use strict";
    var https = require("https");
    var http = require("http");
    var crypto = require("crypto");
    var REGIONS2 = {
      eu: { name: "Central Europe", host: "https://openapi.tuyaeu.com" },
      weu: { name: "Western Europe", host: "https://openapi-weaz.tuyaeu.com" },
      us: { name: "Western America", host: "https://openapi.tuyaus.com" },
      ueaz: { name: "Eastern America", host: "https://openapi-ueaz.tuyaus.com" },
      sg: { name: "Singapore", host: "https://openapi-sg.iotbing.com" },
      in: { name: "India", host: "https://openapi.tuyain.com" },
      cn: { name: "China", host: "https://openapi.tuyacn.com" }
    };
    var AUTO_ORDER = ["eu", "weu", "us", "ueaz", "sg", "in", "cn"];
    var sha256hex = (s) => crypto.createHash("sha256").update(s, "utf8").digest("hex");
    var CloudError = class extends Error {
      constructor(message, code, kind) {
        super(message);
        this.code = code;
        this.kind = kind || "api";
      }
    };
    function explain(code, msg) {
      const c = Number(code);
      if (c === 1004 || c === 1005 || c === 2017) return { kind: "auth", text: "Access ID or Access Secret is wrong." };
      if (c === 1010 || c === 1011) return { kind: "auth", text: "Sign-in expired, trying again." };
      if (c === 28841002 || c === 28841101 || /expired/i.test(msg || "")) {
        return { kind: "expired", text: "Your free Tuya cloud trial has run out. Extend it at iot.tuya.com (Cloud > My Services > IoT Core)." };
      }
      if (c === 1106 || c === 28841105) return { kind: "permission", text: "No permission. Check the Smart Life app is linked to the project (Devices > Link Tuya App Account)." };
      if (c === 1114 || /invalid/i.test(msg || "") && /client/i.test(msg || "")) return { kind: "region", text: "Not found in this data centre." };
      return { kind: "api", text: msg ? `Tuya cloud: ${msg}` : `Tuya cloud error ${code}` };
    }
    var TuyaCloud = class _TuyaCloud {
      constructor({ accessId, accessSecret, region = "auto", log: log2 = () => {
      }, baseUrl = process.env.TUYA_CLOUD_BASE }) {
        this.accessId = String(accessId || "").trim();
        this.accessSecret = String(accessSecret || "").trim();
        this.region = region in REGIONS2 ? region : "auto";
        this.activeRegion = this.region === "auto" ? null : this.region;
        this.baseUrl = baseUrl && /^(https:\/\/|http:\/\/127\.0\.0\.1[:/])/.test(baseUrl) ? baseUrl : null;
        this.log = log2;
        this.token = null;
        this.tokenExpires = 0;
      }
      get host() {
        if (this.baseUrl) return this.baseUrl;
        return REGIONS2[this.activeRegion || "eu"].host;
      }
      sign(method, pathWithQuery, body, t, withToken) {
        const stringToSign = [method, sha256hex(body || ""), "", pathWithQuery].join("\n");
        const msg = this.accessId + (withToken ? this.token : "") + t + stringToSign;
        return crypto.createHmac("sha256", this.accessSecret).update(msg, "utf8").digest("hex").toUpperCase();
      }
      static buildPath(path2, query) {
        if (!query) return path2;
        const keys2 = Object.keys(query).filter((k) => query[k] !== void 0 && query[k] !== null && query[k] !== "").sort();
        if (!keys2.length) return path2;
        return path2 + "?" + keys2.map((k) => `${k}=${query[k]}`).join("&");
      }
      rawRequest(method, path2, query, bodyObj, withToken) {
        const full = _TuyaCloud.buildPath(path2, query);
        const body = bodyObj ? JSON.stringify(bodyObj) : "";
        const t = String(Date.now());
        const headers = {
          client_id: this.accessId,
          sign: this.sign(method, full, body, t, withToken),
          t,
          sign_method: "HMAC-SHA256",
          lang: "en"
        };
        if (withToken) headers.access_token = this.token;
        if (body) {
          headers["Content-Type"] = "application/json";
          headers["Content-Length"] = Buffer.byteLength(body);
        }
        const url = new URL(full, this.host);
        const lib = url.protocol === "http:" ? http : https;
        return new Promise((resolve, reject) => {
          const req = lib.request(url, { method, headers, timeout: 15e3 }, (res) => {
            let data = "";
            res.setEncoding("utf8");
            res.on("data", (d) => {
              data += d;
            });
            res.on("end", () => {
              let json;
              try {
                json = JSON.parse(data);
              } catch (_) {
                return reject(new CloudError(`Unexpected reply from Tuya (HTTP ${res.statusCode})`, res.statusCode, "network"));
              }
              resolve(json);
            });
          });
          req.on("timeout", () => req.destroy(new Error("timed out")));
          req.on("error", (e) => reject(new CloudError(`Can't reach the Tuya cloud (${e.code || e.message})`, 0, "network")));
          if (body) req.write(body);
          req.end();
        });
      }
      async getToken() {
        const res = await this.rawRequest("GET", "/v1.0/token", { grant_type: 1 }, null, false);
        if (!res.success) {
          const e = explain(res.code, res.msg);
          throw new CloudError(e.text, res.code, e.kind);
        }
        this.token = res.result.access_token;
        this.tokenExpires = Date.now() + (Number(res.result.expire_time || res.result.expire || 3600) - 120) * 1e3;
        this.uid = res.result.uid;
      }
      /** Sign in, trying each data centre in turn when set to Auto. */
      async connect() {
        if (!this.accessId || !this.accessSecret) throw new CloudError("Enter your Access ID and Access Secret.", 0, "auth");
        if (this.region !== "auto" || this.baseUrl) {
          await this.getToken();
          return this.activeRegion;
        }
        let lastErr = null;
        for (const r of this.activeRegion ? [this.activeRegion, ...AUTO_ORDER.filter((x) => x !== this.activeRegion)] : AUTO_ORDER) {
          this.activeRegion = r;
          try {
            await this.getToken();
            return r;
          } catch (e) {
            lastErr = e;
            if (e.kind === "network") throw e;
            this.log(`cloud: ${REGIONS2[r].name} said: ${e.message}`);
          }
        }
        throw lastErr || new CloudError("Could not sign in to the Tuya cloud.", 0, "auth");
      }
      async request(method, path2, query, body) {
        if (!this.token || Date.now() > this.tokenExpires) await this.connect();
        let res = await this.rawRequest(method, path2, query, body, true);
        if (!res.success && (res.code === 1010 || res.code === 1011)) {
          await this.connect();
          res = await this.rawRequest(method, path2, query, body, true);
        }
        if (!res.success) {
          const e = explain(res.code, res.msg);
          throw new CloudError(e.text, res.code, e.kind);
        }
        return res.result;
      }
      /** All devices of the linked app account(s), with local keys. */
      async listDevices() {
        const all = /* @__PURE__ */ new Map();
        const uids = /* @__PURE__ */ new Set();
        let rowKey = "";
        for (let page = 0; page < 20; page++) {
          const r = await this.request("GET", "/v1.0/iot-01/associated-users/devices", { size: 50, last_row_key: rowKey });
          for (const d of r && r.devices || []) {
            all.set(d.id, d);
            if (d.uid) uids.add(d.uid);
          }
          if (!r || !r.has_more || !r.last_row_key) break;
          rowKey = r.last_row_key;
        }
        if ([...all.values()].some((d) => !d.local_key)) {
          for (const uid of uids) {
            let key = "";
            for (let page = 0; page < 20; page++) {
              let r;
              try {
                r = await this.request("GET", "/v1.3/iot-03/devices", { page_size: 75, source_type: "tuyaUser", source_id: uid, last_row_key: key });
              } catch (e) {
                this.log("cloud: per-user device list failed: " + e.message);
                break;
              }
              for (const d of r && r.list || []) all.set(d.id, { ...all.get(d.id) || {}, ...d });
              if (!r || !r.has_more || !r.last_row_key) break;
              key = r.last_row_key;
            }
          }
        }
        for (const d of all.values()) {
          if (d.local_key) continue;
          try {
            const info = await this.request("GET", `/v1.0/devices/${d.id}`);
            if (info && info.local_key) d.local_key = info.local_key;
          } catch (e) {
            this.log(`cloud: no details for ${d.id}: ${e.message}`);
          }
        }
        return [...all.values()];
      }
      /** Data point list: [{dp_id, code, type, values}] */
      async specifications(id) {
        const r = await this.request("GET", `/v1.1/devices/${id}/specifications`);
        const out = /* @__PURE__ */ new Map();
        for (const item of [...r && r.status || [], ...r && r.functions || []]) {
          if (item.dp_id === void 0 || out.has(String(item.dp_id))) continue;
          let values = item.values;
          try {
            values = JSON.parse(item.values);
          } catch (_) {
          }
          out.set(String(item.dp_id), { code: item.code, type: item.type, values });
        }
        return Object.fromEntries(out);
      }
      async status(id) {
        return this.request("GET", `/v1.0/iot-03/devices/${id}/status`);
      }
      async command(id, commands) {
        return this.request("POST", `/v1.0/iot-03/devices/${id}/commands`, null, { commands });
      }
    };
    module2.exports = { TuyaCloud, CloudError, REGIONS: REGIONS2, AUTO_ORDER };
  }
});

// src/tuya/discovery.js
var require_discovery = __commonJS({
  "src/tuya/discovery.js"(exports2, module2) {
    "use strict";
    var dgram = require("dgram");
    var net = require("net");
    var os = require("os");
    var { EventEmitter } = require("events");
    var P = require_protocol();
    var Discovery = class extends EventEmitter {
      constructor({ log: log2 = () => {
      } } = {}) {
        super();
        this.log = log2;
        this.sockets = [];
        this.timer = null;
        this.started = 0;
        this.seen = /* @__PURE__ */ new Map();
      }
      start() {
        if (this.started) return;
        this.started = Date.now();
        for (const port of [6666, 6667, 7e3]) {
          const s = dgram.createSocket({ type: "udp4", reuseAddr: true });
          s.on("message", (msg, rinfo) => this.onMessage(msg, rinfo));
          s.on("error", (e) => {
            this.log(`discovery: can't listen on UDP ${port}: ${e.code || e.message}`);
            try {
              s.close();
            } catch (_) {
            }
          });
          try {
            s.bind(port, () => {
              try {
                s.setBroadcast(true);
              } catch (_) {
              }
            });
            this.sockets.push(s);
          } catch (e) {
            this.log(`discovery: bind ${port} failed: ${e.message}`);
          }
        }
        this.sendRequests();
        const tick = () => {
          this.sendRequests();
          const fast = Date.now() - this.started < 12e4;
          this.timer = setTimeout(tick, fast ? 6e3 : 6e4);
        };
        this.timer = setTimeout(tick, 6e3);
      }
      stop() {
        clearTimeout(this.timer);
        for (const s of this.sockets) {
          try {
            s.close();
          } catch (_) {
          }
        }
        this.sockets = [];
        this.started = 0;
      }
      onMessage(msg, rinfo) {
        const info = P.decodeBroadcast(msg);
        if (!info || info.from === "app") return;
        const id = info.gwId || info.devId || info.id;
        if (!id) return;
        const ip = info.ip || rinfo.address;
        const version = info.version ? String(info.version) : "";
        const prev = this.seen.get(id);
        this.seen.set(id, { ip, version, at: Date.now() });
        if (!prev || prev.ip !== ip || prev.version !== version) {
          this.log(`discovery: ${id} at ${ip} (v${version || "?"})`);
          this.emit("found", { id, ip, version });
        }
      }
      sendRequests() {
        const sock = this.sockets.find((s) => {
          try {
            return !!s.address();
          } catch (_) {
            return false;
          }
        });
        if (!sock) return;
        for (const iface of localNetworks()) {
          try {
            sock.send(P.discoveryRequest(iface.address), 7e3, iface.broadcast);
          } catch (_) {
          }
        }
      }
      /** Scan the local /24 networks for anything listening on TCP 6668. */
      async scan() {
        const hosts = process.env.TUYA_SCAN_HOSTS ? process.env.TUYA_SCAN_HOSTS.split(",").map((s) => s.trim()).filter(Boolean) : localNetworks().flatMap((n) => n.hosts);
        const open = [];
        const queue = hosts.slice();
        const worker = async () => {
          while (queue.length) {
            const h = queue.shift();
            if (await portOpen(h, 6668, 700)) open.push(h);
          }
        };
        await Promise.all(Array.from({ length: 48 }, worker));
        this.log(`discovery: network scan found port 6668 open on ${open.length ? open.join(", ") : "nothing"}`);
        return open;
      }
    };
    function portOpen(host, port, timeout) {
      return new Promise((resolve) => {
        const s = net.connect({ host, port });
        const done = (v) => {
          s.destroy();
          resolve(v);
        };
        s.setTimeout(timeout, () => done(false));
        s.on("connect", () => done(true));
        s.on("error", () => done(false));
      });
    }
    function localNetworks() {
      const out = [];
      for (const list of Object.values(os.networkInterfaces())) {
        for (const a of list || []) {
          if (a.family !== "IPv4" && a.family !== 4) continue;
          if (a.internal || a.address.startsWith("169.254.")) continue;
          const parts = a.address.split(".").map(Number);
          const mask = (a.netmask || "255.255.255.0").split(".").map(Number);
          const bcast = parts.map((p, i) => p | ~mask[i] & 255).join(".");
          const base = parts.slice(0, 3).join(".");
          const hosts = [];
          for (let i = 1; i < 255; i++) if (i !== parts[3]) hosts.push(`${base}.${i}`);
          out.push({ address: a.address, broadcast: bcast, hosts });
        }
      }
      return out;
    }
    module2.exports = { Discovery, localNetworks };
  }
});

// src/tuya/hub.js
var require_hub = __commonJS({
  "src/tuya/hub.js"(exports2, module2) {
    "use strict";
    var fs2 = require("fs");
    var path2 = require("path");
    var { EventEmitter } = require("events");
    var { TuyaDevice } = require_device();
    var { TuyaCloud, REGIONS: REGIONS2 } = require_cloud();
    var { Discovery } = require_discovery();
    var model2 = require_model();
    var CLOUD_POLL_MS = 2e4;
    var POWER_POLL_MS = 8e3;
    var HISTORY_MAX = 180;
    var Hub2 = class extends EventEmitter {
      constructor({ dir, log: log2 = () => {
      } }) {
        super();
        this.dir = dir;
        this.log = log2;
        this.cachePath = path2.join(dir, "devices.json");
        this.devices = /* @__PURE__ */ new Map();
        this.creds = { accessId: "", accessSecret: "", region: "auto" };
        this.cloud = null;
        this.account = { state: "none", message: "Not set up yet", region: null, refreshedAt: 0 };
        this.discovery = new Discovery({ log: log2 });
        this.discovery.on("found", (f) => this.onFound(f));
        this.wanted = /* @__PURE__ */ new Map();
        this.refreshing = null;
        this.lastAuthRefresh = 0;
        this.scanTimer = null;
        this.scanning = false;
        this.loadCache();
      }
      // ------------------------------------------------------------ cache
      loadCache() {
        try {
          const data = JSON.parse(fs2.readFileSync(this.cachePath, "utf8"));
          for (const d of data.devices || []) this.addEntry(d, { ip: d.ip, version: d.version });
          if (data.region) this.account.region = data.region;
          this.account.refreshedAt = data.refreshedAt || 0;
          this.log(`loaded ${this.devices.size} devices from devices.json`);
        } catch (_) {
        }
      }
      saveCache() {
        const devices = [...this.devices.values()].map((e) => ({ ...e.info, ip: e.ip || "", version: e.version || "" }));
        const data = { savedAt: Date.now(), refreshedAt: this.account.refreshedAt, region: this.account.region, devices };
        try {
          const tmp = this.cachePath + ".tmp";
          fs2.writeFileSync(tmp, JSON.stringify(data, null, 1));
          fs2.renameSync(tmp, this.cachePath);
        } catch (e) {
          this.log("could not save devices.json: " + e.message);
        }
      }
      addEntry(info, extra = {}) {
        let e = this.devices.get(info.id);
        if (!e) {
          e = { info, dps: {}, ip: "", version: "", conn: null, link: "offline", cloudOnline: null, history: [], lastCloudPoll: 0 };
          this.devices.set(info.id, e);
        }
        e.info = info;
        if (extra.ip) e.ip = extra.ip;
        if (extra.version) e.version = extra.version;
        if (extra.online !== void 0) e.cloudOnline = extra.online;
        if (e.conn) e.conn.update({ ip: e.ip, version: e.version, key: info.key });
        return e;
      }
      // ------------------------------------------------------------ account / cloud
      setCredentials(c) {
        const next = {
          accessId: String(c.accessId || "").trim(),
          accessSecret: String(c.accessSecret || "").trim(),
          region: c.region in REGIONS2 ? c.region : "auto"
        };
        const changed = JSON.stringify(next) !== JSON.stringify(this.creds);
        this.creds = next;
        if (!changed) return;
        this.cloud = next.accessId && next.accessSecret ? new TuyaCloud({ ...next, log: this.log }) : null;
        if (this.cloud && this.account.region && next.region === "auto") this.cloud.activeRegion = this.account.region;
        if (!this.cloud) {
          this.setAccount(this.devices.size ? "cached" : "none", this.devices.size ? "Using saved device list" : "Not set up yet");
          return;
        }
        this.refresh().catch(() => {
        });
      }
      setAccount(state, message, kind = "") {
        this.account.state = state;
        this.account.message = message;
        this.account.kind = kind;
        for (const e of this.devices.values()) this.updateLink(e);
        this.emit("account", this.account);
      }
      /** Fetch the device list (names, local keys, data points) from the cloud. */
      refresh() {
        if (this.refreshing) return this.refreshing;
        if (!this.cloud) {
          this.setAccount("none", "Enter your Access ID and Access Secret first.");
          return Promise.resolve(false);
        }
        this.setAccount("working", "Connecting to the Tuya cloud\u2026");
        this.refreshing = (async () => {
          try {
            const region = await this.cloud.connect();
            if (region) this.account.region = region;
            const list = await this.cloud.listDevices();
            const seen = /* @__PURE__ */ new Set();
            for (const raw of list) {
              if (raw.sub) continue;
              let spec = null;
              try {
                spec = await this.cloud.specifications(raw.id);
              } catch (e2) {
                this.log(`no data point list for ${raw.name}: ${e2.message}`);
              }
              const old = this.devices.get(raw.id);
              const info = model2.describe(raw, spec);
              if (!spec && old) info.cloudCodes = old.info.cloudCodes;
              this.addEntry(info, { online: raw.online });
              seen.add(raw.id);
              const e = this.devices.get(raw.id);
              if (!Object.keys(e.dps).length && Array.isArray(raw.status)) Object.assign(e.dps, model2.cloudStatusToDps(info, raw.status));
            }
            for (const id of [...this.devices.keys()]) {
              if (!seen.has(id)) {
                const e = this.devices.get(id);
                if (e.conn) e.conn.stop();
                this.devices.delete(id);
              }
            }
            this.account.refreshedAt = Date.now();
            this.saveCache();
            const n = this.devices.size;
            const where = REGIONS2[this.account.region] ? ` \xB7 ${REGIONS2[this.account.region].name}` : "";
            this.setAccount("ok", n ? `Found ${n} device${n === 1 ? "" : "s"}${where}` : `Signed in, but no devices found${where}. Link the Smart Life app to the project (Devices > Link Tuya App Account).`);
            this.log(`cloud refresh: ${n} devices`, [...this.devices.values()].map((x) => `${x.info.name} (${x.info.kind}, ${x.info.category})`));
            this.emit("devices");
            this.applyWanted();
            return true;
          } catch (e) {
            this.log("cloud refresh failed: " + (e.stack || e.message));
            const msg = this.devices.size ? `${e.message} Using saved device list.` : e.message;
            this.setAccount(e.kind === "expired" ? "expired" : "error", msg, e.kind || "api");
            return false;
          } finally {
            this.refreshing = null;
          }
        })();
        return this.refreshing;
      }
      // ------------------------------------------------------------ LAN
      onFound({ id, ip, version }) {
        const e = this.devices.get(id);
        if (!e) return;
        const changed = e.ip !== ip || version && e.version !== version;
        e.ip = ip;
        if (version) e.version = version;
        if (changed) this.saveCache();
        if (e.conn) e.conn.update({ ip, version });
        else if (this.wanted.has(id)) this.connect(e);
      }
      /** Tell the hub which devices are on keys (id -> {power}). */
      setWanted(map) {
        this.wanted = map;
        this.applyWanted();
      }
      applyWanted() {
        if (this.wanted.size) this.discovery.start();
        for (const [id, e] of this.devices) {
          if (this.wanted.has(id)) {
            if (!e.conn) this.connect(e);
          } else if (e.conn) {
            e.conn.stop();
            e.conn.removeAllListeners();
            e.conn = null;
            this.updateLink(e);
          }
        }
        this.scheduleScan();
      }
      connect(e) {
        const id = e.info.id;
        if (!e.info.key) {
          this.updateLink(e);
          return;
        }
        const conn = new TuyaDevice({ id, key: e.info.key, ip: e.ip, version: e.version, log: this.log });
        e.conn = conn;
        conn.on("state", () => this.updateLink(e));
        conn.on("version", (v) => {
          e.version = v;
          this.saveCache();
        });
        conn.on("dps", (changed) => this.onDps(e, changed));
        conn.on("authError", () => {
          if (this.cloud && Date.now() - this.lastAuthRefresh > 5 * 6e4) {
            this.lastAuthRefresh = Date.now();
            this.log(`${e.info.name}: key rejected, refreshing device list`);
            this.refresh().catch(() => {
            });
          }
        });
        conn.start();
        this.updateLink(e);
      }
      /** local = talking to it on the home network, cloud = via Tuya's cloud. */
      updateLink(e) {
        let link;
        if (!e.info.key) link = "nokey";
        else if (e.conn && e.conn.state === "connected") link = "local";
        else if (this.cloud && this.account.state === "ok" && e.cloudOnline !== false) link = "cloud";
        else if (!e.ip) link = "searching";
        else if (e.conn && e.conn.state === "connecting" && !e.everConnected) link = "connecting";
        else link = "offline";
        if (link === "local" && e.link !== "local") this.log(`${e.info.name}: connected on home network (${e.ip}, v${e.version || e.conn.version})`);
        if (link === "local") e.everConnected = true;
        this.setLink(e, link);
      }
      setLink(e, link) {
        if (e.link === link) return;
        e.link = link;
        this.emit("update", e.info.id);
      }
      onDps(e, changed) {
        Object.assign(e.dps, changed);
        if (e.info.power && changed[e.info.power.dp] !== void 0) this.recordPower(e);
        this.emit("update", e.info.id);
      }
      recordPower(e) {
        const w = model2.powerWatts(e.info, e.dps);
        if (w === null) return;
        const now = Date.now();
        const last = e.history[e.history.length - 1];
        if (last && now - last.t < 1500) last.w = w;
        else e.history.push({ t: now, w });
        while (e.history.length > HISTORY_MAX) e.history.shift();
      }
      /** If a wanted device hasn't been found by broadcast, scan the network once in a while. */
      scheduleScan() {
        clearTimeout(this.scanTimer);
        const missing = [...this.wanted.keys()].filter((id) => {
          const e = this.devices.get(id);
          return e && e.info.key && !e.ip;
        });
        if (!missing.length) return;
        this.scanTimer = setTimeout(() => this.scanForMissing().catch((err) => this.log("scan error " + err.message)), 15e3);
      }
      async scanForMissing() {
        if (this.scanning) return;
        const missing = [...this.wanted.keys()].map((id) => this.devices.get(id)).filter((e) => e && e.info.key && !e.ip);
        if (!missing.length) return;
        this.scanning = true;
        try {
          const taken = new Set([...this.devices.values()].map((e) => e.ip).filter(Boolean));
          const hosts = (await this.discovery.scan()).filter((h) => !taken.has(h));
          for (const host of hosts) {
            for (const e of missing) {
              if (e.ip) continue;
              const ok = await probe(e, host, this.log);
              if (ok) {
                this.log(`found ${e.info.name} at ${host} by network scan (v${ok})`);
                this.onFound({ id: e.info.id, ip: host, version: ok });
                break;
              }
            }
          }
        } finally {
          this.scanning = false;
          const still = [...this.wanted.keys()].some((id) => {
            const e = this.devices.get(id);
            return e && e.info.key && !e.ip;
          });
          if (still) this.scanTimer = setTimeout(() => this.scanForMissing().catch(() => {
          }), 5 * 6e4);
        }
      }
      // ------------------------------------------------------------ control
      async set(id, dps) {
        const e = this.devices.get(id);
        if (!e) return false;
        const before = { ...e.dps };
        Object.assign(e.dps, dps);
        this.emit("update", id);
        let ok = false;
        if (e.conn && e.conn.state === "connected") ok = await e.conn.set(dps);
        if (!ok && this.cloud && this.account.state !== "expired") {
          try {
            const cmds = model2.dpsToCloudCommands(e.info, dps);
            if (cmds.length) {
              await this.cloud.command(id, cmds);
              ok = true;
            }
          } catch (err) {
            this.log(`cloud command for ${e.info.name} failed: ${err.message}`);
          }
        }
        if (!ok) {
          for (const k of Object.keys(dps)) e.dps[k] = before[k];
          this.emit("update", id);
          this.emit("failed", id);
        }
        return ok;
      }
      /** Called every few seconds: power readings and cloud fallback polling. */
      async tick() {
        const now = Date.now();
        for (const [id, opts] of this.wanted) {
          const e = this.devices.get(id);
          if (!e) continue;
          if (e.conn && e.conn.state === "connected") {
            if (opts.power && e.info.power && now - (e.lastPowerAsk || 0) > POWER_POLL_MS) {
              e.lastPowerAsk = now;
              e.conn.requestDps([e.info.power.dp]);
              this.recordPower(e);
            }
            continue;
          }
          if (this.cloud && this.account.state === "ok" && now - e.lastCloudPoll > CLOUD_POLL_MS) {
            e.lastCloudPoll = now;
            try {
              const st = await this.cloud.status(id);
              e.cloudOnline = true;
              this.onDps(e, model2.cloudStatusToDps(e.info, st));
            } catch (err) {
              this.log(`cloud status for ${e.info.name} failed: ${err.message}`);
              if (/offline/i.test(err.message)) e.cloudOnline = false;
            }
            this.updateLink(e);
          }
        }
      }
      /** Summary for the settings panel. */
      listForPanel() {
        return [...this.devices.values()].map((e) => ({
          id: e.info.id,
          name: e.info.name,
          kind: e.info.kind,
          product: e.info.product,
          switches: e.info.switches.map((s) => ({ dp: s.dp, label: s.label })),
          hasPower: !!e.info.power,
          isLight: !!e.info.light,
          dimmable: !!(e.info.light && (e.info.light.brightDp || e.info.light.colourDp)),
          link: e.link,
          ip: e.ip,
          version: e.version,
          noKey: !e.info.key
        })).sort((a, b) => a.name.localeCompare(b.name));
      }
      stop() {
        this.discovery.stop();
        clearTimeout(this.scanTimer);
        for (const e of this.devices.values()) if (e.conn) e.conn.stop();
      }
    };
    function probe(e, host, log2) {
      return new Promise((resolve) => {
        const d = new TuyaDevice({ id: e.info.id, key: e.info.key, ip: host, version: e.version, log: () => {
        } });
        let done = false;
        const finish = (v) => {
          if (done) return;
          done = true;
          clearTimeout(timer);
          d.stop();
          resolve(v);
        };
        d.on("dps", () => finish(d.version || null));
        d.on("authError", () => {
          if (e.version) finish(null);
        });
        const timer = setTimeout(() => finish(null), e.version ? 7e3 : 16e3);
        d.start();
      });
    }
    module2.exports = { Hub: Hub2 };
  }
});

// src/index.js
var path = require("path");
var fs = require("fs");
var WebSocket = require_ws();
var raster = require_raster();
var render = require_render();
var model = require_model();
var { Hub } = require_hub();
var { REGIONS } = require_cloud();
var ID = "com.clarkyau.smarthome";
var OLD_ID = "dev.smarthome.tuya";
var PLUGIN_DIR = process.env.SMARTHOME_PLUGIN_DIR || path.resolve(__dirname, "..");
var ASSET_DIR = fs.existsSync(path.join(__dirname, "assets")) ? path.join(__dirname, "assets") : path.join(PLUGIN_DIR, "plugin", "assets");
var OLD_DIR = path.join(path.dirname(PLUGIN_DIR), `${OLD_ID}.sdPlugin`);
var S = render.S;
var LOG_PATH = path.join(PLUGIN_DIR, "plugin.log");
function log(...parts) {
  try {
    try {
      if (fs.statSync(LOG_PATH).size > 1024 * 1024) fs.renameSync(LOG_PATH, LOG_PATH + ".old");
    } catch (_) {
    }
    const line = parts.map((p) => typeof p === "string" ? p : JSON.stringify(p)).join(" ");
    fs.appendFileSync(LOG_PATH, `${(/* @__PURE__ */ new Date()).toISOString()} ${line}
`);
  } catch (_) {
  }
}
process.on("uncaughtException", (e) => log("uncaughtException", e && e.stack ? e.stack : String(e)));
process.on("unhandledRejection", (e) => log("unhandledRejection", e && e.stack ? e.stack : String(e)));
var DEFAULT_GLOBALS = { accessId: "", accessSecret: "", region: "auto", keyLayout: "auto", legacyLook: null };
var G = { ...DEFAULT_GLOBALS };
function cleanGlobals(input) {
  const src = input && typeof input === "object" ? input : {};
  const out = { ...DEFAULT_GLOBALS };
  if (typeof src.accessId === "string") out.accessId = src.accessId.trim();
  if (typeof src.accessSecret === "string") out.accessSecret = src.accessSecret.trim();
  if (src.region === "auto" || src.region in REGIONS) out.region = src.region;
  if (["auto", "akp153", "standard"].includes(src.keyLayout)) out.keyLayout = src.keyLayout;
  if (src.legacyLook && typeof src.legacyLook === "object") out.legacyLook = src.legacyLook;
  return out;
}
var hasCreds = () => !!(G.accessId && G.accessSecret);
function parseColor(v) {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(v || "").trim());
  if (!m) return null;
  const n = parseInt(m[1], 16);
  return [n >> 16 & 255, n >> 8 & 255, n & 255];
}
var ACTIONS = ["setup", "switch", "light", "brightness", "power"];
var SHOWS = {
  setup: ["auto", "status", "devices"],
  switch: ["auto", "button", "icon", "name", "state", "watts"],
  light: ["auto", "button", "icon", "name", "state", "level"],
  brightness: ["auto", "slider", "level", "name"],
  power: ["auto", "watts", "graph", "name", "state"]
};
var ICONS = ["auto", "power", "plug", "switch", "bulb", "fan"];
function cleanKeySettings(action, s) {
  const src = s && typeof s === "object" ? s : {};
  return {
    v: 2,
    deviceId: typeof src.deviceId === "string" ? src.deviceId : "",
    dp: typeof src.dp === "string" ? src.dp : "",
    show: (SHOWS[action] || ["auto"]).includes(src.show) ? src.show : "auto",
    join: src.join !== false,
    label: typeof src.label === "string" ? src.label.slice(0, 60) : "",
    icon: ICONS.includes(src.icon) ? src.icon : "auto",
    color: parseColor(src.color) ? src.color : "",
    style: src.style === "flat" ? "flat" : "glow",
    press: src.press === "toggle" ? "toggle" : "none"
  };
}
function upgradeKeySettings(action, s) {
  const out = cleanKeySettings(action, s);
  const look = G.legacyLook || {};
  if (look.style === "flat") out.style = "flat";
  if (!out.color && look.onColor && parseColor(look.onColor) && look.onColor.toLowerCase() !== "#ffb448") out.color = look.onColor;
  if (look.showNames === "off" && (action === "switch" || action === "light")) out.show = "icon";
  return out;
}
function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length - 1; i++) {
    if (/^-{1,2}[A-Za-z]/.test(argv[i])) {
      out[argv[i].replace(/^-+/, "")] = argv[i + 1];
      i++;
    }
  }
  return out;
}
var args = parseArgs(process.argv.slice(2));
var PORT = args.port || process.argv[3];
var PLUGIN_UUID = args.pluginUUID || process.argv[5];
var REGISTER_EVENT = args.registerEvent || process.argv[7] || "registerPlugin";
log("starting", { port: PORT, node: process.version, folder: PLUGIN_DIR });
var deviceInfo = /* @__PURE__ */ new Map();
try {
  const info = JSON.parse(args.info || process.argv[9] || "{}");
  for (const d of info.devices || []) deviceInfo.set(String(d.id), d);
  log("decks", (info.devices || []).map((d) => `${d.name} ${d.size ? d.size.columns + "x" + d.size.rows : ""}`));
} catch (e) {
  log("could not read deck info", String(e));
}
function usesHardwareOrder(device) {
  if (G.keyLayout === "akp153") return true;
  if (G.keyLayout === "standard") return false;
  const d = deviceInfo.get(String(device));
  if (!d) return true;
  const t = `${d.name || ""} ${d.type || ""} ${d.model || ""} ${device}`;
  if (/153|293|HSV/i.test(t)) return true;
  const size = d.size || {};
  return (size.columns === 5 || size.columns === 6) && size.rows === 3;
}
function toPhysical(device, column, row) {
  if (column < 0 || column > 4 || row < 0 || row > 2 || !usesHardwareOrder(device)) return { col: column, row };
  const index = row * 5 + column;
  return { col: 4 - Math.floor(index / 3), row: index % 3 };
}
var zoneOf = (col) => col >= 5 ? "side" : "main";
var ws = new WebSocket(`ws://127.0.0.1:${PORT}`);
ws.on("open", () => {
  ws.send(JSON.stringify({ event: REGISTER_EVENT, uuid: PLUGIN_UUID }));
  ws.send(JSON.stringify({ event: "getGlobalSettings", context: PLUGIN_UUID }));
  log("registered with the Stream Dock software");
});
ws.on("close", () => {
  log("software closed the connection, exiting");
  shutdown();
});
ws.on("error", (e) => log("websocket error", String(e)));
ws.on("message", (raw) => {
  let msg;
  try {
    msg = JSON.parse(raw.toString());
  } catch (_) {
    return;
  }
  try {
    handleHostEvent(msg);
  } catch (e) {
    log("event error", msg.event, e.stack || String(e));
  }
});
function send(obj) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}
var keys = /* @__PURE__ */ new Map();
var piContext = null;
var piAction = null;
var globalsLoaded = false;
var hub = new Hub({ dir: PLUGIN_DIR, log });
hub.on("update", () => scheduleRender());
hub.on("devices", () => {
  updateWanted();
  scheduleRender();
  sendPanelState();
});
hub.on("account", () => {
  sendPanelState();
  scheduleRender();
});
hub.on("failed", (id) => {
  failedUntil.set(id, Date.now() + 1600);
  scheduleRender();
  setTimeout(scheduleRender, 1700);
});
function actionOf(uuid) {
  const a = String(uuid || "").split(".").pop();
  return ACTIONS.includes(a) ? a : null;
}
function handleHostEvent(msg) {
  const { event, context } = msg;
  switch (event) {
    case "willAppear": {
      const action = actionOf(msg.action);
      if (!action) return;
      const c = msg.payload && msg.payload.coordinates || { column: 0, row: 0 };
      const device = msg.device || "default";
      const pos = toPhysical(device, c.column | 0, c.row | 0);
      const raw = msg.payload && msg.payload.settings || {};
      let settings = cleanKeySettings(action, raw);
      if (raw.v !== 2) {
        settings = upgradeKeySettings(action, raw);
        send({ event: "setSettings", context, payload: settings });
      }
      keys.set(context, { action, device, col: pos.col, row: pos.row, reportedCol: c.column | 0, reportedRow: c.row | 0, settings, legacyRaw: raw.v !== 2 ? raw : null });
      log(`key ${action} at column ${pos.col + 1}, row ${pos.row + 1} (reported ${c.column},${c.row})${settings.deviceId ? "" : " no device yet"}`);
      lastSvg.delete(context);
      updateWanted();
      scheduleRender();
      if (action === "setup") sendPanelState();
      break;
    }
    case "willDisappear":
      keys.delete(context);
      lastSvg.delete(context);
      updateWanted();
      scheduleRender();
      break;
    case "didReceiveSettings": {
      const k = keys.get(context);
      if (!k) return;
      k.settings = cleanKeySettings(k.action, msg.payload && msg.payload.settings);
      k.legacyRaw = null;
      lastSvg.delete(context);
      updateWanted();
      scheduleRender();
      break;
    }
    case "keyDown":
      onKeyDown(context);
      break;
    case "didReceiveGlobalSettings":
      applyGlobals(msg.payload && msg.payload.settings);
      if (!globalsLoaded) {
        globalsLoaded = true;
        watchForImport();
      }
      break;
    case "propertyInspectorDidAppear":
      piContext = context;
      piAction = msg.action;
      sendPanelState();
      break;
    case "propertyInspectorDidDisappear":
      if (piContext === context) piContext = null;
      break;
    case "sendToPlugin":
      onPanelMessage(msg);
      break;
    case "deviceDidConnect":
      if (msg.device && msg.deviceInfo) deviceInfo.set(String(msg.device), msg.deviceInfo);
      if (msg.device && msg.payload && msg.payload.deviceInfo) deviceInfo.set(String(msg.device), msg.payload.deviceInfo);
      relayout();
      lastSvg.clear();
      scheduleRender();
      break;
    case "systemDidWakeUp":
      lastSvg.clear();
      for (const e of hub.devices.values()) if (e.conn) e.conn.restart("computer woke up");
      scheduleRender();
      break;
    default:
      break;
  }
}
function relayout() {
  for (const k of keys.values()) {
    const pos = toPhysical(k.device, k.reportedCol, k.reportedRow);
    k.col = pos.col;
    k.row = pos.row;
  }
}
function applyGlobals(input) {
  const next = cleanGlobals(input);
  const layoutChanged = next.keyLayout !== G.keyLayout;
  G = next;
  if (layoutChanged) relayout();
  hub.setCredentials({ accessId: G.accessId, accessSecret: G.accessSecret, region: G.region });
  log(`account details: ${hasCreds() ? "saved" : "not set"}, data centre ${G.region}`);
  lastSvg.clear();
  updateWanted();
  scheduleRender();
  sendPanelState();
}
function saveGlobals() {
  send({ event: "setGlobalSettings", context: PLUGIN_UUID, payload: G });
}
var IMPORT_FILE = path.join(PLUGIN_DIR, "import-settings.json");
function watchForImport() {
  copyOldDeviceList();
  let tries = 0;
  const check = () => {
    let data = null;
    try {
      data = JSON.parse(fs.readFileSync(IMPORT_FILE, "utf8"));
    } catch (_) {
      data = null;
    }
    if (data) {
      try {
        fs.unlinkSync(IMPORT_FILE);
      } catch (_) {
      }
      if (!hasCreds() && typeof data.accessId === "string" && typeof data.accessSecret === "string") {
        G = cleanGlobals({ ...G, accessId: data.accessId, accessSecret: data.accessSecret, region: data.region, keyLayout: data.keyLayout || G.keyLayout, legacyLook: data.look || null });
        saveGlobals();
        applyGlobals(G);
        log("imported the account details from the previous version of the plugin");
        reapplyLegacyLook();
      } else if (data.look && !G.legacyLook) {
        G.legacyLook = data.look;
        saveGlobals();
        reapplyLegacyLook();
      }
      removeOldPlugin();
      return true;
    }
    if (hasCreds() && fs.existsSync(path.join(OLD_DIR, "MOVED.txt"))) {
      removeOldPlugin();
      return true;
    }
    return false;
  };
  if (check()) return;
  if (!fs.existsSync(OLD_DIR)) return;
  const timer = setInterval(() => {
    if (check() || ++tries > 90) clearInterval(timer);
  }, 2e3);
}
function reapplyLegacyLook() {
  for (const [context, k] of keys) {
    if (!k.legacyRaw) continue;
    k.settings = upgradeKeySettings(k.action, k.legacyRaw);
    k.legacyRaw = null;
    send({ event: "setSettings", context, payload: k.settings });
  }
  lastSvg.clear();
  scheduleRender();
}
function copyOldDeviceList() {
  const mine = path.join(PLUGIN_DIR, "devices.json");
  const old = path.join(OLD_DIR, "devices.json");
  try {
    if (!fs.existsSync(mine) && fs.existsSync(old)) {
      fs.copyFileSync(old, mine);
      hub.loadCache();
      log("copied the saved device list from the previous version of the plugin");
      updateWanted();
      scheduleRender();
    }
  } catch (e) {
    log("could not copy the old device list: " + e.message);
  }
}
function removeOldPlugin() {
  try {
    const man = JSON.parse(fs.readFileSync(path.join(OLD_DIR, "manifest.json"), "utf8"));
    if (!JSON.stringify(man.Actions || []).includes(OLD_ID)) return;
    copyOldDeviceList();
    fs.rmSync(OLD_DIR, { recursive: true, force: true });
    log("removed the previous version of the plugin");
  } catch (e) {
    if (e.code !== "ENOENT") log("could not remove the previous version yet: " + e.message);
  }
}
function updateWanted() {
  const want = /* @__PURE__ */ new Map();
  for (const k of keys.values()) {
    const id = k.settings.deviceId;
    if (!id || k.action === "setup") continue;
    const cur = want.get(id) || { power: false };
    if (k.action === "power" || k.action === "switch") cur.power = true;
    want.set(id, cur);
  }
  hub.setWanted(want);
}
var pressedUntil = /* @__PURE__ */ new Map();
var failedUntil = /* @__PURE__ */ new Map();
function switchDp(k, e) {
  const info = e.info;
  if (k.settings.dp && info.switches.some((s) => s.dp === k.settings.dp)) return k.settings.dp;
  if ((k.action === "light" || k.action === "brightness") && info.light && info.light.switchDp) return info.light.switchDp;
  return info.switches[0] && info.switches[0].dp || "1";
}
function onKeyDown(context) {
  const k = keys.get(context);
  if (!k) return;
  pressedUntil.set(context, Date.now() + 180);
  scheduleRender();
  setTimeout(scheduleRender, 220);
  if (k.action === "setup") {
    if (!hasCreds()) send({ event: "openUrl", payload: { url: "https://iot.tuya.com/" } });
    else hub.refresh().catch(() => {
    });
    return;
  }
  const e = hub.devices.get(k.settings.deviceId);
  if (!e) return;
  const id = e.info.id;
  const placed = layout().find((p) => p.context === context);
  const show = placed ? placed.show : "button";
  if (k.action === "switch" || k.action === "light" || k.action === "power" && k.settings.press === "toggle" || k.action === "brightness" && show === "name") {
    const dp = switchDp(k, e);
    hub.set(id, { [dp]: !(e.dps[dp] === true) });
    return;
  }
  if (k.action === "brightness") {
    const ls = model.lightState(e.info, e.dps) || { on: false, pct: 0 };
    let target;
    if (show === "slider" && placed.segment) {
      target = Math.round((placed.segment.index + 1) / placed.segment.size * 100);
    } else if (!ls.on) {
      const sw = e.info.light && e.info.light.switchDp;
      if (sw) {
        hub.set(id, { [sw]: true });
        return;
      }
      target = ls.pct || 50;
    } else {
      target = [25, 50, 75, 100].find((s) => s > (ls.pct || 0) + 3) || 25;
    }
    const dps = model.brightnessDps(e.info, e.dps, target);
    if (Object.keys(dps).length) hub.set(id, dps);
  }
}
function setupVisible() {
  return [...keys.values()].some((k) => k.action === "setup");
}
function sendPanelState() {
  if (!piContext) return;
  send({
    event: "sendToPropertyInspector",
    action: piAction,
    context: piContext,
    payload: {
      type: "state",
      account: {
        state: hub.account.state,
        message: hub.account.message,
        region: hub.account.region,
        regionName: REGIONS[hub.account.region] ? REGIONS[hub.account.region].name : ""
      },
      hasCreds: hasCreds(),
      setupVisible: setupVisible(),
      devices: hub.listForPanel()
    }
  });
}
function onPanelMessage(msg) {
  const p = msg.payload || {};
  if (msg.context && keys.has(msg.context)) {
    piContext = msg.context;
    piAction = msg.action;
  }
  switch (p.type) {
    case "hello":
      sendPanelState();
      break;
    case "refresh":
      hub.refresh().then(() => sendPanelState());
      break;
    case "globals":
      applyGlobals({ ...G, ...p.settings, legacyLook: G.legacyLook });
      break;
    case "openUrl":
      if (/^https:\/\//.test(p.url || "")) send({ event: "openUrl", payload: { url: p.url } });
      break;
    case "identify": {
      const e = hub.devices.get(p.deviceId);
      if (!e) return;
      const dp = e.info.light && e.info.light.switchDp || e.info.switches[0] && e.info.switches[0].dp;
      if (!dp) return;
      const was = e.dps[dp] === true;
      hub.set(e.info.id, { [dp]: !was }).then(() => setTimeout(() => hub.set(e.info.id, { [dp]: was }), 1200));
      break;
    }
    default:
      break;
  }
}
function statusOf(e) {
  switch (e.link) {
    case "local":
    case "cloud":
      return "ok";
    case "nokey":
      return "nokey";
    case "searching":
      return "searching";
    case "connecting":
      return "connecting";
    default:
      return "offline";
  }
}
function iconFor(k, e) {
  if (k.settings.icon !== "auto") return k.settings.icon;
  if (k.action === "light") return "bulb";
  switch (e.info.kind) {
    case "plug":
      return "plug";
    case "light":
      return "bulb";
    case "fan":
      return "fan";
    case "switch":
      return "switch";
    default:
      return "power";
  }
}
function groupId(k) {
  if (k.action === "setup") return `${k.device}|${k.row}|${zoneOf(k.col)}|setup`;
  const e = hub.devices.get(k.settings.deviceId);
  const dp = e && k.action !== "brightness" ? switchDp(k, e) : "";
  return `${k.device}|${k.row}|${zoneOf(k.col)}|${k.action}|${k.settings.deviceId}|${dp}`;
}
function autoShow(action, i, n, e) {
  const meter = !!(e && e.info.power);
  const dimmable = !!(e && e.info.light && (e.info.light.brightDp || e.info.light.colourDp));
  switch (action) {
    case "setup":
      return i === 0 ? "status" : "devices";
    case "switch":
      return n === 1 || i === 0 ? "button" : meter && n >= 3 && i === n - 1 ? "watts" : "name";
    case "light":
      return n === 1 || i === 0 ? "button" : dimmable && n >= 3 && i === n - 1 ? "level" : "name";
    case "brightness":
      return n === 1 || i === 0 ? "level" : "slider";
    case "power":
      return n === 1 || i === 0 ? "watts" : "graph";
    default:
      return "button";
  }
}
function validShow(action, show, e) {
  const meter = !!(e && e.info.power);
  const dimmable = !!(e && e.info.light && (e.info.light.brightDp || e.info.light.colourDp));
  if ((show === "watts" || show === "graph") && !meter) return action === "power" ? "none" : "state";
  if (show === "level" && action === "light" && !dimmable) return "state";
  if ((show === "level" || show === "slider") && action === "brightness" && !dimmable) return "none";
  return show;
}
function layout() {
  const byGroup = /* @__PURE__ */ new Map();
  for (const [context, k] of keys) {
    const id = groupId(k);
    if (!byGroup.has(id)) byGroup.set(id, []);
    byGroup.get(id).push({ context, k });
  }
  const out = [];
  let gseq = 0;
  for (const list of byGroup.values()) {
    list.sort((a, b) => a.k.col - b.k.col);
    const runs = [];
    for (const item of list) {
      const run = runs[runs.length - 1];
      const prev = run && run[run.length - 1];
      const joinable = prev && item.k.col === prev.k.col + 1 && prev.k.settings.join && item.k.settings.join && (item.k.action === "setup" || item.k.settings.deviceId);
      if (joinable) run.push(item);
      else runs.push([item]);
    }
    for (const run of runs) {
      const gid = ++gseq;
      const n = run.length;
      const placed = run.map((item, i) => {
        const e = hub.devices.get(item.k.settings.deviceId) || null;
        let show = item.k.settings.show === "auto" ? autoShow(item.k.action, i, n, e) : item.k.settings.show;
        if (item.k.action !== "setup") show = validShow(item.k.action, show, e);
        return { context: item.context, k: item.k, e, show, group: gid };
      });
      let seg = null;
      placed.forEach((p, i) => {
        const shareable = p.show === "name" || p.show === "slider" || p.show === "graph";
        if (shareable && seg && seg.show === p.show && placed[i - 1].show === p.show) {
          seg.members.push(p);
        } else {
          seg = { show: p.show, members: [p], id: `${gid}.${i}` };
        }
        p.seg = seg;
      });
      const named = placed.some((p) => p.show === "name");
      for (const p of placed) {
        p.named = named && p.show !== "name";
        p.segment = { id: p.seg.id, index: p.seg.members.indexOf(p), size: p.seg.members.length, members: p.seg.members };
        delete p.seg;
        out.push(p);
      }
    }
  }
  return out;
}
function notReadyLines(k) {
  if (!hub.devices.size) {
    if (!hasCreds()) return setupVisible() ? ["Finish the", "Setup key"] : ["Add the", "Setup key"];
    if (hub.account.state === "working") return ["Connecting", "to Tuya"];
    if (hub.account.state === "error" || hub.account.state === "expired") return ["Check the", "Setup key"];
    return ["No devices", "Check Setup key"];
  }
  if (!k.settings.deviceId) return ["Pick a device", "in key settings"];
  return ["Device gone", "Pick another"];
}
function keyColour(p) {
  const k = p.k, e = p.e;
  const custom = parseColor(k.settings.color);
  if (custom) return custom;
  if (e && e.info.light && (k.action === "light" || k.action === "brightness" || iconFor(k, e) === "bulb")) {
    const ls = model.lightState(e.info, e.dps);
    if (ls) return ls.rgb;
  }
  return render.AMBER;
}
function setupDraw(p, now) {
  const a = hub.account;
  const n = hub.devices.size;
  const pressed = (pressedUntil.get(p.context) || 0) > now;
  if (p.show === "devices") {
    const local = [...hub.devices.values()].filter((e) => e.link === "local").length;
    return render.drawKey({ show: "devices", count: n, sub: n ? `${local} on Wi-Fi` : "none yet", style: p.k.settings.style, pressed });
  }
  let line1, line2, color, glow = false;
  if (!hasCreds()) {
    if (n) {
      line1 = "Saved list";
      line2 = "Press: sign in";
      color = render.AMBER;
    } else {
      line1 = "Set up";
      line2 = "Press: open Tuya";
      color = render.MUTED;
    }
  } else if (a.state === "working") {
    line1 = "Connecting";
    line2 = "Tuya cloud";
    color = render.AMBER;
  } else if (a.state === "ok") {
    line1 = "Connected";
    line2 = `${n} device${n === 1 ? "" : "s"}`;
    color = render.GREEN;
    glow = true;
  } else if (a.state === "expired") {
    line1 = "Trial ended";
    line2 = n ? "Keys still work" : "Extend at Tuya";
    color = render.RED;
  } else if (a.state === "error") {
    const kind = a.kind || "";
    line1 = kind === "auth" ? "Wrong details" : kind === "network" ? "No internet" : kind === "permission" ? "No permission" : kind === "region" ? "Wrong region" : "Cloud error";
    line2 = "Press to retry";
    color = render.RED;
  } else {
    line1 = n ? "Saved list" : "Set up";
    line2 = "Press to connect";
    color = render.MUTED;
  }
  return render.drawKey({ show: "status", line1, line2, statusColor: color, line1Color: color === render.MUTED ? render.TEXT : color, statusGlow: glow, style: p.k.settings.style, pressed });
}
function deviceDraw(p, now) {
  const k = p.k, e = p.e;
  const info = e.info;
  const color = keyColour(p);
  const status = statusOf(e);
  const name = k.settings.label || info.name;
  const dp = switchDp(k, e);
  const ls = info.light ? model.lightState(info, e.dps) : null;
  const on = k.action === "brightness" || k.action === "light" && ls ? ls ? ls.on : e.dps[dp] === true : e.dps[dp] === true;
  const base = {
    name,
    status,
    color,
    style: k.settings.style,
    on,
    icon: iconFor(k, e),
    pct: ls ? ls.pct : null,
    watts: model.powerWatts(info, e.dps),
    pressed: (pressedUntil.get(p.context) || 0) > now,
    failed: (failedUntil.get(info.id) || 0) > now
  };
  if (p.show === "none") return render.drawKey({ show: "message", lines: k.action === "power" ? ["No power", "meter"] : ["Not dimmable", "Pick another"] });
  if (p.named) base.name = p.show === "button" ? on ? "On" : "Off" : "";
  return render.drawKey({ ...base, show: p.show });
}
function drawAll() {
  const now = Date.now();
  const out = /* @__PURE__ */ new Map();
  const doneSegments = /* @__PURE__ */ new Set();
  for (const p of layout()) {
    if (p.k.action === "setup") {
      out.set(p.context, setupDraw(p, now));
      continue;
    }
    if (!p.e || !p.k.settings.deviceId) {
      out.set(p.context, render.drawKey({ show: "message", lines: notReadyLines(p.k) }));
      continue;
    }
    if (p.segment.size > 1 || ["name", "slider", "graph"].includes(p.show)) {
      if (doneSegments.has(p.segment.id)) continue;
      doneSegments.add(p.segment.id);
      const first = p.segment.members[0];
      const e = first.e;
      const info = e.info;
      const ls = info.light ? model.lightState(info, e.dps) : null;
      const dp = switchDp(first.k, e);
      const d = {
        name: first.k.settings.label || info.name,
        status: statusOf(e),
        color: keyColour(first),
        style: first.k.settings.style,
        on: ls && first.k.action !== "switch" ? ls.on : e.dps[dp] === true,
        pct: ls ? ls.pct : 0,
        history: e.history,
        now,
        keys: p.segment.members.map((m2) => ({
          pressed: (pressedUntil.get(m2.context) || 0) > now,
          failed: (failedUntil.get(info.id) || 0) > now
        }))
      };
      const m = p.segment.size;
      let images;
      if (p.show === "name") images = render.drawNames(m, d);
      else if (p.show === "slider") images = render.drawSlider(m, d);
      else if (p.show === "graph") images = render.drawGraph(m, d);
      else images = p.segment.members.map((x) => deviceDraw(x, now));
      p.segment.members.forEach((x, i) => out.set(x.context, images[i]));
      continue;
    }
    out.set(p.context, deviceDraw(p, now));
  }
  return out;
}
var lastSvg = /* @__PURE__ */ new Map();
var renderTimer = null;
var ready = false;
function scheduleRender() {
  if (renderTimer) return;
  renderTimer = setTimeout(() => {
    renderTimer = null;
    if (!ready) return;
    try {
      renderAll();
    } catch (e) {
      log("render error", e.stack || String(e));
    }
  }, 30);
}
function renderAll() {
  for (const [context, svg] of drawAll()) {
    if (!svg || lastSvg.get(context) === svg) continue;
    lastSvg.set(context, svg);
    const payload = { image: raster.toDataUrl(svg), target: 0 };
    if (process.env.SMARTHOME_TEST_SVG) payload.svg = svg;
    send({ event: "setImage", context, payload });
  }
}
raster.init(ASSET_DIR).then(() => {
  ready = true;
  scheduleRender();
}).catch((e) => log("renderer failed to start", e.stack || String(e)));
var tickTimer = setInterval(() => {
  hub.tick().catch((e) => log("tick error", e.message));
  if ([...keys.values()].some((k) => k.action === "power" || k.settings.show === "graph" || k.settings.show === "watts")) scheduleRender();
}, 2e3);
function shutdown() {
  clearInterval(tickTimer);
  hub.stop();
  setTimeout(() => process.exit(0), 200);
}
module.exports = { cleanGlobals, cleanKeySettings, ID };
